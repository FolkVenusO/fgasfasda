"""
Тесты производительности для Remote Guardian
Проверяет скорость критических операций
"""

import sys
import os
import time
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def test_screenshot_performance():
    """Тест производительности скриншотов."""
    print("🧪 Тестирование производительности скриншотов...")
    
    try:
        from utils.screenshot import take_screenshot_optimized
        import tempfile
        
        # Тест 1: MSS (если доступен)
        with tempfile.NamedTemporaryFile(suffix='.png', delete=False) as f:
            temp_path = f.name
        
        start = time.perf_counter()
        success = take_screenshot_optimized(temp_path, compress=True)
        elapsed = time.perf_counter() - start
        
        if success:
            file_size = os.path.getsize(temp_path) / 1024  # KB
            print(f"  ✅ Скриншот: {elapsed*1000:.1f}ms, размер: {file_size:.1f} KB")
            
            # Проверка производительности
            if elapsed > 0.5:
                print(f"  ⚠️ МЕДЛЕННО! Скриншот занял {elapsed:.2f}s (норма <0.5s)")
            
            os.remove(temp_path)
        else:
            print("  ❌ Не удалось сделать скриншот")
        
    except ImportError as e:
        print(f"  ⚠️ Модуль недоступен: {e}")


def test_cache_performance():
    """Тест производительности кеша."""
    print("🧪 Тестирование производительности кеша...")
    
    try:
        from utils.cache import SimpleCache
        
        cache = SimpleCache()
        
        # Тест записи
        start = time.perf_counter()
        for i in range(1000):
            cache.set(f"key_{i}", f"value_{i}")
        write_elapsed = time.perf_counter() - start
        
        # Тест чтения
        start = time.perf_counter()
        for i in range(1000):
            cache.get(f"key_{i}", ttl=60.0)
        read_elapsed = time.perf_counter() - start
        
        print(f"  ✅ Запись 1000 элементов: {write_elapsed*1000:.1f}ms")
        print(f"  ✅ Чтение 1000 элементов: {read_elapsed*1000:.1f}ms")
        
        if write_elapsed > 0.1:
            print(f"  ⚠️ МЕДЛЕННАЯ ЗАПИСЬ! {write_elapsed:.3f}s (норма <0.1s)")
        if read_elapsed > 0.1:
            print(f"  ⚠️ МЕДЛЕННОЕ ЧТЕНИЕ! {read_elapsed:.3f}s (норма <0.1s)")
        
    except ImportError as e:
        print(f"  ⚠️ Модуль недоступен: {e}")


def test_database_performance():
    """Тест производительности базы данных."""
    print("🧪 Тестирование производительности базы данных...")
    
    try:
        import database
        import tempfile
        import shutil
        
        # Создаём временную копию БД
        original_db = database.DB_FILE
        temp_dir = tempfile.mkdtemp()
        temp_db = os.path.join(temp_dir, 'test_db.json')
        
        if os.path.exists(original_db):
            shutil.copy(original_db, temp_db)
        
        database.DB_FILE = temp_db
        database.load([])
        
        # Тест добавления пользователей
        start = time.perf_counter()
        for i in range(100):
            database.add(f"user_{i}", 10)
        add_elapsed = time.perf_counter() - start
        
        # Тест проверки лимитов
        start = time.perf_counter()
        for i in range(100):
            database.check_limit(f"user_{i}")
        check_elapsed = time.perf_counter() - start
        
        print(f"  ✅ Добавление 100 пользователей: {add_elapsed*1000:.1f}ms")
        print(f"  ✅ Проверка лимитов 100 раз: {check_elapsed*1000:.1f}ms")
        
        if add_elapsed > 1.0:
            print(f"  ⚠️ МЕДЛЕННОЕ ДОБАВЛЕНИЕ! {add_elapsed:.2f}s (норма <1s)")
        if check_elapsed > 0.5:
            print(f"  ⚠️ МЕДЛЕННАЯ ПРОВЕРКА! {check_elapsed:.2f}s (норма <0.5s)")
        
        # Восстанавливаем оригинальную БД
        database.DB_FILE = original_db
        database.load([])
        shutil.rmtree(temp_dir)
        
    except Exception as e:
        print(f"  ❌ Ошибка теста: {e}")


def test_rate_limiter_performance():
    """Тест производительности rate limiter."""
    print("🧪 Тестирование производительности rate limiter...")
    
    try:
        from utils.rate_limiter import RateLimiter
        
        limiter = RateLimiter(max_calls=100, window=60)
        
        # Тест проверки лимитов
        start = time.perf_counter()
        for i in range(1000):
            limiter.check_rate_limit(f"user_{i % 10}")  # 10 разных пользователей
        elapsed = time.perf_counter() - start
        
        print(f"  ✅ 1000 проверок rate limit: {elapsed*1000:.1f}ms")
        print(f"  ✅ Средняя задержка: {elapsed/1000*1000:.3f}ms на проверку")
        
        if elapsed > 0.5:
            print(f"  ⚠️ МЕДЛЕННО! {elapsed:.2f}s (норма <0.5s)")
        
    except ImportError as e:
        print(f"  ⚠️ Модуль недоступен: {e}")


def run_performance_tests():
    """Запускает все тесты производительности."""
    print("=" * 60)
    print("⚡ ЗАПУСК ТЕСТОВ ПРОИЗВОДИТЕЛЬНОСТИ REMOTE GUARDIAN")
    print("=" * 60)
    print()
    
    test_screenshot_performance()
    print()
    test_cache_performance()
    print()
    test_database_performance()
    print()
    test_rate_limiter_performance()
    
    print()
    print("=" * 60)
    print("✅ ТЕСТЫ ПРОИЗВОДИТЕЛЬНОСТИ ЗАВЕРШЕНЫ")
    print("=" * 60)


if __name__ == "__main__":
    run_performance_tests()
