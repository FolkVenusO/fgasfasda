import os
from dotenv import load_dotenv

load_dotenv()

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ASSETS_DIR = os.path.join(BASE_DIR, "assets")
FFMPEG_EXE = os.path.join(BASE_DIR, 'ffmpeg.exe')

if not os.path.exists(ASSETS_DIR):
    os.makedirs(ASSETS_DIR)

API_ID = int(os.getenv('API_ID', 0))
API_HASH = os.getenv('API_HASH', '')
BOT_TOKEN = os.getenv('BOT_TOKEN', '')

# Главные админы (Владельцы). Храним как строки для безопасного сравнения.
env_admins = os.getenv('MAIN_ADMINS', '')
MAIN_ADMINS = [x.strip() for x in env_admins.split(',') if x.strip()]