import os
import sys
import asyncio
import logging
from logging.handlers import RotatingFileHandler
import pygame
from telethon import TelegramClient

# --- ПРОФЕССИОНАЛЬНОЕ ЛОГИРОВАНИЕ ---
def setup_logger():
    # Создаем папку logs рядом со скриптом
    log_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'logs')
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)

    log_file = os.path.join(log_dir, 'guardian.log')

    # Красивый формат лога
    formatter = logging.Formatter(
        fmt='[%(asctime)s] %(levelname)-8s | %(name)s | %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )

    # Запись в файл (макс 5 МБ на файл, храним 3 резервных копии)
    file_handler = RotatingFileHandler(log_file, maxBytes=5*1024*1024, backupCount=3, encoding='utf-8')
    file_handler.setFormatter(formatter)

    # Вывод в консоль
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(formatter)

    # Применяем настройки ко всем логгерам
    logging.basicConfig(level=logging.INFO, handlers=[file_handler, console_handler])

    # Перехват критических ошибок (чтобы краши тоже писались в лог-файл)
    def handle_exception(exc_type, exc_value, exc_traceback):
        if issubclass(exc_type, KeyboardInterrupt):
            sys.__excepthook__(exc_type, exc_value, exc_traceback)
            return
        logging.getLogger("CRITICAL_CRASH").error("Фатальная ошибка!", exc_info=(exc_type, exc_value, exc_traceback))

    sys.excepthook = handle_exception

# Активируем логгер до загрузки остальных модулей
setup_logger()
logger = logging.getLogger("MAIN")

# Дальше идут твои обычные импорты и код...
from config import API_ID, API_HASH, BOT_TOKEN, MAIN_ADMINS
from core.state import state
from core.security import start_sensors
from handlers import register_all_handlers
import database

async def main():
    # 0. Инициализация звукового движка (для сирены и медиа)
    try:
        pygame.mixer.init()
        logger.info("Звуковой движок pygame инициализирован.")
    except Exception as e:
        logger.warning(f"Звуковой движок недоступен (нет аудиоустройства?): {e}")
    
    # 1. Загрузка базы данных
    database.load(MAIN_ADMINS)
    
    # 2. Инициализация клиента Telegram с оптимизированными параметрами
    bot = TelegramClient(
        'bot_session', 
        API_ID, 
        API_HASH,
        # Оптимизация для стабильности при нагрузке
        connection_retries=5,
        retry_delay=1,
        auto_reconnect=True,
        flood_sleep_threshold=60  # Автоматическое ожидание при flood limits
    )
    
    # 3. Сохранение клиента в глобальный стейт для сенсоров
    state.bot_client = bot
    state.bot_loop = asyncio.get_running_loop()
    
    # 4. Регистрация всех команд
    register_all_handlers(bot)
    
    # 5. Запуск фоновых сенсоров безопасности
    start_sensors()
    
    # 6. Запуск бота
    await bot.start(bot_token=BOT_TOKEN)
    logger.info("🚀 REMOTE GUARDIAN V12 (MODULAR) ONLINE")
    
    # 7. Запуск системы умных уведомлений (триггеров)
    try:
        from utils.triggers import start_monitoring
        from utils.dashboard import set_bot_start_time
        
        # Устанавливаем время старта бота для uptime
        set_bot_start_time()
        
        # Запускаем мониторинг триггеров
        admin_ids = set(int(admin_id) for admin_id in MAIN_ADMINS)
        asyncio.create_task(start_monitoring(bot, admin_ids))
        logger.info("✅ Система умных уведомлений запущена")
    except Exception as e:
        logger.error(f"Ошибка запуска системы триггеров: {e}")
    
    # 8. Оповещение владельцев о старте
    startup_msg = (
        "🖥 **Remote Guardian V12.2 ЗАГРУЖЕН!**\n\n"
        "✅ Модульная архитектура\n"
        "✅ Дашборд мониторинга\n"
        "✅ Inline кнопки\n"
        "✅ Умные уведомления 🆕\n\n"
        "Жми /menu для начала работы"
    )
    for adm in MAIN_ADMINS:
        try: 
            await bot.send_message(int(adm), startup_msg)
        except Exception as e: 
            logger.warning(f"Не удалось уведомить админа {adm}: {e}")
    
    # Удержание процесса
    await bot.run_until_disconnected()

if __name__ == '__main__':
    try:
        # Оптимизация event loop для Windows (только для Python < 3.14)
        if sys.platform == 'win32' and sys.version_info < (3, 14):
            asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())
        
        asyncio.run(main())
    except KeyboardInterrupt: 
        logger.info("Бот остановлен пользователем (Ctrl+C).")
    except Exception as e: 
        logger.critical(f"Критическая ошибка ядра: {e}", exc_info=True)
