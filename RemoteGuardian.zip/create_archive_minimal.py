"""
Скрипт для создания МИНИМАЛЬНОГО архива Remote Guardian для AI
Только Python код и документация - без EXE, DLL, медиа
"""

import os
import zipfile
from datetime import datetime

# Разрешённые расширения (только код и документация)
ALLOWED_EXTENSIONS = {
    '.py',      # Python код
    '.md',      # Markdown документация
    '.txt',     # Текстовые файлы (requirements.txt и т.д.)
    '.json',    # JSON конфиги (но не users_db.json!)
    '.example', # Примеры (.env.example)
    '.gitignore', # Git ignore
}

# Файлы для обязательного исключения
EXCLUDE_FILES = {
    '.env',
    'users_db.json',
    'bot_session.session',
    'bot_session.session-journal',
    'triggers_config.json',
}

# Папки для исключения
EXCLUDE_FOLDERS = {
    'assets',        # Медиа файлы
    'logs',          # Логи
    '__pycache__',   # Python кеш
    '.git',
    '.idea',
    '.vscode',
    'venv',
    'env',
    '.pytest_cache',
}


def should_include(filepath, filename):
    """Проверяет нужно ли включить файл в архив."""
    
    # Исключаем файлы из чёрного списка
    if filename in EXCLUDE_FILES:
        return False
    
    # Исключаем временные файлы
    if filename.startswith('tmp_') or filename.startswith('temp_'):
        return False
    
    # Проверяем расширение
    _, ext = os.path.splitext(filename)
    
    # Специальные файлы без расширения
    if filename in ['.gitignore', 'Procfile', 'Dockerfile']:
        return True
    
    # Проверяем разрешённые расширения
    return ext in ALLOWED_EXTENSIONS


def create_minimal_archive():
    """Создаёт минимальный ZIP архив только с Python кодом."""
    
    project_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Имя архива
    date_str = datetime.now().strftime('%Y%m%d_%H%M%S')
    archive_name = f'RemoteGuardian_V12.2_Python_Only_{date_str}.zip'
    archive_path = os.path.join(project_dir, archive_name)
    
    print("=" * 70)
    print("📦 СОЗДАНИЕ МИНИМАЛЬНОГО АРХИВА (ТОЛЬКО PYTHON + ДОКУМЕНТАЦИЯ)")
    print("=" * 70)
    print(f"\n📁 Проект: {project_dir}")
    print(f"📦 Архив: {archive_name}")
    print(f"\n✅ Включается: .py, .md, .txt, .json (конфиги)")
    print(f"❌ Исключается: .exe, .dll, .mp3, .mp4, assets/, logs/\n")
    
    files_added = 0
    files_excluded = 0
    total_size = 0
    
    # Список добавленных файлов для отчёта
    added_files = []
    
    with zipfile.ZipFile(archive_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(project_dir):
            # Исключаем папки
            dirs[:] = [d for d in dirs if d not in EXCLUDE_FOLDERS]
            
            # Пропускаем если мы в исключённой папке
            rel_root = os.path.relpath(root, project_dir)
            if any(excl in rel_root.split(os.sep) for excl in EXCLUDE_FOLDERS):
                continue
            
            for file in files:
                # Пропускаем сам архив
                if file.endswith('.zip'):
                    continue
                
                file_path = os.path.join(root, file)
                
                # Проверяем нужно ли включить
                if should_include(file_path, file):
                    arcname = os.path.relpath(file_path, project_dir)
                    zipf.write(file_path, arcname)
                    
                    file_size = os.path.getsize(file_path)
                    total_size += file_size
                    files_added += 1
                    added_files.append((arcname, file_size))
                    
                    print(f"✅ {arcname}")
                else:
                    files_excluded += 1
    
    # Размер архива
    archive_size_mb = os.path.getsize(archive_path) / (1024 * 1024)
    total_size_mb = total_size / (1024 * 1024)
    
    print("\n" + "=" * 70)
    print("✅ АРХИВ СОЗДАН УСПЕШНО!")
    print("=" * 70)
    
    print(f"\n📦 **Файл:** {archive_name}")
    print(f"📊 **Размер архива:** {archive_size_mb:.2f} MB")
    print(f"📊 **Размер файлов:** {total_size_mb:.2f} MB")
    print(f"✅ **Добавлено:** {files_added} файлов")
    print(f"❌ **Исключено:** {files_excluded} файлов")
    
    # Группируем по типам
    py_files = [f for f, _ in added_files if f.endswith('.py')]
    md_files = [f for f, _ in added_files if f.endswith('.md')]
    other_files = [f for f, _ in added_files if not (f.endswith('.py') or f.endswith('.md'))]
    
    print(f"\n📋 **Состав архива:**")
    print(f"   🐍 Python файлов: {len(py_files)}")
    print(f"   📄 Markdown файлов: {len(md_files)}")
    print(f"   📑 Других файлов: {len(other_files)}")
    
    print("\n" + "=" * 70)
    print("🎯 ЧТО В АРХИВЕ:")
    print("=" * 70)
    
    # Показываем структуру по папкам
    folders = {}
    for arcname, size in added_files:
        folder = os.path.dirname(arcname) or 'root'
        if folder not in folders:
            folders[folder] = []
        folders[folder].append((os.path.basename(arcname), size))
    
    for folder in sorted(folders.keys()):
        file_count = len(folders[folder])
        folder_size = sum(size for _, size in folders[folder]) / 1024  # KB
        print(f"\n📁 {folder}/ ({file_count} файлов, {folder_size:.1f} KB)")
        for filename, size in sorted(folders[folder]):
            size_kb = size / 1024
            print(f"   • {filename} ({size_kb:.1f} KB)")
    
    print("\n" + "=" * 70)
    print("🔒 БЕЗОПАСНОСТЬ:")
    print("=" * 70)
    print("✅ .env исключён (секретные ключи)")
    print("✅ users_db.json исключён (персональные данные)")
    print("✅ bot_session.* исключён (токены)")
    print("✅ assets/ исключена (медиа файлы)")
    print("✅ .exe/.dll исключены (бинарные файлы)")
    
    print("\n" + "=" * 70)
    print("📤 ДЛЯ AI:")
    print("=" * 70)
    print("✅ Весь Python код (main.py, handlers/, core/, utils/)")
    print("✅ Вся документация (.md файлы)")
    print("✅ requirements.txt (зависимости)")
    print("✅ .env.example (пример конфигурации)")
    print("✅ Тесты (tests/)")
    
    print("\n" + "=" * 70)
    print(f"🎉 ГОТОВО! Архив: {archive_name}")
    print("=" * 70)
    print("\n💡 Этот архив можно безопасно передавать другим AI для анализа кода!")
    print("   Размер минимален - только необходимые файлы.\n")
    
    return archive_path


if __name__ == "__main__":
    try:
        archive_path = create_minimal_archive()
        
        print("\n✅ Архив готов к передаче другим AI ассистентам!")
        print(f"📦 Путь: {archive_path}")
        
    except Exception as e:
        print(f"\n❌ ОШИБКА: {e}")
        import traceback
        traceback.print_exc()
