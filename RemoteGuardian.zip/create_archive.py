"""
Скрипт для создания архива Remote Guardian для передачи другим AI
Автоматически исключает чувствительные данные
"""

import os
import zipfile
import shutil
from datetime import datetime

# Файлы и папки для исключения
EXCLUDE = {
    '.env',                    # Секретные ключи
    'users_db.json',          # Персональные данные
    'bot_session.session',    # Сессия Telegram
    'bot_session.session-journal',
    'triggers_config.json',   # Настройки триггеров (могут содержать персональные данные)
    '__pycache__',            # Python кеш
    '.git',                   # Git репозиторий
    '.idea',                  # IDE настройки
    '.vscode',
    'logs',                   # Логи
    'venv',                   # Virtual environment
    'env',
    '.pytest_cache',
    '*.pyc',
    '*.pyo',
    '*.pyd',
    '.DS_Store',              # MacOS
    'Thumbs.db',              # Windows
}

# Временные файлы для исключения (по префиксу)
EXCLUDE_PREFIXES = ['tmp_', 'temp_', '~$']

# Расширения для исключения
EXCLUDE_EXTENSIONS = ['.pyc', '.pyo', '.pyd', '.log', '.tmp']


def should_exclude(path, name):
    """Проверяет нужно ли исключить файл/папку."""
    
    # Проверка на точное совпадение
    if name in EXCLUDE:
        return True
    
    # Проверка префиксов
    for prefix in EXCLUDE_PREFIXES:
        if name.startswith(prefix):
            return True
    
    # Проверка расширений
    for ext in EXCLUDE_EXTENSIONS:
        if name.endswith(ext):
            return True
    
    return False


def create_archive():
    """Создаёт ZIP архив проекта."""
    
    # Получаем путь к проекту
    project_dir = os.path.dirname(os.path.abspath(__file__))
    project_name = os.path.basename(project_dir)
    
    # Имя архива с датой
    date_str = datetime.now().strftime('%Y%m%d_%H%M%S')
    archive_name = f'RemoteGuardian_V12.2_{date_str}.zip'
    archive_path = os.path.join(project_dir, archive_name)
    
    print("=" * 60)
    print("📦 СОЗДАНИЕ АРХИВА REMOTE GUARDIAN")
    print("=" * 60)
    print(f"\n📁 Проект: {project_dir}")
    print(f"📦 Архив: {archive_name}\n")
    
    # Создаём архив
    files_added = 0
    files_excluded = 0
    
    with zipfile.ZipFile(archive_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(project_dir):
            # Исключаем директории
            dirs[:] = [d for d in dirs if not should_exclude(root, d)]
            
            for file in files:
                # Пропускаем сам архив
                if file == archive_name:
                    continue
                
                # Проверяем нужно ли исключить
                if should_exclude(root, file):
                    files_excluded += 1
                    print(f"❌ Исключён: {file}")
                    continue
                
                # Добавляем файл
                file_path = os.path.join(root, file)
                arcname = os.path.relpath(file_path, project_dir)
                
                zipf.write(file_path, arcname)
                files_added += 1
                print(f"✅ Добавлен: {arcname}")
    
    # Размер архива
    archive_size = os.path.getsize(archive_path) / (1024 * 1024)  # MB
    
    print("\n" + "=" * 60)
    print("✅ АРХИВ СОЗДАН УСПЕШНО!")
    print("=" * 60)
    print(f"\n📦 Файл: {archive_name}")
    print(f"📊 Размер: {archive_size:.2f} MB")
    print(f"✅ Добавлено файлов: {files_added}")
    print(f"❌ Исключено файлов: {files_excluded}")
    print("\n" + "=" * 60)
    print("🔒 ПРОВЕРЬ ЧТО ИСКЛЮЧЕНЫ:")
    print("=" * 60)
    print("❌ .env (секретные ключи)")
    print("❌ users_db.json (персональные данные)")
    print("❌ bot_session.* (токены сессии)")
    print("❌ logs/ (логи)")
    print("\n" + "=" * 60)
    print("📋 СЛЕДУЮЩИЕ ШАГИ:")
    print("=" * 60)
    print(f"1. Проверь содержимое архива: {archive_name}")
    print("2. Убедись что нет секретных данных")
    print("3. Можешь передавать архив другим AI ✅")
    print("\n💡 Архив готов для передачи!")
    print("=" * 60)
    
    return archive_path


def verify_archive(archive_path):
    """Проверяет содержимое архива на наличие чувствительных данных."""
    
    print("\n" + "=" * 60)
    print("🔍 ПРОВЕРКА АРХИВА НА БЕЗОПАСНОСТЬ")
    print("=" * 60)
    
    dangerous_files = []
    
    with zipfile.ZipFile(archive_path, 'r') as zipf:
        for name in zipf.namelist():
            # Проверяем на опасные файлы
            if any(pattern in name.lower() for pattern in ['.env', 'users_db.json', 'bot_session']):
                dangerous_files.append(name)
    
    if dangerous_files:
        print("\n⚠️ ВНИМАНИЕ! Найдены чувствительные файлы:")
        for file in dangerous_files:
            print(f"   🚨 {file}")
        print("\n❌ АРХИВ НЕБЕЗОПАСЕН ДЛЯ ПЕРЕДАЧИ!")
        return False
    else:
        print("\n✅ Чувствительные файлы не найдены")
        print("✅ Архив безопасен для передачи!")
        return True


if __name__ == "__main__":
    try:
        # Создаём архив
        archive_path = create_archive()
        
        # Проверяем безопасность
        is_safe = verify_archive(archive_path)
        
        if is_safe:
            print("\n🎉 Готово! Архив можно передавать другим AI.")
        else:
            print("\n⚠️ Удали чувствительные файлы перед передачей!")
        
    except Exception as e:
        print(f"\n❌ ОШИБКА: {e}")
        import traceback
        traceback.print_exc()
