import logging
from functools import wraps
import database
from config import MAIN_ADMINS

logger = logging.getLogger(__name__)

def with_verify(action_name: str, dangerous: bool = False):
    """
    Универсальный декоратор проверки прав и лимитов.
    :param action_name: Имя действия для логирования.
    :param dangerous: Если True, доступно ТОЛЬКО Главным Админам.
    """
    def decorator(func):
        @wraps(func)
        async def wrapper(event, *args, **kwargs):
            uid = str(event.sender_id)
            is_owner = uid in MAIN_ADMINS

            # 1. Проверка на опасные команды
            if dangerous and not is_owner:
                logger.warning(f"User {uid} attempted DANGEROUS action: {action_name}")
                await event.reply("⛔️ **Отказ:** Эта команда доступна только Главному Администратору.")
                return

            # 2. Проверка регистрации и лимитов (для не-владельцев)
            if not is_owner:
                if not database.exists(uid):
                    logger.warning(f"Unregistered access attempt by {uid}: {action_name}")
                    await event.reply("⛔️ **Отказ:** Доступ запрещен. Вы не зарегистрированы в базе.")
                    return
                
                allowed, limit = database.check_limit(uid)
                if not allowed:
                    await event.reply(f"❌ Исчерпан дневной лимит команд: {limit}")
                    return

            # 3. Выполнение и перехват исключений
            logger.info(f"User {uid} executing: {action_name}")
            try:
                return await func(event, *args, **kwargs)
            except Exception as e:
                logger.error(f"Error in {action_name}: {e}", exc_info=True)
                await event.reply("❌ Произошла внутренняя ошибка сервера. Инцидент записан в лог.")
        return wrapper
    return decorator