import time
import asyncio
import logging
import psutil
from pynput import mouse, keyboard
from core.state import state
from config import MAIN_ADMINS

logger = logging.getLogger(__name__)

async def send_alarm_alert():
    """Рассылка тревоги владельцам."""
    if not state.bot_client: return
    for adm in MAIN_ADMINS:
        try:
            await state.bot_client.send_message(
                int(adm), "🚨 **ВНИМАНИЕ! КТО-ТО ЗА КОМПОМ!** 🚨\nЗафиксирована физическая активность!"
            )
        except Exception: pass

def on_physical_activity(*args, **kwargs):
    if state.security_mode:
        curr = time.time()
        if curr - state.last_alarm_time > state.alarm_cooldown:
            state.last_alarm_time = curr
            if state.bot_loop and state.bot_client:
                asyncio.run_coroutine_threadsafe(send_alarm_alert(), state.bot_loop)

def start_usb_monitor():
    """Фоновый монитор подключения USB-накопителей."""
    async def _monitor():
        known_drives = set()
        try:
            known_drives = {d.device for d in psutil.disk_partitions()}
        except: pass  # Игнорируем первичную ошибку

        while True:
            await asyncio.sleep(5)
            try:
                current_drives = {d.device for d in psutil.disk_partitions()}
                new_drives = current_drives - known_drives
                
                for d in new_drives:
                    for adm in MAIN_ADMINS:
                        try: await state.bot_client.send_message(int(adm), f"🔌 **АХТУНГ!** Подключен новый диск/флешка: `{d}`")
                        except: pass
                
                known_drives = current_drives
            except Exception:
                pass  # Если винда ругается на дисковод, цикл не умрет

    if state.bot_loop:
        asyncio.run_coroutine_threadsafe(_monitor(), state.bot_loop)

def start_sensors():
    """Запуск фоновых сенсоров."""
    mouse.Listener(on_move=on_physical_activity, on_click=on_physical_activity).start()
    keyboard.Listener(on_press=on_physical_activity).start()
    start_usb_monitor()
    logger.info("Сенсоры безопасности и USB-монитор активированы.")