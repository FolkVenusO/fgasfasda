import time
import asyncio
import logging
import psutil
from pynput import mouse, keyboard
from core.state import state
from config import MAIN_ADMINS

logger = logging.getLogger(__name__)

async def send_alarm_alert():
    """Рассылка тревоги владельцам."""
    if not state.bot_client: return
    for adm in MAIN_ADMINS:
        try:
            await state.bot_client.send_message(
                int(adm), "🚨 **ВНИМАНИЕ! КТО-ТО ЗА КОМПОМ!** 🚨\nЗафиксирована физическая активность!"
            )
        except Exception: pass

def on_physical_activity(*args, **kwargs):
    if state.security_mode:
        curr = time.time()
        if curr - state.last_alarm_time > state.alarm_cooldown:
            state.last_alarm_time = curr
            if state.bot_loop and state.bot_client:
                asyncio.run_coroutine_threadsafe(send_alarm_alert(), state.bot_loop)

def start_usb_monitor():
    """
    Фоновый монитор подключения USB-накопителей.
    
    ✅ ОПТИМИЗИРОВАНО: Использует WMI события вместо постоянного опроса
    - Нулевое потребление CPU в режиме ожидания
    - Моментальная реакция на подключение USB
    - Fallback на polling если WMI недоступен
    """
    
    def _watcher_thread():
        """WMI watcher в отдельном потоке (синхронный)."""
        try:
            import wmi
            import pythoncom
            
            pythoncom.CoInitialize()
            try:
                c = wmi.WMI()
                
                # Подписываемся на события подключения дисков
                watcher = c.watch_for(
                    notification_type="Creation",
                    wmi_class="Win32_LogicalDisk",
                    delay_secs=1
                )
                
                logger.info("✅ USB монитор через WMI запущен (событийная модель)")
                
                while True:
                    try:
                        new_disk = watcher()
                        drive_letter = new_disk.DeviceID
                        drive_type = new_disk.DriveType
                        
                        # DriveType 2 = Removable (USB флешки)
                        if drive_type == 2:
                            # Отправляем уведомление асинхронно
                            if state.bot_loop and state.bot_client:
                                async def _send():
                                    for adm in MAIN_ADMINS:
                                        try:
                                            await state.bot_client.send_message(
                                                int(adm), 
                                                f"🔌 **АХТУНГ!** Подключена USB флешка: `{drive_letter}`"
                                            )
                                        except:
                                            pass
                                
                                asyncio.run_coroutine_threadsafe(_send(), state.bot_loop)
                    
                    except Exception as e:
                        logger.debug(f"WMI watcher error: {e}")
                        time.sleep(1)
                        
            except Exception as e:
                logger.warning(f"⚠️ WMI monitor failed ({type(e).__name__}), fallback to polling")
                # Если WMI не работает, запускаем polling
                if state.bot_loop:
                    asyncio.run_coroutine_threadsafe(_monitor_polling(), state.bot_loop)
            finally:
                try:
                    pythoncom.CoUninitialize()
                except:
                    pass
                
        except (ImportError, Exception) as e:
            logger.warning(f"⚠️ WMI недоступен ({type(e).__name__}), переключаюсь на polling режим")
            # Fallback на старый метод
            if state.bot_loop:
                asyncio.run_coroutine_threadsafe(_monitor_polling(), state.bot_loop)
    
    
    async def _monitor_polling():
        """Fallback: мониторинг через опрос (если WMI не работает)."""
        logger.info("USB монитор через polling запущен (опрос каждые 5 сек)")
        
        known_drives = set()
        try:
            known_drives = {d.device for d in psutil.disk_partitions()}
        except:
            pass

        while True:
            await asyncio.sleep(5)
            try:
                current_drives = {d.device for d in psutil.disk_partitions()}
                new_drives = current_drives - known_drives
                
                for d in new_drives:
                    for adm in MAIN_ADMINS:
                        try:
                            await state.bot_client.send_message(
                                int(adm), 
                                f"🔌 **АХТУНГ!** Подключен новый диск/флешка: `{d}`"
                            )
                        except:
                            pass
                
                known_drives = current_drives
            except Exception:
                pass
    
    # Пробуем запустить WMI watcher в отдельном потоке
    try:
        import threading
        wmi_thread = threading.Thread(target=_watcher_thread, daemon=True)
        wmi_thread.start()
    except Exception as e:
        logger.error(f"Failed to start WMI thread: {e}")
        # Fallback на polling
        if state.bot_loop:
            asyncio.run_coroutine_threadsafe(_monitor_polling(), state.bot_loop)

def start_sensors():
    """Запуск фоновых сенсоров."""
    mouse.Listener(on_move=on_physical_activity, on_click=on_physical_activity).start()
    keyboard.Listener(on_press=on_physical_activity).start()
    start_usb_monitor()
    logger.info("Сенсоры безопасности и USB-монитор активированы.")