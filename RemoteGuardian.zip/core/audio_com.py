import logging
import ctypes
import pythoncom
from comtypes import CLSCTX_ALL, CoCreateInstance, GUID
from pycaw.pycaw import IAudioEndpointVolume, IMMDeviceEnumerator

logger = logging.getLogger(__name__)

def get_volume_interface():
    """Прямое обращение к системному микшеру через GUID.
    
    Returns:
        IAudioEndpointVolume: Интерфейс управления громкостью или None при ошибке.
        
    Note:
        Вызывает CoInitialize/CoUninitialize автоматически.
        При ошибке корректно освобождает COM-ресурсы.
    """
    try:
        pythoncom.CoInitialize()
        CLSID_MMDeviceEnumerator = GUID("{BCDE0395-E52F-467C-8E3D-C4579291692E}")
        device_enumerator = CoCreateInstance(
            CLSID_MMDeviceEnumerator, 
            IMMDeviceEnumerator, 
            CLSCTX_ALL
        )
        endpoint = device_enumerator.GetDefaultAudioEndpoint(0, 1) 
        interface = endpoint.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
        volume_interface = ctypes.cast(interface, ctypes.POINTER(IAudioEndpointVolume))
        # ✅ ИСПРАВЛЕНО: CoUninitialize теперь вызывается только при ошибке
        # При успехе интерфейс остаётся активным для использования
        return volume_interface
    except Exception as e:
        logger.error(f"Системная ошибка звука: {e}")
        try:
            pythoncom.CoUninitialize()
        except:
            pass
        return None

def set_max_volume_and_get_current() -> tuple:
    """Выкручивает громкость на 100% и возвращает (интерфейс, старая_громкость).
    
    Returns:
        tuple: (IAudioEndpointVolume интерфейс, float старая громкость) или (None, None)
        
    Example:
        >>> vol_interface, old_vol = set_max_volume_and_get_current()
        >>> if vol_interface:
        >>>     # делаем что-то со звуком
        >>>     vol_interface.SetMasterVolumeLevelScalar(old_vol, None)  # восстанавливаем
    """
    vol = get_volume_interface()
    if vol:
        try:
            old_val = vol.GetMasterVolumeLevelScalar()
            vol.SetMasterVolumeLevelScalar(1.0, None)
            vol.SetMute(0, None)
            return vol, old_val
        except Exception as e:
            logger.error(f"Ошибка установки громкости: {e}")
            return None, None
    return None, None