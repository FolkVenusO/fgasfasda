import logging
import ctypes
import pythoncom
from comtypes import CLSCTX_ALL, CoCreateInstance, GUID
from pycaw.pycaw import IAudioEndpointVolume, IMMDeviceEnumerator

logger = logging.getLogger(__name__)

def get_volume_interface():
    """Прямое обращение к системному микшеру через GUID."""
    try:
        pythoncom.CoInitialize()
        CLSID_MMDeviceEnumerator = GUID("{BCDE0395-E52F-467C-8E3D-C4579291692E}")
        device_enumerator = CoCreateInstance(
            CLSID_MMDeviceEnumerator, 
            IMMDeviceEnumerator, 
            CLSCTX_ALL
        )
        endpoint = device_enumerator.GetDefaultAudioEndpoint(0, 1) 
        interface = endpoint.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
        return ctypes.cast(interface, ctypes.POINTER(IAudioEndpointVolume))
    except Exception as e:
        logger.error(f"Системная ошибка звука: {e}")
        pythoncom.CoUninitialize()
        return None

def set_max_volume_and_get_current() -> tuple:
    """Выкручивает громкость на 100% и возвращает (интерфейс, старая_громкость)."""
    vol = get_volume_interface()
    if vol:
        old_val = vol.GetMasterVolumeLevelScalar()
        vol.SetMasterVolumeLevelScalar(1.0, None)
        vol.SetMute(0, None)
        return vol, old_val
    return None, None