# 🔨 Remote Guardian - Инструкции по сборке

## 📦 Создание standalone .exe файла

### Вариант 1: Быстрая сборка (рекомендуется)

```bash
# 1. Установи PyInstaller
pip install pyinstaller

# 2. Собери .exe файл
pyinstaller guardian_optimized.spec
```

**Результат:** `dist/RemoteGuardian.exe` - один файл, готовый к использованию!

---

### Вариант 2: Ручная сборка

```bash
pyinstaller --onefile --name RemoteGuardian ^
    --add-data "assets;assets" ^
    --add-data ".env;." ^
    --add-binary "ffmpeg.exe;." ^
    --hidden-import telethon ^
    --hidden-import psutil ^
    --hidden-import cv2 ^
    --hidden-import pygame ^
    --hidden-import pynput ^
    --exclude-module matplotlib ^
    --exclude-module tkinter ^
    --console ^
    --upx-dir "C:\upx" ^
    main.py
```

---

### Вариант 3: Folder-based (быстрее запускается)

Измени в `guardian_optimized.spec`:

```python
# Раскомментируй в конце файла:
coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='RemoteGuardian',
)
```

---

## ⚡ Оптимизация размера .exe

### 1. UPX Compression (уменьшает размер на 30-50%)

```bash
# Скачай UPX: https://upx.github.io/
# Распакуй в C:\upx\

# PyInstaller автоматически использует UPX если он есть
pyinstaller guardian_optimized.spec
```

### 2. Исключение ненужных библиотек

В `guardian_optimized.spec` уже настроено:
- ❌ Исключены: matplotlib, numpy.testing, pytest, unittest, tkinter
- ✅ Включены: только необходимые модули

### 3. Виртуальное окружение (чистая сборка)

```bash
# Создай чистое окружение
python -m venv venv_build
venv_build\Scripts\activate

# Установи только необходимое
pip install -r requirements.txt

# Собери
pyinstaller guardian_optimized.spec

# Деактивируй
deactivate
```

---

## 🎯 Размеры файлов

| Вариант | Размер | Запуск | Рекомендация |
|---------|--------|--------|--------------|
| **Onefile (без UPX)** | ~80-120 MB | 5-10 сек | Для распространения |
| **Onefile (с UPX)** | ~40-60 MB | 5-10 сек | ✅ **Лучший вариант** |
| **Folder-based** | ~100-150 MB | 1-3 сек | Для личного использования |

---

## 🐛 Решение проблем

### Ошибка: "Failed to execute script"

```bash
# Собери с консолью для отладки
pyinstaller guardian_optimized.spec --console
```

### Ошибка: "ModuleNotFoundError"

Добавь модуль в `guardian_optimized.spec`:

```python
hiddenimports=[
    'твой_модуль',
    # ...
]
```

### Ошибка: "ffmpeg.exe not found"

```bash
# Убедись что ffmpeg.exe в корне проекта
dir ffmpeg.exe

# Или измени путь в guardian_optimized.spec
binaries=[('путь/к/ffmpeg.exe', '.')],
```

---

## 📊 Тестирование производительности

### 1. Benchmark (перед оптимизацией)

```bash
python tmp_rovodev_performance_test.py
```

### 2. Benchmark (после оптимизации)

Замени функции на оптимизированные и запусти снова.

### 3. Сравнение

```bash
# Python скрипт
python main.py
# Время запуска: ~2-3 сек
# Потребление памяти: ~80-100 MB

# .exe файл
RemoteGuardian.exe
# Время запуска: ~5-8 сек (первый запуск)
# Потребление памяти: ~70-90 MB
```

---

## 🚀 Автоматическая сборка (опционально)

### build.bat

```batch
@echo off
echo ================================
echo Remote Guardian - Auto Build
echo ================================

echo [1/3] Cleaning old builds...
rmdir /s /q build dist 2>nul

echo [2/3] Building .exe...
pyinstaller guardian_optimized.spec

echo [3/3] Done!
echo.
echo File: dist\RemoteGuardian.exe
pause
```

Сохрани как `build.bat` и запускай двойным кликом!

---

## ✅ Финальная проверка

После сборки протестируй:

```bash
cd dist
RemoteGuardian.exe
```

Проверь:
- ✅ Бот запускается
- ✅ Логи пишутся в `logs/guardian.log`
- ✅ Команды работают
- ✅ Медиа загружаются
- ✅ Скриншоты создаются

---

## 📝 Примечания

1. **Антивирусы** могут блокировать .exe файл (false positive)
   - Добавь в исключения
   - Или создай цифровую подпись

2. **Первый запуск** .exe медленнее (распаковка)
   - Последующие запуски быстрее

3. **Обновление** - пересобери .exe после изменений кода

---

Готово! 🎉
