"""
Система умных уведомлений (триггеров) для Remote Guardian
Автоматический мониторинг системы и отправка алертов
"""

import asyncio
import psutil
import logging
from typing import Dict, Callable, Optional, Set
from datetime import datetime, timedelta
import json
import os

logger = logging.getLogger(__name__)

# Путь к конфигурации триггеров
TRIGGERS_CONFIG_FILE = "triggers_config.json"

# Глобальное состояние триггеров
_triggers_enabled = {}
_trigger_states = {}
_monitoring_task = None
_bot_client = None
_admin_ids = set()


class TriggerConfig:
    """Конфигурация триггера."""
    
    def __init__(self, name: str, enabled: bool = True, cooldown: int = 300):
        """
        Args:
            name: Название триггера
            enabled: Включен ли триггер
            cooldown: Время перед повторной отправкой (секунды)
        """
        self.name = name
        self.enabled = enabled
        self.cooldown = cooldown
        self.last_triggered = None
    
    def can_trigger(self) -> bool:
        """Проверяет можно ли сработать триггеру (учитывая cooldown)."""
        if not self.enabled:
            return False
        
        if self.last_triggered is None:
            return True
        
        elapsed = (datetime.now() - self.last_triggered).total_seconds()
        return elapsed >= self.cooldown
    
    def mark_triggered(self):
        """Отмечает что триггер сработал."""
        self.last_triggered = datetime.now()


# Конфигурация всех триггеров
TRIGGERS = {
    'high_cpu': TriggerConfig('high_cpu', enabled=True, cooldown=300),  # 5 минут
    'high_temp': TriggerConfig('high_temp', enabled=True, cooldown=600),  # 10 минут
    'low_disk': TriggerConfig('low_disk', enabled=True, cooldown=3600),  # 1 час
    'usb_connected': TriggerConfig('usb_connected', enabled=True, cooldown=10),  # 10 секунд
    'usb_disconnected': TriggerConfig('usb_disconnected', enabled=True, cooldown=10),
    'ip_changed': TriggerConfig('ip_changed', enabled=True, cooldown=60),  # 1 минута
    'login_detected': TriggerConfig('login_detected', enabled=False, cooldown=60),
    'battery_low': TriggerConfig('battery_low', enabled=True, cooldown=600),
}


def load_triggers_config():
    """Загружает конфигурацию триггеров из файла."""
    global TRIGGERS
    
    if not os.path.exists(TRIGGERS_CONFIG_FILE):
        save_triggers_config()
        return
    
    try:
        with open(TRIGGERS_CONFIG_FILE, 'r', encoding='utf-8') as f:
            config = json.load(f)
        
        for trigger_name, data in config.items():
            if trigger_name in TRIGGERS:
                TRIGGERS[trigger_name].enabled = data.get('enabled', True)
                TRIGGERS[trigger_name].cooldown = data.get('cooldown', 300)
        
        logger.info(f"Loaded triggers config: {len(config)} triggers")
        
    except Exception as e:
        logger.error(f"Error loading triggers config: {e}")


def save_triggers_config():
    """Сохраняет конфигурацию триггеров в файл."""
    try:
        config = {}
        for name, trigger in TRIGGERS.items():
            config[name] = {
                'enabled': trigger.enabled,
                'cooldown': trigger.cooldown
            }
        
        with open(TRIGGERS_CONFIG_FILE, 'w', encoding='utf-8') as f:
            json.dump(config, f, indent=2, ensure_ascii=False)
        
        logger.info(f"Saved triggers config: {len(config)} triggers")
        
    except Exception as e:
        logger.error(f"Error saving triggers config: {e}")


def set_trigger_enabled(trigger_name: str, enabled: bool):
    """
    Включает/выключает триггер.
    
    Args:
        trigger_name: Имя триггера
        enabled: Включить или выключить
    """
    if trigger_name in TRIGGERS:
        TRIGGERS[trigger_name].enabled = enabled
        save_triggers_config()
        logger.info(f"Trigger '{trigger_name}' set to {enabled}")


def get_trigger_status() -> Dict[str, bool]:
    """
    Получает статус всех триггеров.
    
    Returns:
        dict: {trigger_name: enabled}
    """
    return {name: trigger.enabled for name, trigger in TRIGGERS.items()}


async def send_alert(message: str, trigger_name: str = None):
    """
    Отправляет алерт всем администраторам.
    
    Args:
        message: Текст сообщения
        trigger_name: Имя сработавшего триггера
    """
    if not _bot_client or not _admin_ids:
        logger.warning("Bot client or admin IDs not set, cannot send alert")
        return
    
    # Проверяем cooldown
    if trigger_name and trigger_name in TRIGGERS:
        trigger = TRIGGERS[trigger_name]
        if not trigger.can_trigger():
            logger.debug(f"Trigger '{trigger_name}' in cooldown, skipping alert")
            return
        
        trigger.mark_triggered()
    
    # Отправляем всем администраторам
    for admin_id in _admin_ids:
        try:
            await _bot_client.send_message(admin_id, message)
        except Exception as e:
            logger.error(f"Error sending alert to {admin_id}: {e}")


# === МОНИТОРИНГ CPU ===

async def monitor_cpu():
    """Мониторинг высокой загрузки CPU."""
    threshold = 90  # Процент
    duration = 300  # 5 минут
    
    high_cpu_start = None
    
    while True:
        try:
            cpu_percent = psutil.cpu_percent(interval=5)
            
            if cpu_percent > threshold:
                if high_cpu_start is None:
                    high_cpu_start = datetime.now()
                else:
                    # Проверяем сколько времени CPU загружен
                    elapsed = (datetime.now() - high_cpu_start).total_seconds()
                    if elapsed >= duration:
                        # Получаем топ процессы
                        top_procs = sorted(
                            [p for p in psutil.process_iter(['name', 'cpu_percent'])],
                            key=lambda p: p.info.get('cpu_percent', 0) or 0,
                            reverse=True
                        )[:3]
                        
                        procs_text = "\n".join([
                            f"• {p.info['name']}: {p.info.get('cpu_percent', 0):.1f}%"
                            for p in top_procs
                        ])
                        
                        message = (
                            f"🔥 **ВЫСОКАЯ ЗАГРУЗКА CPU**\n\n"
                            f"**Загрузка:** {cpu_percent:.1f}%\n"
                            f"**Длительность:** {elapsed/60:.1f} минут\n\n"
                            f"**Топ процессов:**\n{procs_text}\n\n"
                            f"⚠️ CPU перегружен дольше 5 минут!"
                        )
                        
                        await send_alert(message, 'high_cpu')
                        high_cpu_start = None  # Сбрасываем
            else:
                high_cpu_start = None
            
            await asyncio.sleep(10)  # Проверка каждые 10 секунд
            
        except Exception as e:
            logger.error(f"Error in CPU monitor: {e}")
            await asyncio.sleep(30)


# === МОНИТОРИНГ ТЕМПЕРАТУРЫ ===

async def monitor_temperature():
    """Мониторинг высокой температуры."""
    threshold = 85  # Градусы Цельсия
    
    while True:
        try:
            temps = {}
            
            # Попытка получить температуры
            try:
                if hasattr(psutil, 'sensors_temperatures'):
                    sensor_temps = psutil.sensors_temperatures()
                    if sensor_temps:
                        for name, entries in sensor_temps.items():
                            for entry in entries:
                                if 'cpu' in name.lower() or 'core' in entry.label.lower():
                                    temps['CPU'] = entry.current
            except:
                pass
            
            # Проверка через WMI
            if not temps:
                try:
                    import wmi
                    w = wmi.WMI(namespace="root\\OpenHardwareMonitor")
                    sensors = w.Sensor()
                    for s in sensors:
                        if s.SensorType == 'Temperature' and 'cpu' in s.Name.lower():
                            temps['CPU'] = s.Value
                            break
                except:
                    pass
            
            # Проверяем температуры
            for component, temp in temps.items():
                if temp > threshold:
                    message = (
                        f"🌡️ **ВЫСОКАЯ ТЕМПЕРАТУРА**\n\n"
                        f"**Компонент:** {component}\n"
                        f"**Температура:** {temp:.1f}°C\n"
                        f"**Порог:** {threshold}°C\n\n"
                        f"⚠️ Рекомендуется проверить охлаждение!"
                    )
                    
                    await send_alert(message, 'high_temp')
            
            await asyncio.sleep(60)  # Проверка каждую минуту
            
        except Exception as e:
            logger.error(f"Error in temperature monitor: {e}")
            await asyncio.sleep(120)


# === МОНИТОРИНГ СВОБОДНОГО МЕСТА ===

async def monitor_disk_space():
    """Мониторинг свободного места на диске."""
    threshold = 10  # Процент свободного места
    
    while True:
        try:
            for partition in psutil.disk_partitions():
                try:
                    usage = psutil.disk_usage(partition.mountpoint)
                    free_percent = 100 - usage.percent
                    
                    if free_percent < threshold:
                        message = (
                            f"💾 **МАЛО СВОБОДНОГО МЕСТА**\n\n"
                            f"**Диск:** {partition.device}\n"
                            f"**Свободно:** {usage.free / (1024**3):.1f} GB ({free_percent:.1f}%)\n"
                            f"**Занято:** {usage.used / (1024**3):.1f} GB ({usage.percent:.1f}%)\n\n"
                            f"⚠️ Освободите место на диске!"
                        )
                        
                        await send_alert(message, 'low_disk')
                except:
                    pass
            
            await asyncio.sleep(3600)  # Проверка каждый час
            
        except Exception as e:
            logger.error(f"Error in disk monitor: {e}")
            await asyncio.sleep(3600)


# === МОНИТОРИНГ USB УСТРОЙСТВ ===

_usb_devices = set()

async def monitor_usb():
    """Мониторинг подключения/отключения USB устройств."""
    global _usb_devices
    
    # Инициализация - получаем текущие устройства
    try:
        current = set(p.device for p in psutil.disk_partitions() if 'removable' in p.opts.lower())
        _usb_devices = current
    except:
        _usb_devices = set()
    
    while True:
        try:
            current = set(p.device for p in psutil.disk_partitions() if 'removable' in p.opts.lower())
            
            # Новые устройства (подключены)
            connected = current - _usb_devices
            for device in connected:
                message = (
                    f"🔌 **USB УСТРОЙСТВО ПОДКЛЮЧЕНО**\n\n"
                    f"**Устройство:** {device}\n"
                    f"**Время:** {datetime.now().strftime('%H:%M:%S')}"
                )
                await send_alert(message, 'usb_connected')
            
            # Удалённые устройства (отключены)
            disconnected = _usb_devices - current
            for device in disconnected:
                message = (
                    f"🔌 **USB УСТРОЙСТВО ОТКЛЮЧЕНО**\n\n"
                    f"**Устройство:** {device}\n"
                    f"**Время:** {datetime.now().strftime('%H:%M:%S')}"
                )
                await send_alert(message, 'usb_disconnected')
            
            _usb_devices = current
            
            await asyncio.sleep(5)  # Проверка каждые 5 секунд
            
        except Exception as e:
            logger.error(f"Error in USB monitor: {e}")
            await asyncio.sleep(10)


# === МОНИТОРИНГ IP АДРЕСА ===

_current_ip = None

async def monitor_ip_change():
    """Мониторинг смены внешнего IP адреса."""
    global _current_ip
    
    while True:
        try:
            import aiohttp
            
            async with aiohttp.ClientSession() as session:
                async with session.get('https://api.ipify.org?format=json', timeout=10) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        new_ip = data.get('ip')
                        
                        if _current_ip is None:
                            _current_ip = new_ip
                        elif new_ip != _current_ip:
                            message = (
                                f"🌐 **СМЕНА IP АДРЕСА**\n\n"
                                f"**Старый IP:** {_current_ip}\n"
                                f"**Новый IP:** {new_ip}\n"
                                f"**Время:** {datetime.now().strftime('%H:%M:%S')}\n\n"
                                f"💡 Возможна смена сети или VPN"
                            )
                            
                            await send_alert(message, 'ip_changed')
                            _current_ip = new_ip
            
            await asyncio.sleep(300)  # Проверка каждые 5 минут
            
        except Exception as e:
            logger.error(f"Error in IP monitor: {e}")
            await asyncio.sleep(600)


# === ГЛАВНЫЙ МОНИТОРИНГ ===

async def start_monitoring(bot_client, admin_ids: Set[int]):
    """
    Запускает систему мониторинга.
    
    Args:
        bot_client: Telegram bot client
        admin_ids: Set ID администраторов для отправки алертов
    """
    global _bot_client, _admin_ids, _monitoring_task
    
    _bot_client = bot_client
    _admin_ids = admin_ids
    
    # Загружаем конфигурацию
    load_triggers_config()
    
    # Запускаем все мониторы
    monitors = [
        monitor_cpu(),
        monitor_temperature(),
        monitor_disk_space(),
        monitor_usb(),
        monitor_ip_change(),
    ]
    
    _monitoring_task = asyncio.gather(*monitors, return_exceptions=True)
    
    logger.info("Trigger monitoring system started")


async def stop_monitoring():
    """Останавливает систему мониторинга."""
    global _monitoring_task
    
    if _monitoring_task:
        _monitoring_task.cancel()
        try:
            await _monitoring_task
        except asyncio.CancelledError:
            pass
        
        _monitoring_task = None
    
    logger.info("Trigger monitoring system stopped")
