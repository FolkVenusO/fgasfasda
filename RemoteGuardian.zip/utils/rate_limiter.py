"""
Rate Limiter для защиты от спама команд
Предотвращает DoS атаки через частые запросы
"""

import time
import asyncio
from collections import defaultdict, deque
from typing import Optional

class RateLimiter:
    """
    Простой rate limiter на основе sliding window.
    
    Использование:
        limiter = RateLimiter(max_calls=5, window=60)  # 5 вызовов в минуту
        
        if limiter.check_rate_limit(user_id):
            # выполнить действие
        else:
            # отказать
    """
    
    def __init__(self, max_calls: int = 10, window: int = 60):
        """
        Args:
            max_calls: Максимальное количество вызовов
            window: Временное окно в секундах
        """
        self.max_calls = max_calls
        self.window = window
        self.calls = defaultdict(deque)
        self._lock = asyncio.Lock()
    
    async def check_rate_limit_async(self, user_id: str) -> tuple[bool, Optional[int]]:
        """
        Проверяет rate limit для пользователя (async).
        
        Returns:
            tuple: (разрешено ли, секунд до сброса или None)
        """
        async with self._lock:
            now = time.time()
            user_calls = self.calls[user_id]
            
            # Удаляем устаревшие записи
            while user_calls and user_calls[0] < now - self.window:
                user_calls.popleft()
            
            # Проверяем лимит
            if len(user_calls) >= self.max_calls:
                # Вычисляем время до сброса
                oldest_call = user_calls[0]
                wait_time = int(self.window - (now - oldest_call)) + 1
                return False, wait_time
            
            # Добавляем новый вызов
            user_calls.append(now)
            return True, None
    
    def check_rate_limit(self, user_id: str) -> tuple[bool, Optional[int]]:
        """
        Проверяет rate limit для пользователя (sync).
        
        Returns:
            tuple: (разрешено ли, секунд до сброса или None)
        """
        now = time.time()
        user_calls = self.calls[user_id]
        
        # Удаляем устаревшие записи
        while user_calls and user_calls[0] < now - self.window:
            user_calls.popleft()
        
        # Проверяем лимит
        if len(user_calls) >= self.max_calls:
            oldest_call = user_calls[0]
            wait_time = int(self.window - (now - oldest_call)) + 1
            return False, wait_time
        
        # Добавляем новый вызов
        user_calls.append(now)
        return True, None
    
    def reset(self, user_id: str):
        """Сбрасывает лимит для пользователя."""
        if user_id in self.calls:
            del self.calls[user_id]


# Глобальные rate limiters для разных типов команд
command_limiter = RateLimiter(max_calls=30, window=60)  # 30 команд в минуту
dangerous_limiter = RateLimiter(max_calls=10, window=60)  # 10 опасных команд в минуту
screenshot_limiter = RateLimiter(max_calls=20, window=60)  # 20 скриншотов в минуту
ai_limiter = RateLimiter(max_calls=15, window=60)  # 15 AI запросов в минуту


def with_rate_limit(limiter: RateLimiter, error_message: str = "⏱ Слишком частые запросы. Подожди {wait} сек."):
    """
    Декоратор для добавления rate limiting к команде.
    
    Args:
        limiter: Экземпляр RateLimiter
        error_message: Сообщение при превышении лимита (может содержать {wait})
    
    Example:
        @with_rate_limit(dangerous_limiter)
        @with_verify("Shutdown", dangerous=True)
        async def shutdown(event):
            ...
    """
    def decorator(func):
        async def wrapper(event, *args, **kwargs):
            user_id = str(event.sender_id)
            allowed, wait_time = await limiter.check_rate_limit_async(user_id)
            
            if not allowed:
                msg = error_message.format(wait=wait_time)
                await event.reply(msg)
                return
            
            return await func(event, *args, **kwargs)
        
        wrapper.__name__ = func.__name__
        wrapper.__doc__ = func.__doc__
        return wrapper
    return decorator
