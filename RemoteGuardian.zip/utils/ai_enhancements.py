"""
Расширенный AI функционал для Remote Guardian
Улучшенная интеграция с Google Gemini
"""

import os
import re
import logging
from typing import Optional, List, Dict, Tuple
from collections import deque

logger = logging.getLogger(__name__)

# Контекст сессий для каждого пользователя (память диалога)
_user_contexts = {}
_max_context_messages = 10  # Храним последние 10 сообщений


class AISession:
    """Сессия AI диалога для пользователя."""
    
    def __init__(self, user_id: str):
        self.user_id = user_id
        self.messages = deque(maxlen=_max_context_messages)
        self.system_info = {}
    
    def add_message(self, role: str, content: str):
        """Добавляет сообщение в контекст."""
        self.messages.append({'role': role, 'content': content})
    
    def get_context(self) -> List[Dict[str, str]]:
        """Возвращает весь контекст диалога."""
        return list(self.messages)
    
    def clear(self):
        """Очищает контекст."""
        self.messages.clear()
    
    def update_system_info(self, info: dict):
        """Обновляет информацию о системе."""
        self.system_info.update(info)


def get_or_create_session(user_id: str) -> AISession:
    """Получает или создаёт AI сессию для пользователя."""
    if user_id not in _user_contexts:
        _user_contexts[user_id] = AISession(user_id)
    return _user_contexts[user_id]


def clear_session(user_id: str):
    """Очищает сессию пользователя."""
    if user_id in _user_contexts:
        _user_contexts[user_id].clear()


def detect_language(text: str) -> str:
    """
    Определяет язык текста (русский или английский).
    
    Returns:
        str: 'ru' или 'en'
    """
    # Простая эвристика: если есть кириллица - русский
    cyrillic_pattern = re.compile('[а-яА-ЯёЁ]')
    if cyrillic_pattern.search(text):
        return 'ru'
    return 'en'


def extract_commands_advanced(text: str) -> List[str]:
    """
    Улучшенный парсер команд из ответа AI.
    
    Поддерживает форматы:
    - [COMMAND:/screenshot]
    - [CMD:/sysinfo]
    - [EXECUTE:/ps]
    - /screenshot (в начале строки)
    
    Returns:
        List[str]: Список команд без префикса /
    """
    commands = []
    
    # Паттерн 1: [COMMAND:/xxx] или [CMD:/xxx] или [EXECUTE:/xxx]
    pattern1 = re.findall(r'\[(?:COMMAND|CMD|EXECUTE):(/[a-z_\-]+(?:\s+[^\]]*)?)\]', text, re.IGNORECASE)
    commands.extend(pattern1)
    
    # Паттерн 2: Команды в начале строки или после переноса
    pattern2 = re.findall(r'(?:^|\n)(/[a-z_\-]+(?:\s+[^\n]*)?)', text, re.MULTILINE)
    commands.extend(pattern2)
    
    # Удаляем дубликаты, сохраняя порядок
    seen = set()
    unique_commands = []
    for cmd in commands:
        cmd_clean = cmd.strip()
        if cmd_clean not in seen:
            seen.add(cmd_clean)
            unique_commands.append(cmd_clean)
    
    return unique_commands


def build_system_prompt(language: str = 'ru', include_context: bool = True) -> str:
    """
    Строит системный промпт для Gemini.
    
    Args:
        language: Язык ответа ('ru' или 'en')
        include_context: Включать ли контекст о командах
        
    Returns:
        str: Системный промпт
    """
    if language == 'ru':
        base_prompt = """Ты - AI-ассистент для удалённого управления Windows компьютером через Telegram бот "Remote Guardian".

Твои возможности:
- Анализировать скриншоты экрана
- Отвечать на вопросы о системе
- Выполнять команды бота
- Помогать пользователю управлять компьютером

Отвечай кратко, по делу, на русском языке. Используй эмодзи для наглядности."""
    else:
        base_prompt = """You are an AI assistant for remote Windows PC management via "Remote Guardian" Telegram bot.

Your capabilities:
- Analyze screenshots
- Answer questions about the system
- Execute bot commands
- Help user manage their computer

Answer concisely and use emojis for clarity."""
    
    if include_context:
        commands_list = """

📋 Доступные команды (можешь использовать в ответе):

🖥 **СИСТЕМА:**
/sysinfo - детальная информация
/ps - список процессов  
/temp - температуры
/disk - диски
/status - краткий статус

👁 **МОНИТОРИНГ:**
/screenshot - скриншот экрана
/webcam - фото с камеры
/mic [сек] - запись микрофона

⚡ **УПРАВЛЕНИЕ:**
/shutdown - выключить
/restart - перезагрузить
/lock - заблокировать
/vol [0-100] - громкость

📁 **ФАЙЛЫ:**
/ls [путь] - файловый менеджер
/open <URL> - открыть ссылку

🌐 **СЕТЬ:**
/ip - внешний IP
/speedtest - тест скорости
/netstat - соединения

🎬 **МЕДИА:**
/media - медиатека
/say <текст> - озвучить TTS

Чтобы выполнить команду, добавь в ответ:
[COMMAND:/название_команды]

Пример: "Делаю скриншот! [COMMAND:/screenshot]"
Можно несколько: [COMMAND:/screenshot] [COMMAND:/sysinfo]
"""
        
        base_prompt += commands_list
    
    return base_prompt


def build_enhanced_prompt(
    question: str,
    system_info: dict = None,
    context: List[Dict[str, str]] = None,
    language: str = 'ru'
) -> str:
    """
    Строит улучшенный промпт с контекстом.
    
    Args:
        question: Вопрос пользователя
        system_info: Информация о системе
        context: История диалога
        language: Язык
        
    Returns:
        str: Полный промпт
    """
    prompt = build_system_prompt(language, include_context=True)
    
    # Добавляем информацию о системе
    if system_info:
        prompt += "\n\n📊 **Текущее состояние системы:**\n"
        for key, value in system_info.items():
            prompt += f"• {key}: {value}\n"
    
    # Добавляем контекст диалога
    if context and len(context) > 0:
        prompt += "\n\n💬 **История диалога:**\n"
        for msg in context[-5:]:  # Последние 5 сообщений
            role = "Пользователь" if msg['role'] == 'user' else "Ассистент"
            prompt += f"{role}: {msg['content'][:100]}...\n"
    
    # Добавляем текущий вопрос
    prompt += f"\n\n❓ **Текущий запрос:** {question}\n"
    
    return prompt


def parse_ai_response(response_text: str) -> Tuple[str, List[str]]:
    """
    Парсит ответ AI и извлекает команды.
    
    Returns:
        tuple: (очищенный текст ответа, список команд)
    """
    # Извлекаем команды
    commands = extract_commands_advanced(response_text)
    
    # Убираем теги команд из текста
    clean_text = response_text
    clean_text = re.sub(r'\[(?:COMMAND|CMD|EXECUTE):[^\]]+\]', '', clean_text)
    clean_text = clean_text.strip()
    
    return clean_text, commands


def is_special_question(question: str) -> Optional[str]:
    """
    Проверяет специальные вопросы (например, про любовь к Рамазану).
    
    Returns:
        Optional[str]: Специальный ответ или None
    """
    question_lower = question.lower()
    
    # Вопросы про любовь
    love_keywords = ['любит', 'люблю', 'любовь', 'нравлюсь', 'нравится', 'рамазан']
    if any(keyword in question_lower for keyword in love_keywords):
        import random
        compliments = [
            "💕 Конечно любит! Ты же невероятная! ✨",
            "💖 Да, безусловно! Ты самая прекрасная!",
            "👑 100%! Ты же богиня!",
            "⭐ Безумно любит! Ты же сияешь как звезда!",
            "✨💕 Ещё как! Ты просто волшебная!",
            "💯 Да! Ты же идеальна во всём!",
            "🌸 Конечно! Ты украшаешь этот мир!",
            "😍 Да, и он счастливчик! Ты великолепна!",
        ]
        return random.choice(compliments)
    
    return None


def should_take_screenshot(question: str) -> bool:
    """
    Определяет, нужен ли скриншот для ответа на вопрос.
    
    Returns:
        bool: True если нужен скриншот
    """
    screenshot_keywords = [
        'вижу', 'видишь', 'экран', 'делаю', 'делаешь', 'открыт',
        'что на экране', 'что происходит', 'покажи', 'смотрю',
        'работаю', 'программа', 'приложение', 'окно', 'браузер',
        'screen', 'see', 'show', 'display', 'what am i', 'what is'
    ]
    
    question_lower = question.lower()
    return any(keyword in question_lower for keyword in screenshot_keywords)


def sanitize_ai_output(text: str) -> str:
    """
    Очищает вывод AI от потенциально опасного контента.
    
    Returns:
        str: Безопасный текст
    """
    # Удаляем потенциальные скрипты
    text = re.sub(r'<script[^>]*>.*?</script>', '', text, flags=re.IGNORECASE | re.DOTALL)
    
    # Ограничиваем длину
    if len(text) > 4000:
        text = text[:4000] + "\n\n... (сообщение обрезано)"
    
    return text


# Статистика использования AI
_ai_stats = {
    'total_requests': 0,
    'successful_requests': 0,
    'failed_requests': 0,
    'commands_executed': 0,
    'screenshots_analyzed': 0
}


def update_ai_stats(success: bool, commands_count: int = 0, screenshot_used: bool = False):
    """Обновляет статистику AI."""
    _ai_stats['total_requests'] += 1
    if success:
        _ai_stats['successful_requests'] += 1
    else:
        _ai_stats['failed_requests'] += 1
    
    _ai_stats['commands_executed'] += commands_count
    if screenshot_used:
        _ai_stats['screenshots_analyzed'] += 1


def get_ai_stats() -> dict:
    """Возвращает статистику AI."""
    return _ai_stats.copy()


def format_ai_stats() -> str:
    """Форматирует статистику AI для отображения."""
    stats = get_ai_stats()
    
    success_rate = 0
    if stats['total_requests'] > 0:
        success_rate = (stats['successful_requests'] / stats['total_requests']) * 100
    
    return f"""🤖 **Статистика AI (Google Gemini):**

📊 Всего запросов: {stats['total_requests']}
✅ Успешных: {stats['successful_requests']}
❌ Ошибок: {stats['failed_requests']}
📈 Успешность: {success_rate:.1f}%

⚙️ Команд выполнено: {stats['commands_executed']}
📸 Скриншотов проанализировано: {stats['screenshots_analyzed']}
"""
