import os
import logging

logger = logging.getLogger(__name__)

def safe_remove(filepath: str) -> None:
    """Безопасное удаление временных файлов без краша бота."""
    if os.path.exists(filepath):
        try:
            os.remove(filepath)
        except Exception as e:
            logger.error(f"Не удалось удалить файл {filepath}: {e}")