"""
Системный дашборд для Remote Guardian
Красивая визуализация состояния системы
"""

import psutil
import platform
import time
from datetime import datetime, timedelta
from typing import Dict, List, Tuple
import logging

logger = logging.getLogger(__name__)

# Кеш для uptime бота
_bot_start_time = None


def set_bot_start_time():
    """Устанавливает время запуска бота."""
    global _bot_start_time
    _bot_start_time = time.time()


def get_bot_uptime() -> str:
    """Возвращает время работы бота."""
    if _bot_start_time is None:
        return "N/A"
    
    uptime_seconds = int(time.time() - _bot_start_time)
    return format_uptime(uptime_seconds)


def format_uptime(seconds: int) -> str:
    """
    Форматирует uptime в читаемый вид.
    
    Args:
        seconds: Количество секунд
        
    Returns:
        str: Форматированное время (например, "2д 5ч 30м")
    """
    days = seconds // 86400
    hours = (seconds % 86400) // 3600
    minutes = (seconds % 3600) // 60
    
    parts = []
    if days > 0:
        parts.append(f"{days}д")
    if hours > 0:
        parts.append(f"{hours}ч")
    if minutes > 0 or len(parts) == 0:
        parts.append(f"{minutes}м")
    
    return " ".join(parts)


def create_progress_bar(percentage: float, length: int = 10, filled_char: str = "█", empty_char: str = "░") -> str:
    """
    Создаёт ASCII progress bar.
    
    Args:
        percentage: Процент заполнения (0-100)
        length: Длина полоски
        filled_char: Символ для заполненной части
        empty_char: Символ для пустой части
        
    Returns:
        str: ASCII progress bar
        
    Example:
        >>> create_progress_bar(75, 10)
        "████████░░"
    """
    filled_length = int(length * (percentage / 100))
    empty_length = length - filled_length
    
    return filled_char * filled_length + empty_char * empty_length


def get_color_emoji(percentage: float) -> str:
    """
    Возвращает цветной эмодзи в зависимости от процента.
    
    Args:
        percentage: Процент (0-100)
        
    Returns:
        str: Эмодзи (🟢 зелёный, 🟡 жёлтый, 🔴 красный)
    """
    if percentage < 60:
        return "🟢"
    elif percentage < 85:
        return "🟡"
    else:
        return "🔴"


def get_cpu_info() -> Dict[str, any]:
    """
    Собирает информацию о CPU.
    
    Returns:
        dict: Информация о CPU
    """
    try:
        cpu_percent = psutil.cpu_percent(interval=1)
        cpu_count = psutil.cpu_count(logical=True)
        cpu_freq = psutil.cpu_freq()
        
        return {
            'percent': cpu_percent,
            'count': cpu_count,
            'freq_current': cpu_freq.current if cpu_freq else 0,
            'freq_max': cpu_freq.max if cpu_freq else 0,
        }
    except Exception as e:
        logger.error(f"Error getting CPU info: {e}")
        return {'percent': 0, 'count': 0, 'freq_current': 0, 'freq_max': 0}


def get_memory_info() -> Dict[str, any]:
    """
    Собирает информацию о памяти.
    
    Returns:
        dict: Информация о RAM
    """
    try:
        mem = psutil.virtual_memory()
        
        return {
            'percent': mem.percent,
            'total_gb': mem.total / (1024**3),
            'used_gb': mem.used / (1024**3),
            'available_gb': mem.available / (1024**3),
        }
    except Exception as e:
        logger.error(f"Error getting memory info: {e}")
        return {'percent': 0, 'total_gb': 0, 'used_gb': 0, 'available_gb': 0}


def get_disk_info() -> Dict[str, any]:
    """
    Собирает информацию о диске C:\\.
    
    Returns:
        dict: Информация о диске
    """
    try:
        disk = psutil.disk_usage('C:\\')
        
        return {
            'percent': disk.percent,
            'total_gb': disk.total / (1024**3),
            'used_gb': disk.used / (1024**3),
            'free_gb': disk.free / (1024**3),
        }
    except Exception as e:
        logger.error(f"Error getting disk info: {e}")
        return {'percent': 0, 'total_gb': 0, 'used_gb': 0, 'free_gb': 0}


def get_network_speed() -> Dict[str, float]:
    """
    Получает текущую скорость сети (приблизительно).
    
    Returns:
        dict: {'download_mbps': float, 'upload_mbps': float}
    """
    try:
        # Первый замер
        net1 = psutil.net_io_counters()
        time.sleep(1)
        # Второй замер через 1 секунду
        net2 = psutil.net_io_counters()
        
        download_speed = (net2.bytes_recv - net1.bytes_recv) / (1024 * 1024)  # MB/s
        upload_speed = (net2.bytes_sent - net1.bytes_sent) / (1024 * 1024)  # MB/s
        
        return {
            'download_mbps': download_speed,
            'upload_mbps': upload_speed
        }
    except Exception as e:
        logger.error(f"Error getting network speed: {e}")
        return {'download_mbps': 0, 'upload_mbps': 0}


def get_temperatures() -> Dict[str, float]:
    """
    Получает температуры компонентов (если доступно).
    
    Returns:
        dict: Температуры (может быть пустым если нет датчиков)
    """
    try:
        temps = psutil.sensors_temperatures()
        
        if not temps:
            return {}
        
        result = {}
        
        # Ищем CPU температуру
        for name, entries in temps.items():
            for entry in entries:
                if 'cpu' in name.lower() or 'core' in entry.label.lower():
                    result['cpu'] = entry.current
                    break
            if 'cpu' in result:
                break
        
        return result
    except Exception as e:
        # sensors_temperatures может не работать на Windows
        return {}


def get_top_processes(limit: int = 5) -> List[Dict[str, any]]:
    """
    Получает топ процессов по использованию RAM.
    
    Args:
        limit: Количество процессов
        
    Returns:
        list: Список процессов [{'name': str, 'memory_mb': float, 'cpu_percent': float}, ...]
    """
    try:
        processes = []
        
        for proc in psutil.process_iter(['name', 'memory_info', 'cpu_percent']):
            try:
                info = proc.info
                memory_mb = info['memory_info'].rss / (1024 * 1024)
                cpu_percent = info['cpu_percent'] or 0
                
                processes.append({
                    'name': info['name'],
                    'memory_mb': memory_mb,
                    'cpu_percent': cpu_percent
                })
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        
        # Сортируем по использованию памяти
        processes.sort(key=lambda x: x['memory_mb'], reverse=True)
        
        return processes[:limit]
    except Exception as e:
        logger.error(f"Error getting top processes: {e}")
        return []


def get_system_uptime() -> str:
    """
    Получает время работы системы (uptime).
    
    Returns:
        str: Форматированное время работы
    """
    try:
        boot_time = psutil.boot_time()
        uptime_seconds = int(time.time() - boot_time)
        return format_uptime(uptime_seconds)
    except Exception as e:
        logger.error(f"Error getting system uptime: {e}")
        return "N/A"


def format_dashboard() -> str:
    """
    Создаёт форматированный дашборд с визуализацией.
    
    Returns:
        str: Красивый ASCII дашборд
    """
    # Собираем данные
    cpu = get_cpu_info()
    mem = get_memory_info()
    disk = get_disk_info()
    temps = get_temperatures()
    top_procs = get_top_processes(5)
    sys_uptime = get_system_uptime()
    bot_uptime = get_bot_uptime()
    
    # Создаём progress bars
    cpu_bar = create_progress_bar(cpu['percent'])
    mem_bar = create_progress_bar(mem['percent'])
    disk_bar = create_progress_bar(disk['percent'])
    
    # Цветные индикаторы
    cpu_emoji = get_color_emoji(cpu['percent'])
    mem_emoji = get_color_emoji(mem['percent'])
    disk_emoji = get_color_emoji(disk['percent'])
    
    # Формируем дашборд
    dashboard = f"""╭─────────────────────────────────────╮
│      🖥 **СИСТЕМНЫЙ ДАШБОРД**       │
╰─────────────────────────────────────╯

📊 **РЕСУРСЫ:**
{cpu_emoji} CPU:  `{cpu_bar}` **{cpu['percent']:.1f}%**
   └ Ядер: {cpu['count']} | Частота: {cpu['freq_current']:.0f} MHz

{mem_emoji} RAM:  `{mem_bar}` **{mem['percent']:.1f}%**
   └ {mem['used_gb']:.1f} GB / {mem['total_gb']:.1f} GB

{disk_emoji} Disk: `{disk_bar}` **{disk['percent']:.1f}%**
   └ {disk['used_gb']:.1f} GB / {disk['total_gb']:.1f} GB
"""

    # Добавляем температуру если доступна
    if 'cpu' in temps:
        temp_emoji = "🌡️" if temps['cpu'] < 75 else "🔥"
        dashboard += f"\n{temp_emoji} **Температура:** {temps['cpu']:.0f}°C\n"
    
    # Добавляем uptime
    dashboard += f"""
⏱️ **UPTIME:**
   └ Система: {sys_uptime}
   └ Бот: {bot_uptime}
"""
    
    # Добавляем топ процессов
    dashboard += "\n🔝 **ТОП ПРОЦЕССОВ:**\n"
    
    for i, proc in enumerate(top_procs, 1):
        mem_str = f"{proc['memory_mb']:.0f} MB" if proc['memory_mb'] < 1024 else f"{proc['memory_mb']/1024:.1f} GB"
        dashboard += f"   {i}. `{proc['name'][:20]}` - {mem_str}\n"
    
    # Время обновления
    now = datetime.now().strftime("%H:%M:%S")
    dashboard += f"\n🕐 Обновлено: {now}"
    
    return dashboard


def format_dashboard_compact() -> str:
    """
    Создаёт компактную версию дашборда (для быстрого просмотра).
    
    Returns:
        str: Компактный дашборд
    """
    cpu = get_cpu_info()
    mem = get_memory_info()
    disk = get_disk_info()
    
    cpu_emoji = get_color_emoji(cpu['percent'])
    mem_emoji = get_color_emoji(mem['percent'])
    disk_emoji = get_color_emoji(disk['percent'])
    
    return f"""{cpu_emoji} CPU: **{cpu['percent']:.1f}%** | {mem_emoji} RAM: **{mem['percent']:.1f}%** | {disk_emoji} Disk: **{disk['percent']:.1f}%**"""


async def get_network_speed_async() -> Dict[str, float]:
    """
    Асинхронная версия получения скорости сети.
    
    Returns:
        dict: {'download_mbps': float, 'upload_mbps': float}
    """
    import asyncio
    return await asyncio.to_thread(get_network_speed)
