"""
Валидаторы безопасности для Remote Guardian
Защита от опасных команд и path traversal
"""

import os
import re
from typing import Optional

# Черный список команд CMD (опасные команды)
CMD_BLACKLIST = {
    'format', 'del /s', 'rd /s', 'rmdir /s',
    'shutdown /s /f /t 0', 'reg delete',
    'bcdedit', 'diskpart', 'cipher /w',
    'net user', 'net localgroup administrators',
    'schtasks /create', 'wmic',
    'powershell -encodedcommand', 'powershell -enc',
    '>nul', 'start /min'  # Скрытое выполнение
}

# Белый список безопасных команд
CMD_WHITELIST = {
    'dir', 'cd', 'echo', 'type', 'tree', 'find',
    'ipconfig', 'ping', 'tracert', 'netstat',
    'tasklist', 'systeminfo', 'whoami', 'hostname',
    'date', 'time', 'ver', 'where', 'help'
}

# Критические процессы которые нельзя убивать
PROTECTED_PROCESSES = {
    'system', 'csrss.exe', 'smss.exe', 'services.exe',
    'lsass.exe', 'winlogon.exe', 'wininit.exe',
    'explorer.exe', 'dwm.exe', 'svchost.exe'
}

# Запрещённые пути для файлового менеджера
FORBIDDEN_PATHS = {
    'C:\\Windows\\System32',
    'C:\\Windows\\SysWOW64',
    'C:\\Windows\\Boot',
    'C:\\$Recycle.Bin',
    'C:\\ProgramData\\Microsoft\\Windows\\Start Menu',
}


def validate_cmd_command(command: str) -> tuple[bool, Optional[str]]:
    """
    Проверяет безопасность CMD команды.
    
    Args:
        command: Команда для выполнения
        
    Returns:
        tuple: (разрешено ли, причина отказа или None)
        
    Example:
        >>> is_safe, reason = validate_cmd_command("format C:")
        >>> if not is_safe:
        >>>     print(f"Опасная команда: {reason}")
    """
    cmd_lower = command.lower().strip()
    
    # Проверка на пустую команду
    if not cmd_lower:
        return False, "Пустая команда"
    
    # Проверка на опасные символы и операторы
    dangerous_chars = ['|', '&', ';', '>', '<', '^']
    if any(char in command for char in dangerous_chars):
        # Разрешаем только простые перенаправления
        if not (command.count('>') == 1 or command.count('<') == 1):
            return False, "Обнаружены опасные операторы цепочки команд"
    
    # Проверка черного списка
    for dangerous_cmd in CMD_BLACKLIST:
        if dangerous_cmd in cmd_lower:
            return False, f"Запрещённая команда: {dangerous_cmd}"
    
    # Проверка на попытки обхода (base64, hex)
    if any(keyword in cmd_lower for keyword in ['certutil -decode', 'bitsadmin', 'msiexec /q']):
        return False, "Обнаружена попытка обхода через кодирование"
    
    return True, None


def validate_process_kill(pid: int, process_name: str) -> tuple[bool, Optional[str]]:
    """
    Проверяет безопасность убийства процесса.
    
    Args:
        pid: Process ID
        process_name: Имя процесса
        
    Returns:
        tuple: (разрешено ли, причина отказа или None)
    """
    name_lower = process_name.lower()
    
    # Проверка критических процессов
    if name_lower in PROTECTED_PROCESSES:
        return False, f"Критический системный процесс: {process_name}"
    
    # Проверка PID критических процессов (обычно < 1000)
    if pid < 100:
        return False, f"Слишком низкий PID ({pid}). Вероятно системный процесс."
    
    return True, None


def validate_file_path(path: str, base_allowed_paths: list = None) -> tuple[bool, Optional[str]]:
    """
    Проверяет безопасность пути файла (защита от path traversal).
    
    Args:
        path: Путь для проверки
        base_allowed_paths: Список разрешённых базовых путей
        
    Returns:
        tuple: (разрешено ли, причина отказа или None)
    """
    if not path:
        return False, "Пустой путь"
    
    try:
        # Нормализуем путь
        abs_path = os.path.abspath(path)
        
        # Проверка на запрещённые директории
        for forbidden in FORBIDDEN_PATHS:
            if abs_path.lower().startswith(forbidden.lower()):
                return False, f"Доступ к системной директории запрещён: {forbidden}"
        
        # Если заданы разрешённые пути - проверяем принадлежность
        if base_allowed_paths:
            allowed = False
            for allowed_path in base_allowed_paths:
                allowed_abs = os.path.abspath(allowed_path)
                if abs_path.lower().startswith(allowed_abs.lower()):
                    allowed = True
                    break
            
            if not allowed:
                return False, "Путь за пределами разрешённых директорий"
        
        # Проверка на path traversal
        if '..' in path or path.startswith('\\\\'):
            # Дополнительная проверка на легитимность
            if os.path.dirname(abs_path) != os.path.dirname(path.replace('..', '')):
                return False, "Обнаружена попытка path traversal (..)"
        
        return True, None
        
    except Exception as e:
        return False, f"Ошибка валидации пути: {e}"


def sanitize_log_message(message: str) -> str:
    """
    Очищает сообщение от чувствительных данных перед логированием.
    
    Args:
        message: Исходное сообщение
        
    Returns:
        str: Очищенное сообщение
        
    Example:
        >>> sanitize_log_message("API_KEY=sk-abc123")
        >>> "API_KEY=***HIDDEN***"
    """
    # Паттерны для скрытия
    patterns = [
        # API ключи, токены, пароли
        (r'(api[_-]?key|token|password|secret)[=:\s]+[^\s,]+', r'\1=***HIDDEN***'),
        # Bearer токены (с пробелом после Bearer)
        (r'Bearer\s+[a-zA-Z0-9_\-]+', r'Bearer ***HIDDEN_TOKEN***'),
        # Ключи типа sk-xxx, pk-xxx
        (r'(sk|pk)[_-][a-zA-Z0-9]{20,}', r'***HIDDEN_KEY***'),
        # Длинные хеши и токены (32+ символов)
        (r'\b[A-Za-z0-9]{32,}\b', r'***HASH***'),
    ]
    
    result = message
    for pattern, replacement in patterns:
        result = re.sub(pattern, replacement, result, flags=re.IGNORECASE)
    
    return result


def validate_ai_prompt(prompt: str) -> tuple[bool, Optional[str]]:
    """
    Проверяет безопасность промпта для AI.
    
    Args:
        prompt: Промпт для проверки
        
    Returns:
        tuple: (разрешено ли, причина отказа или None)
    """
    # Защита от prompt injection
    dangerous_patterns = [
        'ignore previous',
        'disregard',
        'system:',
        'you are now',
        'forget everything',
        'new instructions',
    ]
    
    prompt_lower = prompt.lower()
    
    for pattern in dangerous_patterns:
        if pattern in prompt_lower:
            return False, f"Обнаружена попытка prompt injection: {pattern}"
    
    # Ограничение длины
    if len(prompt) > 5000:
        return False, "Промпт слишком длинный (макс 5000 символов)"
    
    return True, None
