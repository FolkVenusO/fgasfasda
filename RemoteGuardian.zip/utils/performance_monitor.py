"""
Монитор производительности для Remote Guardian
Отслеживает время выполнения команд и выявляет узкие места
"""

import time
import logging
import asyncio
from functools import wraps
from collections import defaultdict
from typing import Callable, Any

logger = logging.getLogger(__name__)

# Статистика выполнения команд
_command_stats = defaultdict(lambda: {'count': 0, 'total_time': 0.0, 'max_time': 0.0, 'min_time': float('inf')})
_stats_lock = asyncio.Lock()


def performance_monitor(command_name: str = None, log_slow_threshold: float = 2.0):
    """
    Декоратор для мониторинга производительности команд.
    
    Args:
        command_name: Имя команды (по умолчанию - имя функции)
        log_slow_threshold: Порог в секундах для логирования медленных команд
        
    Example:
        @performance_monitor("Screenshot", log_slow_threshold=1.0)
        async def take_screenshot(event):
            ...
    """
    def decorator(func: Callable) -> Callable:
        name = command_name or func.__name__
        
        @wraps(func)
        async def async_wrapper(*args, **kwargs) -> Any:
            start_time = time.perf_counter()
            
            try:
                result = await func(*args, **kwargs)
                return result
            finally:
                elapsed = time.perf_counter() - start_time
                
                # Обновляем статистику
                async with _stats_lock:
                    stats = _command_stats[name]
                    stats['count'] += 1
                    stats['total_time'] += elapsed
                    stats['max_time'] = max(stats['max_time'], elapsed)
                    stats['min_time'] = min(stats['min_time'], elapsed)
                
                # Логируем медленные команды
                if elapsed > log_slow_threshold:
                    logger.warning(
                        f"⚠️ Slow command detected: {name} took {elapsed:.2f}s "
                        f"(threshold: {log_slow_threshold}s)"
                    )
        
        @wraps(func)
        def sync_wrapper(*args, **kwargs) -> Any:
            start_time = time.perf_counter()
            
            try:
                result = func(*args, **kwargs)
                return result
            finally:
                elapsed = time.perf_counter() - start_time
                
                # Обновляем статистику
                stats = _command_stats[name]
                stats['count'] += 1
                stats['total_time'] += elapsed
                stats['max_time'] = max(stats['max_time'], elapsed)
                stats['min_time'] = min(stats['min_time'], elapsed)
                
                if elapsed > log_slow_threshold:
                    logger.warning(
                        f"⚠️ Slow command detected: {name} took {elapsed:.2f}s"
                    )
        
        # Определяем async или sync
        import inspect
        if inspect.iscoroutinefunction(func):
            return async_wrapper
        else:
            return sync_wrapper
    
    return decorator


async def get_performance_stats() -> dict:
    """
    Получает статистику производительности всех команд.
    
    Returns:
        dict: Статистика по каждой команде
    """
    async with _stats_lock:
        stats = {}
        for name, data in _command_stats.items():
            if data['count'] > 0:
                stats[name] = {
                    'count': data['count'],
                    'total_time': round(data['total_time'], 2),
                    'avg_time': round(data['total_time'] / data['count'], 3),
                    'max_time': round(data['max_time'], 3),
                    'min_time': round(data['min_time'], 3)
                }
        return stats


def get_performance_stats_sync() -> dict:
    """Синхронная версия get_performance_stats()."""
    stats = {}
    for name, data in _command_stats.items():
        if data['count'] > 0:
            stats[name] = {
                'count': data['count'],
                'total_time': round(data['total_time'], 2),
                'avg_time': round(data['total_time'] / data['count'], 3),
                'max_time': round(data['max_time'], 3),
                'min_time': round(data['min_time'], 3)
            }
    return stats


def format_performance_report() -> str:
    """
    Форматирует отчёт о производительности для отображения.
    
    Returns:
        str: Форматированный отчёт
    """
    stats = get_performance_stats_sync()
    
    if not stats:
        return "📊 Статистика пуста. Команды ещё не выполнялись."
    
    # Сортируем по общему времени (самые медленные сверху)
    sorted_stats = sorted(stats.items(), key=lambda x: x[1]['total_time'], reverse=True)
    
    report = "📊 **Статистика производительности команд:**\\n\\n"
    
    for name, data in sorted_stats[:15]:  # Топ-15
        report += (
            f"**{name}**\\n"
            f"└ Вызовов: {data['count']} | "
            f"Среднее: {data['avg_time']}s | "
            f"Макс: {data['max_time']}s\\n"
        )
    
    # Общая статистика
    total_commands = sum(s['count'] for s in stats.values())
    total_time = sum(s['total_time'] for s in stats.values())
    
    report += (
        f"\\n**Всего:**\\n"
        f"└ Команд выполнено: {total_commands}\\n"
        f"└ Общее время: {total_time:.2f}s\\n"
    )
    
    return report


def reset_performance_stats():
    """Сбрасывает всю статистику производительности."""
    _command_stats.clear()
    logger.info("Performance statistics reset")
