"""
Модуль кэширования для Remote Guardian
Кэширует дорогие операции (список процессов, системная информация)
"""

import time
from functools import wraps
from typing import Callable, Any
import asyncio


class SimpleCache:
    """Простой thread-safe кэш с TTL"""
    
    def __init__(self):
        self.cache = {}
        self.timestamps = {}
        self._lock = asyncio.Lock()
    
    async def get_async(self, key: str, ttl: float = 60.0) -> Any:
        """Получить значение из кэша (async)"""
        async with self._lock:
            if key in self.cache:
                if time.time() - self.timestamps[key] < ttl:
                    return self.cache[key]
                else:
                    del self.cache[key]
                    del self.timestamps[key]
            return None
    
    def get(self, key: str, ttl: float = 60.0) -> Any:
        """Получить значение из кэша (sync)"""
        if key in self.cache:
            if time.time() - self.timestamps[key] < ttl:
                return self.cache[key]
            else:
                del self.cache[key]
                del self.timestamps[key]
        return None
    
    async def set_async(self, key: str, value: Any) -> None:
        """Сохранить значение в кэш (async)"""
        async with self._lock:
            self.cache[key] = value
            self.timestamps[key] = time.time()
    
    def set(self, key: str, value: Any) -> None:
        """Сохранить значение в кэш (sync)"""
        self.cache[key] = value
        self.timestamps[key] = time.time()
    
    def clear(self) -> None:
        """Очистить весь кэш"""
        self.cache.clear()
        self.timestamps.clear()


# Глобальный кэш
_cache = SimpleCache()


def cached(ttl: float = 60.0, key_func: Callable = None):
    """
    Декоратор для кэширования результатов функций
    
    Args:
        ttl: Время жизни кэша в секундах
        key_func: Функция для генерации ключа кэша (по умолчанию - имя функции)
    
    Example:
        @cached(ttl=30.0)
        async def get_system_info():
            # Дорогая операция
            return psutil.cpu_percent()
    """
    def decorator(func):
        @wraps(func)
        async def async_wrapper(*args, **kwargs):
            # Генерируем ключ
            if key_func:
                cache_key = key_func(*args, **kwargs)
            else:
                cache_key = f"{func.__name__}"
            
            # Проверяем кэш
            cached_value = await _cache.get_async(cache_key, ttl)
            if cached_value is not None:
                return cached_value
            
            # Вычисляем и кэшируем
            result = await func(*args, **kwargs)
            await _cache.set_async(cache_key, result)
            return result
        
        @wraps(func)
        def sync_wrapper(*args, **kwargs):
            # Генерируем ключ
            if key_func:
                cache_key = key_func(*args, **kwargs)
            else:
                cache_key = f"{func.__name__}"
            
            # Проверяем кэш
            cached_value = _cache.get(cache_key, ttl)
            if cached_value is not None:
                return cached_value
            
            # Вычисляем и кэшируем
            result = func(*args, **kwargs)
            _cache.set(cache_key, result)
            return result
        
        # Определяем, async или sync функция
        import inspect
        if inspect.iscoroutinefunction(func):
            return async_wrapper
        else:
            return sync_wrapper
    
    return decorator


def clear_cache():
    """Очистить весь кэш"""
    _cache.clear()
