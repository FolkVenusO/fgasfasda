"""
Оптимизированный модуль для скриншотов
Использует MSS (быстрее чем pyautogui на 300-500%)
"""

import os
import logging
from typing import Optional
from PIL import Image

logger = logging.getLogger(__name__)

# Lazy import для ускорения загрузки модуля
_mss_available = None
_mss = None


def _check_mss():
    """Проверяет доступность mss и кеширует результат."""
    global _mss_available, _mss
    
    if _mss_available is None:
        try:
            import mss
            _mss = mss
            _mss_available = True
        except ImportError:
            _mss_available = False
    
    return _mss_available


def take_screenshot_optimized(output_path: str, monitor: int = 0, compress: bool = True) -> bool:
    """
    Делает скриншот используя самый быстрый доступный метод.
    
    Args:
        output_path: Путь для сохранения
        monitor: Номер монитора (0 = все мониторы, 1 = первый, и т.д.)
        compress: Сжимать ли изображение для экономии места
        
    Returns:
        bool: Успешность операции
        
    Performance:
        - MSS: ~15-30ms (приоритет)
        - PIL ImageGrab: ~50-80ms (fallback)
        - pyautogui: ~100-200ms (последний вариант)
    """
    try:
        # Метод 1: MSS (самый быстрый)
        if _check_mss():
            with _mss.mss() as sct:
                # Выбираем монитор
                if monitor == 0:
                    # Все мониторы
                    screenshot = sct.grab(sct.monitors[0])
                else:
                    # Конкретный монитор
                    if monitor <= len(sct.monitors) - 1:
                        screenshot = sct.grab(sct.monitors[monitor])
                    else:
                        screenshot = sct.grab(sct.monitors[1])
                
                # Конвертируем в PIL Image
                img = Image.frombytes('RGB', screenshot.size, screenshot.rgb)
                
                # Опциональное сжатие
                if compress:
                    # Уменьшаем качество для экономии ~40-60% размера
                    img.save(output_path, 'PNG', optimize=True, compress_level=6)
                else:
                    img.save(output_path, 'PNG')
                
                return True
        
        # Метод 2: PIL ImageGrab (fallback)
        try:
            from PIL import ImageGrab
            img = ImageGrab.grab(all_screens=(monitor == 0))
            
            if compress:
                img.save(output_path, 'PNG', optimize=True, compress_level=6)
            else:
                img.save(output_path, 'PNG')
            
            return True
        except Exception as e:
            logger.debug(f"PIL ImageGrab failed: {e}")
        
        # Метод 3: pyautogui (самый медленный, но надёжный)
        import pyautogui
        screenshot = pyautogui.screenshot()
        
        if compress:
            screenshot.save(output_path, 'PNG', optimize=True, compress_level=6)
        else:
            screenshot.save(output_path, 'PNG')
        
        return True
        
    except Exception as e:
        logger.error(f"Screenshot failed: {e}")
        return False


def take_screenshot_region(x: int, y: int, width: int, height: int, output_path: str) -> bool:
    """
    Делает скриншот определённой области экрана.
    
    Args:
        x, y: Координаты верхнего левого угла
        width, height: Размеры области
        output_path: Путь для сохранения
        
    Returns:
        bool: Успешность операции
    """
    try:
        if _check_mss():
            with _mss.mss() as sct:
                monitor = {"top": y, "left": x, "width": width, "height": height}
                screenshot = sct.grab(monitor)
                img = Image.frombytes('RGB', screenshot.size, screenshot.rgb)
                img.save(output_path, 'PNG', optimize=True, compress_level=6)
                return True
        
        # Fallback на PIL
        from PIL import ImageGrab
        bbox = (x, y, x + width, y + height)
        img = ImageGrab.grab(bbox=bbox)
        img.save(output_path, 'PNG', optimize=True, compress_level=6)
        return True
        
    except Exception as e:
        logger.error(f"Region screenshot failed: {e}")
        return False


def get_screenshot_as_bytes(compress: bool = True) -> Optional[bytes]:
    """
    Возвращает скриншот как байты (без сохранения в файл).
    
    Args:
        compress: Сжимать ли изображение
        
    Returns:
        bytes: PNG данные или None при ошибке
    """
    try:
        from io import BytesIO
        
        if _check_mss():
            with _mss.mss() as sct:
                screenshot = sct.grab(sct.monitors[0])
                img = Image.frombytes('RGB', screenshot.size, screenshot.rgb)
        else:
            from PIL import ImageGrab
            img = ImageGrab.grab()
        
        # Сохраняем в BytesIO
        buffer = BytesIO()
        if compress:
            img.save(buffer, 'PNG', optimize=True, compress_level=6)
        else:
            img.save(buffer, 'PNG')
        
        return buffer.getvalue()
        
    except Exception as e:
        logger.error(f"Screenshot to bytes failed: {e}")
        return None


def get_monitor_info() -> list:
    """
    Получает информацию о подключённых мониторах.
    
    Returns:
        list: Список словарей с информацией о мониторах
              [{'index': 1, 'width': 1920, 'height': 1080, 'left': 0, 'top': 0}, ...]
    """
    try:
        if _check_mss():
            with _mss.mss() as sct:
                monitors = []
                for idx, monitor in enumerate(sct.monitors[1:], start=1):  # Пропускаем monitors[0] (все экраны)
                    monitors.append({
                        'index': idx,
                        'width': monitor['width'],
                        'height': monitor['height'],
                        'left': monitor['left'],
                        'top': monitor['top']
                    })
                return monitors
        
        # Fallback - возвращаем информацию о текущем разрешении
        import pyautogui
        size = pyautogui.size()
        return [{'index': 1, 'width': size.width, 'height': size.height, 'left': 0, 'top': 0}]
        
    except Exception as e:
        logger.error(f"Get monitor info failed: {e}")
        return []
