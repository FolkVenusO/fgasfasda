import os
import json
import datetime
import logging
import asyncio

_BASE_DIR = os.path.dirname(os.path.abspath(__file__))

logger = logging.getLogger(__name__)

DB_FILE = os.path.join(_BASE_DIR, 'users_db.json')
db_data = {}

# Глобальная блокировка для защиты от race condition при одновременных операциях с БД
_db_lock = asyncio.Lock()

def load(main_admins: list) -> None:
    """Загружает базу данных. При ошибке чтения создает пустую."""
    global db_data
    if os.path.exists(DB_FILE):
        try:
            with open(DB_FILE, 'r', encoding='utf-8') as f:
                db_data = json.load(f)
        except json.JSONDecodeError as e:
            logger.error(f"Файл БД поврежден. Создается новая база. Ошибка: {e}")
            db_data = {}
            
    # Главные админы всегда получают роль owner и неограниченный лимит
    for adm in main_admins:
        if adm not in db_data or db_data[adm].get("role") != "owner":
            db_data[adm] = {"role": "owner", "limit": 99999, "used_today": 0, "last_date": ""}
    save()

def save() -> None:
    """Безопасное (атомарное) сохранение БД.
    
    ВАЖНО: Эта функция НЕ потокобезопасна сама по себе!
    Вызывай её только внутри блокировки _db_lock или используй save_async().
    """
    try:
        tmp_file = DB_FILE + '.tmp'
        with open(tmp_file, 'w', encoding='utf-8') as f:
            json.dump(db_data, f, indent=4)
        # Мгновенная подмена файла (исключает повреждение при сбое ПК)
        os.replace(tmp_file, DB_FILE)
    except Exception as e:
        logger.error(f"Ошибка при сохранении БД: {e}")

async def save_async() -> None:
    """Асинхронная потокобезопасная версия save()."""
    async with _db_lock:
        await asyncio.to_thread(save)

def exists(user_id: str) -> bool:
    return str(user_id) in db_data

def get_all() -> dict:
    return db_data

async def add_async(user_id: str, limit: int) -> None:
    """Потокобезопасное добавление пользователя."""
    async with _db_lock:
        db_data[str(user_id)] = {"role": "user", "limit": limit, "used_today": 0, "last_date": ""}
        await asyncio.to_thread(save)

def add(user_id: str, limit: int) -> None:
    """Синхронная версия (deprecated - используй add_async)."""
    db_data[str(user_id)] = {"role": "user", "limit": limit, "used_today": 0, "last_date": ""}
    save()

async def remove_async(user_id: str) -> bool:
    """Потокобезопасное удаление пользователя."""
    async with _db_lock:
        if str(user_id) in db_data:
            del db_data[str(user_id)]
            await asyncio.to_thread(save)
            return True
        return False

def remove(user_id: str) -> bool:
    """Синхронная версия (deprecated - используй remove_async)."""
    if str(user_id) in db_data:
        del db_data[str(user_id)]
        save()
        return True
    return False

async def check_limit_async(user_id: str) -> tuple[bool, int]:
    """Потокобезопасная проверка лимита. Возвращает (Разрешено_ли, Текущий_лимит)."""
    async with _db_lock:
        user = db_data.get(str(user_id))
        if not user:
            return False, 0
            
        today = str(datetime.date.today())

        # Сброс счетчика каждый новый день
        if user.get("last_date") != today:
            user["used_today"] = 0
            user["last_date"] = today
            await asyncio.to_thread(save)

        # Владельцы и админы не имеют лимитов
        if user["role"] in ["owner", "admin"]:
            return True, 0

        if user["used_today"] >= user["limit"]:
            return False, user['limit']
            
        user["used_today"] += 1
        await asyncio.to_thread(save)
        return True, 0

def check_limit(user_id: str) -> tuple[bool, int]:
    """Синхронная версия (deprecated - используй check_limit_async).
    
    ВНИМАНИЕ: Эта функция НЕ потокобезопасна! 
    Используй check_limit_async() из async-хендлеров.
    """
    user = db_data.get(str(user_id))
    if not user:
        return False, 0
        
    today = str(datetime.date.today())

    # Сброс счетчика каждый новый день
    if user.get("last_date") != today:
        user["used_today"] = 0
        user["last_date"] = today
        save()

    # Владельцы и админы не имеют лимитов
    if user["role"] in ["owner", "admin"]:
        return True, 0

    if user["used_today"] >= user["limit"]:
        return False, user['limit']
        
    user["used_today"] += 1
    save()
    return True, 0