import os
import json
import datetime
import logging

_BASE_DIR = os.path.dirname(os.path.abspath(__file__))

logger = logging.getLogger(__name__)

DB_FILE = os.path.join(_BASE_DIR, 'users_db.json')
db_data = {}

def load(main_admins: list) -> None:
    """Загружает базу данных. При ошибке чтения создает пустую."""
    global db_data
    if os.path.exists(DB_FILE):
        try:
            with open(DB_FILE, 'r', encoding='utf-8') as f:
                db_data = json.load(f)
        except json.JSONDecodeError as e:
            logger.error(f"Файл БД поврежден. Создается новая база. Ошибка: {e}")
            db_data = {}
            
    # Главные админы всегда получают роль owner и неограниченный лимит
    for adm in main_admins:
        if adm not in db_data or db_data[adm].get("role") != "owner":
            db_data[adm] = {"role": "owner", "limit": 99999, "used_today": 0, "last_date": ""}
    save()

def save() -> None:
    """Безопасное сохранение БД."""
    try:
        with open(DB_FILE, 'w', encoding='utf-8') as f:
            json.dump(db_data, f, indent=4)
    except Exception as e:
        logger.error(f"Ошибка при сохранении БД: {e}")

def exists(user_id: str) -> bool:
    return str(user_id) in db_data

def get_all() -> dict:
    return db_data

def add(user_id: str, limit: int) -> None:
    db_data[str(user_id)] = {"role": "user", "limit": limit, "used_today": 0, "last_date": ""}
    save()

def remove(user_id: str) -> bool:
    if str(user_id) in db_data:
        del db_data[str(user_id)]
        save()
        return True
    return False

def check_limit(user_id: str) -> tuple[bool, int]:
    """Возвращает (Разрешено_ли, Текущий_лимит)."""
    user = db_data.get(str(user_id))
    if not user:
        return False, 0
        
    today = str(datetime.date.today())

    # Сброс счетчика каждый новый день
    if user.get("last_date") != today:
        user["used_today"] = 0
        user["last_date"] = today
        save()

    # Владельцы и админы не имеют лимитов
    if user["role"] in ["owner", "admin"]:
        return True, 0

    if user["used_today"] >= user["limit"]:
        return False, user['limit']
        
    user["used_today"] += 1
    save()
    return True, 0