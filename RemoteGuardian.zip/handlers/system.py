import os
import asyncio
import threading
import psutil
import ctypes
import pyperclip
import winreg
import sys
import pyautogui
from telethon import events
from core.decorators import with_verify
from core.state import state
from utils.helpers import safe_remove
from config import BASE_DIR

def register_system(bot):
    # --- ТВОИ СТАРЫЕ ФУНКЦИИ ---

    @bot.on(events.NewMessage(func=lambda e: e.text in ['/status', '📊 Статус ПК']))
    @with_verify("PC Status", dangerous=False)
    async def status(event):
        cpu = psutil.cpu_percent(interval=1)
        ram = psutil.virtual_memory()
        disk = psutil.disk_usage('C:')
        await event.reply(f"📊 **Система:**\n🖥 CPU: {cpu}%\n📟 ОЗУ: {ram.percent}%\n💾 SSD: {disk.percent}% занято")

    @bot.on(events.NewMessage(func=lambda e: e.text in ['/tasks', '⚙️ Процессы']))
    @with_verify("Process List", dangerous=False)
    async def top_tasks(event):
        pr = sorted(
            [p.info for p in psutil.process_iter(['pid', 'name', 'memory_info']) if p.info.get('memory_info')], 
            key=lambda p: p['memory_info'].rss, 
            reverse=True
        )[:5]
        text = "⚙️ **Топ-5 тяжелых процессов:**\n"
        for p in pr: 
            text += f"🔹 `{p['name']}` — {p['memory_info'].rss / (1024*1024):.1f} MB\n"
        await event.reply(text)

    @bot.on(events.NewMessage(func=lambda e: e.text in ['/clip', '📋 Буфер обмена']))
    @with_verify("Read Clipboard", dangerous=False)
    async def read_clip(event):
        text = pyperclip.paste()
        if not text: 
            return await event.reply("📭 Буфер пуст.")
        await event.reply(f"📋 **В буфере ПК:**\n`{text[:1500]}`")

    @bot.on(events.NewMessage(pattern=r'^/cmd (.*)'))
    @with_verify("CMD Execution", dangerous=True)
    async def terminal_handler(event):
        cmd = event.pattern_match.group(1)
        proc = await asyncio.create_subprocess_shell(
            cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
        )
        out, err = await proc.communicate()
        res = (out + err).decode('cp866', errors='replace')
            
        if len(res) > 4000:
            filepath = os.path.join(BASE_DIR, 'cmd_res.txt')
            with open(filepath, 'w', encoding='utf-8') as f: 
                f.write(res)
            await event.reply("📁 Результат слишком большой:", file=filepath)
            safe_remove(filepath)
        else: 
            await event.reply(f"```text\n{res or 'Успешно.'}\n```")

    @bot.on(events.NewMessage(func=lambda e: e.text == '🔴 Выключить'))
    @with_verify("Shutdown PC", dangerous=True)
    async def shutdown_pc(event):
        await event.reply("⚠️ ПК выключается...")
        os.system("shutdown /s /t 0")

    @bot.on(events.NewMessage(func=lambda e: e.text == '🔄 Рестарт'))
    @with_verify("Restart PC", dangerous=True)
    async def restart_pc(event):
        await event.reply("🔄 Перезагрузка...")
        os.system("shutdown /r /t 0")

    @bot.on(events.NewMessage(func=lambda e: e.text == '🖥 Потушить экран'))
    @with_verify("Screen Off", dangerous=True)
    async def screen_off(event):
        await event.reply("🖥 Экран выключен.")
        ctypes.windll.user32.SendMessageW(0xFFFF, 0x0112, 0xF170, 2)

    @bot.on(events.NewMessage(func=lambda e: e.text == '🔒 Заблокировать ПК'))
    @with_verify("Lock PC", dangerous=True)
    async def lock_windows(event):
        await event.reply("🔒 Учетная запись заблокирована.")
        ctypes.windll.user32.LockWorkStation()

    @bot.on(events.NewMessage(func=lambda e: e.text == '🚫 Блок мыши (10 сек)'))
    @with_verify("Block Input", dangerous=True)
    async def block_input(event):
        if ctypes.windll.shell32.IsUserAnAdmin():
            await event.reply("🚫 Ввод заблокирован на 10 сек!")
            try: 
                ctypes.windll.user32.BlockInput(True)
                await asyncio.sleep(10)
            finally: 
                ctypes.windll.user32.BlockInput(False)
                await event.reply("✅ Восстановлено.")
        else: 
            await event.reply("❌ Ошибка: Скрипт запущен не от имени Администратора.")

    # --- НОВЫЕ ДОБАВЛЕННЫЕ ФУНКЦИИ ---

    @bot.on(events.NewMessage(pattern=r'^/autorun (on|off)'))
    @with_verify("Autorun Config", dangerous=True)
    async def autorun(event):
        state_mode = event.pattern_match.group(1).lower()
        key_path = r"Software\Microsoft\Windows\CurrentVersion\Run"
        try:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path, 0, winreg.KEY_ALL_ACCESS) as reg_key:
                if state_mode == "on":
                    cmd = f'"{sys.executable}" "{os.path.abspath("main.py")}"'
                    winreg.SetValueEx(reg_key, "RemoteGuardian", 0, winreg.REG_SZ, cmd)
                    await event.reply("✅ Бот добавлен в автозагрузку Windows.")
                else:
                    winreg.DeleteValue(reg_key, "RemoteGuardian")
                    await event.reply("🛑 Бот удален из автозагрузки.")
        except FileNotFoundError:
            await event.reply("✅ Бота и так нет в автозагрузке.")
        except Exception as e:
            await event.reply(f"❌ Ошибка реестра: {e}")

    @bot.on(events.NewMessage(pattern=r'^/setclip (.*)'))
    @with_verify("Set Clipboard", dangerous=True)
    async def set_clip(event):
        text = event.pattern_match.group(1)
        pyperclip.copy(text)
        await event.reply("✅ Текст скопирован в буфер обмена на ПК.")

    @bot.on(events.NewMessage(pattern=r'^/kill (\d+)'))
    @with_verify("Kill Process", dangerous=True)
    async def kill_proc(event):
        pid = int(event.pattern_match.group(1))
        try:
            p = psutil.Process(pid)
            name = p.name()
            p.terminate()
            await event.reply(f"💀 Процесс `{name}` (PID: {pid}) убит.")
        except psutil.NoSuchProcess:
            await event.reply("❌ Процесс не найден.")
        except Exception as e:
            await event.reply(f"❌ Ошибка: {e}")

    @bot.on(events.NewMessage(pattern=r'^/type (.+)'))
    @with_verify("Type Text", dangerous=True)
    async def type_text(event):
        text = event.pattern_match.group(1)
        # Небольшая задержка чтобы фокус успел переключиться
        await asyncio.sleep(0.5)
        # pyautogui.write() поддерживает Unicode (русский, эмодзи и т.д.)
        await asyncio.to_thread(pyautogui.write, text, interval=0.05)
        await event.reply(f"⌨️ Напечатано на ПК: `{text}`")

    @bot.on(events.NewMessage(pattern=r'^/wallpaper$'))
    @with_verify("Set Wallpaper", dangerous=True)
    async def set_wallpaper(event):
        if not event.message.media:
            return await event.reply("🖼 Отправь картинку вместе с командой /wallpaper как подпись.")
        msg = await event.reply("⏳ Скачиваю изображение...")
        wp_path = os.path.join(BASE_DIR, 'wallpaper_tmp.jpg')
        await event.message.download_media(wp_path)
        SPI_SETDESKWALLPAPER = 0x0014
        result = ctypes.windll.user32.SystemParametersInfoW(SPI_SETDESKWALLPAPER, 0, wp_path, 3)
        if result:
            await msg.edit("✅ Обои успешно установлены!")
        else:
            await msg.edit("❌ Не удалось установить обои.")

    @bot.on(events.NewMessage(func=lambda e: e.text in ['/keylog on', '/keylog off', '/keylog get']))
    @with_verify("Keylogger", dangerous=True)
    async def keylogger(event):
        cmd = event.text.strip()

        if cmd == '/keylog on':
            if state.keylog_active:
                return await event.reply("⌨️ Кейлоггер уже запущен.")
            state.keylog_active = True
            state.keylog_buffer = []

            def on_press(key):
                if not state.keylog_active:
                    return False  # останавливает listener
                try:
                    state.keylog_buffer.append(key.char if hasattr(key, 'char') and key.char else f'[{key.name}]')
                except Exception:
                    state.keylog_buffer.append(f'[{key}]')

            from pynput import keyboard as kb
            listener = kb.Listener(on_press=on_press)
            listener.daemon = True
            listener.start()
            state.keylog_listener = listener
            await event.reply("✅ Кейлоггер запущен. `/keylog get` — посмотреть, `/keylog off` — остановить.")

        elif cmd == '/keylog off':
            if not state.keylog_active:
                return await event.reply("⌨️ Кейлоггер не запущен.")
            state.keylog_active = False
            if hasattr(state, 'keylog_listener') and state.keylog_listener:
                state.keylog_listener.stop()
                state.keylog_listener = None
            await event.reply("🛑 Кейлоггер остановлен.")

        elif cmd == '/keylog get':
            if not state.keylog_buffer:
                return await event.reply("📭 Буфер кейлоггера пуст.")
            text = ''.join(state.keylog_buffer)
            state.keylog_buffer.clear()
            # Если текст большой — отправляем файлом
            if len(text) > 3000:
                fp = os.path.join(BASE_DIR, 'keylog.txt')
                with open(fp, 'w', encoding='utf-8') as f:
                    f.write(text)
                await event.reply("⌨️ Лог нажатий:", file=fp)
                safe_remove(fp)
            else:
                await event.reply(f"⌨️ **Лог нажатий:**\n`{text}`")