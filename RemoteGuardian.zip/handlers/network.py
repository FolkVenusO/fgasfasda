import urllib.request
import psutil
import speedtest
import asyncio
from telethon import events
from core.decorators import with_verify

def register_network(bot):
    @bot.on(events.NewMessage(pattern=r'^/ip$'))
    @with_verify("Check IP", dangerous=True)
    async def check_ip(event):
        try:
            ip = urllib.request.urlopen('https://api.ipify.org').read().decode('utf8')
            await event.reply(f"🌐 Внешний IP компьютера: `{ip}`")
        except Exception as e:
            await event.reply(f"❌ Ошибка: {e}")

    @bot.on(events.NewMessage(pattern=r'^/netstat$'))
    @with_verify("Network Stat", dangerous=True)
    async def netstat(event):
        conns = psutil.net_connections(kind='inet')
        text = "🌐 **Текущие интернет-соединения ПК:**\n\n"
        count = 0
        for c in conns:
            if c.status == 'ESTABLISHED' and count < 15:
                raddr = f"{c.raddr.ip}:{c.raddr.port}" if c.raddr else "Unknown"
                text += f"🔹 PID: `{c.pid}` | Куда: `{raddr}`\n"
                count += 1
        await event.reply(text if count > 0 else "📭 Активных соединений не найдено.")

    @bot.on(events.NewMessage(pattern=r'^/speedtest$'))
    @with_verify("Speedtest", dangerous=True)
    async def run_speedtest(event):
        msg = await event.reply("⏳ Измеряю скорость интернета ПК... (это займет около 30-60 сек)")
        try:
            def _st():
                st = speedtest.Speedtest()
                st.get_best_server()
                d = st.download() / 1024 / 1024
                u = st.upload() / 1024 / 1024
                p = st.results.ping
                return d, u, p
                
            d, u, p = await asyncio.to_thread(_st)
            await msg.edit(f"🚀 **Speedtest (ПК):**\n\n⬇️ Скачивание: `{d:.2f} Мбит/с`\n⬆️ Загрузка: `{u:.2f} Мбит/с`\n🏓 Пинг: `{p} мс`")
        except Exception as e:
            await msg.edit(f"❌ Ошибка измерения скорости: {e}")