from telethon import events
from .menus import register_menus
from .system import register_system
from .media import register_media
from .cyber import register_cyber
from .surveillance import register_surveillance
from .files import register_files
from .network import register_network

def register_all_handlers(bot):
    register_menus(bot)
    register_system(bot)
    register_media(bot)
    register_cyber(bot)
    register_surveillance(bot)
    register_files(bot)
    register_network(bot)
    
    # Обработчик неизвестных команд/текста (должен быть последним!)
    @bot.on(events.NewMessage(incoming=True, func=lambda e: e.is_private))
    async def unknown_handler(event):
        """Отлавливает все необработанные сообщения."""
        # Определяем тип сообщения
        if event.message.sticker:
            await event.reply("❓ Стикеры я пока не понимаю. Напиши `/menu` чтобы увидеть все команды!")
        elif event.message.photo:
            await event.reply("📷 Фото получил, но я не знаю что с ним делать. Попробуй `/wallpaper` с фото как подписью!")
        elif event.message.document:
            await event.reply("📁 Файл получен, но обработка файлов пока не поддерживается. Используй `/menu` для доступных команд.")
        elif event.message.voice:
            await event.reply("🎤 Голосовые сообщения не поддерживаются. Используй текстовые команды — `/menu`")
        elif event.text and event.text.startswith('/'):
            await event.reply(f"❓ Неизвестная команда: `{event.text}`\n\nОткрой главное меню: `/menu`")
        elif event.text:
            await event.reply(f"💬 Получил сообщение: _{event.text}_\n\nЯ бот удалённого управления, не чат-бот 😊\nИспользуй `/menu` для списка команд!")