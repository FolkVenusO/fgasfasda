from .menus import register_menus
from .system import register_system
from .media import register_media
from .cyber import register_cyber
from .surveillance import register_surveillance
from .files import register_files
from .network import register_network
from .advanced import register_advanced
from .dashboard import register_dashboard
from .dashboard_button import register_dashboard_button
from .system_callbacks import register_system_callbacks
from .surveillance_callbacks import register_surveillance_callbacks
from .triggers import register_triggers

def register_all_handlers(bot):
    register_menus(bot)
    register_system(bot)
    register_media(bot)
    register_cyber(bot)
    register_surveillance(bot)
    register_files(bot)
    register_network(bot)
    register_advanced(bot)  # Новые продвинутые функции
    register_dashboard(bot)  # Системный дашборд
    register_dashboard_button(bot)  # Кнопка дашборда в меню
    register_system_callbacks(bot)  # Callback handlers для системных команд
    register_surveillance_callbacks(bot)  # Callback handlers для surveillance
    register_triggers(bot)  # Умные уведомления (триггеры)
