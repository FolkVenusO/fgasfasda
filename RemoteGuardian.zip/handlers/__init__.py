from .menus import register_menus
from .system import register_system
from .media import register_media
from .cyber import register_cyber
from .surveillance import register_surveillance
from .files import register_files
from .network import register_network  # <-- НОВЫЙ ИМПОРТ

def register_all_handlers(bot):
    register_menus(bot)
    register_system(bot)
    register_media(bot)
    register_cyber(bot)
    register_surveillance(bot)
    register_files(bot)
    register_network(bot) # <-- НОВЫЙ ВЫЗОВ