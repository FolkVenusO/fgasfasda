import asyncio
import os
import subprocess
import webbrowser
import pyttsx3
import pythoncom
import pygame
from telethon import events
from core.decorators import with_verify
from core.audio_com import get_volume_interface, set_max_volume_and_get_current
from config import ASSETS_DIR, FFMPEG_EXE

def get_media_duration(filepath: str) -> float:
    """Получает длительность медиафайла в секундах через ffprobe."""
    try:
        ffprobe = FFMPEG_EXE.replace('ffmpeg.exe', 'ffprobe.exe')
        if not os.path.exists(ffprobe):
            ffprobe = 'ffprobe'
        result = subprocess.run(
            [ffprobe, '-v', 'error', '-show_entries', 'format=duration',
             '-of', 'default=noprint_wrappers=1:nokey=1', filepath],
            capture_output=True, text=True, timeout=10
        )
        return float(result.stdout.strip())
    except Exception:
        return 0.0

def kill_video_players():
    """Завершает все известные видеоплееры напрямую через WinAPI."""
    from core.winapi import media_controller
    # Используем прямое управление через WinAPI вместо taskkill
    killed = media_controller.stop_all_known_players()
    return killed

def register_cyber(bot):
    @bot.on(events.NewMessage(pattern=r'^/vol(?: (\d+))?$'))
    @with_verify("Set Volume", dangerous=False)
    async def set_vol(event):
        val_str = event.pattern_match.group(1)
        if not val_str:
            return await event.reply(
                "🔊 **Команда /vol** — установить громкость\n\n"
                "**Использование:**\n"
                "`/vol <0-100>`\n\n"
                "**Примеры:**\n"
                "`/vol 50` — установить громкость на 50%\n"
                "`/vol 0` — выключить звук\n"
                "`/vol 100` — максимальная громкость\n\n"
                "💡 Или используй `/mute` для быстрого выключения звука"
            )
        val = int(val_str)
        val = max(0, min(100, val))
        vi = get_volume_interface()
        if vi:
            vi.SetMasterVolumeLevelScalar(val/100.0, None)
            vi.SetMute(0, None)
            await event.reply(f"🎚 Громкость ПК установлена на: **{val}%**")
        else:
            await event.reply("❌ Ошибка управления звуком.")

    @bot.on(events.NewMessage(func=lambda e: e.text in ['/mute', '/unmute']))
    @with_verify("Toggle Mute", dangerous=False)
    async def toggle_mute(event):
        is_mute = 1 if event.text == '/mute' else 0
        vi = get_volume_interface()
        if vi:
            vi.SetMute(is_mute, None)
            await event.reply("🔇 Звук выключен" if is_mute else "🔊 Звук включен")

    @bot.on(events.NewMessage(pattern=r'^/say(?: (.+))?$'))
    @with_verify("TTS Speak", dangerous=False)
    async def tts_say(event):
        """
        Озвучка текста через встроенный синтезатор Windows (PowerShell).
        
        ✅ ИСПРАВЛЕНО: Использует PowerShell вместо pyttsx3
        - Не крашит бот при повторных вызовах
        - Работает асинхронно в отдельном процессе
        - Полностью изолировано от основного процесса
        """
        txt = event.pattern_match.group(1)
        if not txt:
            return await event.reply(
                "🔊 **Команда /say** — озвучить текст на ПК\\n\\n"
                "**Использование:**\\n"
                "`/say <текст>`\\n\\n"
                "**Примеры:**\\n"
                "`/say Привет мир` — озвучит голосом Windows\\n"
                "`/say Hello world` — работает и на английском\\n\\n"
                "💡 Использует встроенный синтезатор Windows (SAPI5)"
            )
        
        txt = txt.strip()
        
        # Экранируем одинарные кавычки для PowerShell
        safe_txt = txt.replace("'", "''")
        
        # Формируем команду для встроенного синтезатора Windows
        # ✅ УЛУЧШЕНО: Добавлена быстрая скорость речи (Rate = 2)
        # Rate: -10 (очень медленно) до 10 (очень быстро), 0 = нормально
        ps_command = (
            "Add-Type -AssemblyName System.Speech; "
            "$synth = New-Object System.Speech.Synthesis.SpeechSynthesizer; "
            "$synth.Rate = 2; "  # Быстрее обычного (было по умолчанию 0)
            f"$synth.Speak('{safe_txt}')"
        )
        
        try:
            # Полный путь к PowerShell (на случай если не в PATH)
            powershell_path = r"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe"
            
            # Если стандартный путь не существует - пробуем через PATH
            if not os.path.exists(powershell_path):
                powershell_path = "powershell"
            
            # Запускаем асинхронно в отдельном процессе PowerShell
            process = await asyncio.create_subprocess_exec(
                powershell_path, "-NoProfile", "-WindowStyle", "Hidden", "-Command", ps_command,
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.DEVNULL
            )
            
            # Ждём завершения (с таймаутом 30 сек на случай очень длинного текста)
            try:
                await asyncio.wait_for(process.communicate(), timeout=30.0)
                await event.reply(f"🗣 ПК произнёс: `{txt}`")
            except asyncio.TimeoutError:
                process.kill()
                await event.reply(f"⚠️ Текст слишком длинный, озвучка прервана после 30 сек")
                
        except Exception as e:
            import logging
            logging.getLogger(__name__).error(f"TTS error: {e}")
            await event.reply(f"❌ Ошибка озвучки: {e}")

    @bot.on(events.NewMessage(pattern=r'^/open(?: (.+))?$'))
    @with_verify("Open Browser URL", dangerous=False)
    async def open_url(event):
        url = event.pattern_match.group(1)
        if not url:
            return await event.reply(
                "🌐 **Команда /open** — открыть ссылку в браузере\n\n"
                "**Использование:**\n"
                "`/open <URL>`\n\n"
                "**Примеры:**\n"
                "`/open https://google.com`\n"
                "`/open youtube.com`"
            )
        url = url.strip()
        if not url.startswith('http'):
            url = 'https://' + url
        webbrowser.open(url)
        await event.reply(f"🌐 Ссылка открыта в браузере: {url}")

    @bot.on(events.NewMessage(pattern=r'^/stop$'))
    @with_verify("Stop All Media", dangerous=False)
    async def stop_all_media(event):
        """Останавливает всё аудио и видео."""
        # Останавливаем pygame музыку
        if pygame.mixer.music.get_busy():
            pygame.mixer.music.stop()
        
        # Закрываем видеоплееры
        kill_video_players()
        
        await event.reply("⏹ Всё аудио и видео остановлено!")
    
    @bot.on(events.NewMessage(func=lambda e: e.text == '🔊 Сирена'))
    @with_verify("Play Siren", dangerous=False)
    async def play_siren(event):
        siren_path = os.path.join(ASSETS_DIR, "siren.mp3")
        if not os.path.exists(siren_path): 
            return await event.reply("❌ Нет звука сирены.")

        duration = get_media_duration(siren_path)
        await event.reply(f"🔊 Врубаю сирену на максимум... ({duration:.1f} сек)")
        vol_interface, old_volume = set_max_volume_and_get_current()
        try:
            pygame.mixer.music.load(siren_path)
            pygame.mixer.music.play()
            # Ждём ровно столько, сколько длится трек
            if duration > 0:
                await asyncio.sleep(duration)
                pygame.mixer.music.stop()
            else:
                while pygame.mixer.music.get_busy():
                    await asyncio.sleep(0.5)
        finally:
            if vol_interface and old_volume is not None: 
                vol_interface.SetMasterVolumeLevelScalar(old_volume, None)
        await event.reply("✅ Сирена отработала.")

    @bot.on(events.NewMessage(func=lambda e: e.text == '👻 Скример'))
    @with_verify("Play Screamer", dangerous=False)
    async def play_screamer(event):
        """
        Скример через ffplay для надёжной работы.
        
        ✅ ИСПРАВЛЕНО: Использует ffplay вместо системного плеера
        - Не зависит от ассоциаций файлов
        - Автоматически полноэкранный режим
        - Автозакрытие после проигрывания
        - Точный контроль PID процесса
        """
        scr_path = os.path.join(ASSETS_DIR, "screamer.mp4")
        if not os.path.exists(scr_path): 
            return await event.reply("❌ Нет видео скримера.")

        # Проверяем наличие ffplay
        ffplay_path = FFMPEG_EXE.replace('ffmpeg.exe', 'ffplay.exe')
        if not os.path.exists(ffplay_path):
            # Fallback на старый метод если ffplay нет
            return await play_screamer_legacy(event, scr_path)
        
        duration = get_media_duration(scr_path)
        await event.reply(f"👻 Скример запущен! ({duration:.1f} сек)")
        vol_interface, old_volume = set_max_volume_and_get_current()
        
        try:
            # Запускаем ffplay с параметрами:
            # -autoexit: автозакрытие после проигрывания
            # -alwaysontop: поверх всех окон
            # -noborder: без рамок
            # -fs: полноэкранный режим
            # -loglevel quiet: без логов
            process = await asyncio.create_subprocess_exec(
                ffplay_path,
                "-autoexit",      # Автозакрытие
                "-alwaysontop",   # Поверх всех окон
                "-noborder",      # Без рамок
                "-fs",            # Полный экран
                "-loglevel", "quiet",  # Без логов
                scr_path,
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.DEVNULL
            )
            
            # ✅ УЛУЧШЕНИЕ: Принудительно выводим окно на передний план
            # Даже если пользователь в другом окне - он увидит скример!
            pid = process.pid
            
            # Даём окну время на создание (0.5 сек)
            await asyncio.sleep(0.5)
            
            # Агрессивно выводим окно на передний план
            def _force_focus():
                from core.winapi import force_window_focus
                # Пробуем 10 раз с интервалом 0.3 сек (всего 3 сек)
                force_window_focus(pid, max_attempts=10, delay=0.3)
            
            # Запускаем в отдельном потоке чтобы не блокировать
            await asyncio.to_thread(_force_focus)
            
            # Ждём завершения процесса (или таймаут)
            wait_time = max(12.0, duration) if duration > 0 else 12.0
            try:
                await asyncio.wait_for(process.wait(), timeout=wait_time + 2.0)
            except asyncio.TimeoutError:
                # Если процесс завис - убиваем принудительно
                try:
                    process.kill()
                    await process.wait()
                except:
                    pass
                    
        except Exception as e:
            import logging
            logging.getLogger(__name__).error(f"Screamer error: {e}")
            await event.reply(f"❌ Ошибка скримера: {e}")
        finally:
            # Восстанавливаем громкость
            if vol_interface and old_volume is not None: 
                vol_interface.SetMasterVolumeLevelScalar(old_volume, None)
        
        await event.reply("👻 Скример отработал.")
    
    
    async def play_screamer_legacy(event, scr_path):
        """Старый метод скримера (если нет ffplay)."""
        from core.winapi import send_keypress, VK_F11, media_controller, force_window_focus
        import psutil
        
        duration = get_media_duration(scr_path)
        await event.reply(f"👻 Скример запущен (legacy режим)! ({duration:.1f} сек)")
        vol_interface, old_volume = set_max_volume_and_get_current()
        
        player_pid = None
        
        try:
            # Запускаем плеер и получаем его PID
            os.startfile(scr_path)
            await asyncio.sleep(2)  # Ждём запуска плеера
            
            # Находим PID запущенного плеера
            for proc in psutil.process_iter(['pid', 'name', 'create_time']):
                try:
                    if proc.info['name'].lower() in ['wmplayer.exe', 'movies.ui.exe', 'vlc.exe']:
                        player_pid = proc.info['pid']
                        media_controller.track_player(player_pid, proc.info['name'])
                        break
                except:
                    pass
            
            # ✅ УЛУЧШЕНИЕ: Выводим окно плеера на передний план
            if player_pid:
                await asyncio.to_thread(force_window_focus, player_pid, 10, 0.3)
            
            # Полноэкранный режим через WinAPI
            send_keypress(VK_F11)
            
            # Ждём минимум 12 секунд
            wait = max(12.0, duration - 2.0) if duration > 0 else 12.0
            await asyncio.sleep(wait)
        finally:
            if vol_interface and old_volume is not None: 
                vol_interface.SetMasterVolumeLevelScalar(old_volume, None)
            # Останавливаем плеер
            if media_controller.active_players:
                media_controller.stop_all_tracked()
            else:
                kill_video_players()
        
        await event.reply("👻 Скример отработал.")