"""
Callback handlers для inline кнопок surveillance команд
"""

import os
from telethon import events
from config import BASE_DIR
from utils.helpers import safe_remove
import logging

logger = logging.getLogger(__name__)


def register_surveillance_callbacks(bot):
    """Регистрирует callback handlers для surveillance команд."""
    
    @bot.on(events.CallbackQuery(pattern=b"screenshot_all"))
    async def screenshot_all_monitors(event):
        """Делает скриншот всех мониторов."""
        try:
            from utils.screenshot import take_screenshot_optimized
            
            await event.answer("📸 Делаю скриншот...", alert=False)
            
            screen_path = os.path.join(BASE_DIR, 's.png')
            success = take_screenshot_optimized(screen_path, monitor=0, compress=True)
            
            if success:
                await event.edit("📸 Скриншот всех мониторов:")
                await event.respond(file=screen_path)
            else:
                # Fallback
                import pyautogui
                pyautogui.screenshot(screen_path)
                await event.edit("📸 Скриншот всех мониторов:")
                await event.respond(file=screen_path)
            
            safe_remove(screen_path)
            
        except Exception as e:
            logger.error(f"Error taking screenshot: {e}")
            await event.answer("❌ Ошибка создания скриншота", alert=True)
    
    
    @bot.on(events.CallbackQuery(pattern=rb"screenshot_(\d+)"))
    async def screenshot_specific_monitor(event):
        """Делает скриншот конкретного монитора."""
        try:
            monitor_id = int(event.pattern_match.group(1).decode())
            
            from utils.screenshot import take_screenshot_optimized
            
            await event.answer(f"📸 Делаю скриншот монитора {monitor_id}...", alert=False)
            
            screen_path = os.path.join(BASE_DIR, f's_mon{monitor_id}.png')
            success = take_screenshot_optimized(screen_path, monitor=monitor_id, compress=True)
            
            if success:
                await event.edit(f"📸 Скриншот монитора {monitor_id}:")
                await event.respond(file=screen_path)
            else:
                await event.answer("❌ Ошибка захвата монитора", alert=True)
            
            safe_remove(screen_path)
            
        except Exception as e:
            logger.error(f"Error taking monitor screenshot: {e}")
            await event.answer("❌ Ошибка", alert=True)
    
    
    logger.info("Surveillance callback handlers registered")
