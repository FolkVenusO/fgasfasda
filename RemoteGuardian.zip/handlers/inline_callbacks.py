"""
Дополнительные inline callback handlers для улучшенного UI
"""

from telethon import events, Button
import logging

logger = logging.getLogger(__name__)


def register_inline_callbacks(bot):
    """Регистрирует дополнительные callback handlers."""
    
    # Placeholder для будущих callbacks
    # Основные callbacks уже в system_callbacks.py и surveillance_callbacks.py
    
    logger.info("Additional inline callback handlers registered")
