"""
Обработчик кнопки "📊 Дашборд" в главном меню
"""

from telethon import events, Button
from core.decorators import with_verify
from utils.dashboard import format_dashboard
import logging

logger = logging.getLogger(__name__)


def register_dashboard_button(bot):
    """Регистрирует обработчик кнопки дашборда."""
    
    @bot.on(events.NewMessage(func=lambda e: e.text == '📊 Дашборд'))
    @with_verify("Dashboard Button", dangerous=False)
    async def dashboard_button_handler(event):
        """Обрабатывает нажатие на кнопку Дашборд."""
        
        # Формируем дашборд
        dashboard_text = format_dashboard()
        
        # Создаём inline кнопки
        buttons = [
            [
                Button.inline("🔄 Обновить", b"dashboard_refresh"),
                Button.inline("📊 Сеть", b"dashboard_network")
            ],
            [
                Button.inline("📈 Компактно", b"dashboard_compact"),
                Button.inline("❌ Закрыть", b"dashboard_close")
            ]
        ]
        
        # Отправляем дашборд
        await event.reply(dashboard_text, buttons=buttons)
    
    logger.info("Dashboard button handler registered")
