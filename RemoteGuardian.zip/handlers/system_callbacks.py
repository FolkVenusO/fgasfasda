"""
Callback handlers для inline кнопок системных команд
"""

from telethon import events, Button
import psutil
import platform
import time
from datetime import timedelta
import logging

logger = logging.getLogger(__name__)


def register_system_callbacks(bot):
    """Регистрирует callback handlers для системных команд."""
    
    # === SYSINFO CALLBACKS ===
    
    @bot.on(events.CallbackQuery(pattern=b"sysinfo_refresh"))
    async def sysinfo_refresh(event):
        """Обновляет информацию о системе."""
        try:
            cpu_percent = psutil.cpu_percent(interval=1)
            cpu_count = psutil.cpu_count(logical=False)
            cpu_threads = psutil.cpu_count(logical=True)
            cpu_freq = psutil.cpu_freq()
            mem = psutil.virtual_memory()
            disk = psutil.disk_usage('C:\\')
            uptime = str(timedelta(seconds=int(time.time() - psutil.boot_time())))
            
            msg = (
                f"🖥 **Информация о системе:**\n\n"
                f"**💻 ОС:** {platform.system()} {platform.release()}\n"
                f"**⚙️ CPU:** {platform.processor()}\n"
                f"└ Ядер: {cpu_count} ({cpu_threads} потоков)\n"
                f"└ Загрузка: {cpu_percent}%\n\n"
                f"**💾 RAM:** {mem.used/(1024**3):.1f}/{mem.total/(1024**3):.1f} GB ({mem.percent}%)\n"
                f"**💿 Диск C:\\:** {disk.used/(1024**3):.1f}/{disk.total/(1024**3):.1f} GB ({disk.percent}%)\n"
                f"**⏱ Uptime:** {uptime}"
            )
            
            buttons = [
                [
                    Button.inline("🔄 Обновить", b"sysinfo_refresh"),
                    Button.inline("🌡️ Температуры", b"sysinfo_temp")
                ],
                [
                    Button.inline("⚙️ Процессы", b"sysinfo_processes"),
                    Button.inline("💿 Диски", b"sysinfo_disks")
                ],
                [
                    Button.inline("📊 Дашборд", b"sysinfo_dashboard")
                ]
            ]
            
            await event.edit(msg, buttons=buttons)
            await event.answer("✅ Обновлено!", alert=False)
            
        except Exception as e:
            logger.error(f"Error refreshing sysinfo: {e}")
            await event.answer("❌ Ошибка обновления", alert=True)
    
    
    @bot.on(events.CallbackQuery(pattern=b"sysinfo_temp"))
    async def sysinfo_temp(event):
        """Показывает температуры."""
        try:
            msg = "🌡 **Температуры:**\n\n"
            temp_found = False
            
            # Через psutil
            try:
                if hasattr(psutil, 'sensors_temperatures'):
                    temps = psutil.sensors_temperatures()
                    if temps:
                        for name, entries in temps.items():
                            for entry in entries:
                                msg += f"**{entry.label or name}:** {entry.current:.1f}°C\n"
                                temp_found = True
            except Exception:
                pass
            
            # Через WMI
            if not temp_found:
                try:
                    import wmi
                    w = wmi.WMI(namespace="root\\OpenHardwareMonitor")
                    sensors = w.Sensor()
                    for s in sensors:
                        if s.SensorType == 'Temperature':
                            msg += f"**{s.Name}:** {s.Value:.1f}°C\n"
                            temp_found = True
                except:
                    pass
            
            if not temp_found:
                msg += (
                    "❌ Температуры недоступны.\n\n"
                    "**Как включить:**\n"
                    "1. Скачай Open Hardware Monitor\n"
                    "2. Запусти от Администратора\n"
                    "3. Попробуй снова"
                )
            
            buttons = [
                [Button.inline("🔄 Обновить", b"sysinfo_temp")],
                [Button.inline("⬅️ Назад", b"sysinfo_refresh")]
            ]
            
            await event.edit(msg, buttons=buttons)
            
        except Exception as e:
            logger.error(f"Error getting temperatures: {e}")
            await event.answer("❌ Ошибка", alert=True)
    
    
    @bot.on(events.CallbackQuery(pattern=b"sysinfo_processes"))
    async def sysinfo_processes(event):
        """Показывает топ процессов."""
        try:
            processes = sorted(
                [p.info for p in psutil.process_iter(['pid', 'name', 'memory_info']) 
                 if p.info.get('memory_info')],
                key=lambda p: p['memory_info'].rss,
                reverse=True
            )[:10]
            
            msg = "⚙️ **Топ-10 процессов по RAM:**\n\n"
            for i, p in enumerate(processes, 1):
                mem_mb = p['memory_info'].rss / (1024 * 1024)
                msg += f"{i}. `{p['name'][:20]}` - {mem_mb:.1f} MB\n"
            
            buttons = [
                [Button.inline("🔄 Обновить", b"sysinfo_processes")],
                [Button.inline("⬅️ Назад", b"sysinfo_refresh")]
            ]
            
            await event.edit(msg, buttons=buttons)
            
        except Exception as e:
            logger.error(f"Error getting processes: {e}")
            await event.answer("❌ Ошибка", alert=True)
    
    
    @bot.on(events.CallbackQuery(pattern=b"sysinfo_disks"))
    async def sysinfo_disks(event):
        """Показывает информацию о дисках."""
        try:
            msg = "💿 **Диски:**\n\n"
            
            for partition in psutil.disk_partitions():
                try:
                    usage = psutil.disk_usage(partition.mountpoint)
                    total_gb = usage.total / (1024**3)
                    used_gb = usage.used / (1024**3)
                    free_gb = usage.free / (1024**3)
                    
                    msg += f"**{partition.device}** ({partition.fstype})\n"
                    msg += f"└ {used_gb:.1f}/{total_gb:.1f} GB ({usage.percent}%)\n"
                    msg += f"└ Свободно: {free_gb:.1f} GB\n\n"
                except:
                    msg += f"**{partition.device}** - ⛔️ Нет доступа\n\n"
            
            buttons = [
                [Button.inline("🔄 Обновить", b"sysinfo_disks")],
                [Button.inline("⬅️ Назад", b"sysinfo_refresh")]
            ]
            
            await event.edit(msg, buttons=buttons)
            
        except Exception as e:
            logger.error(f"Error getting disks: {e}")
            await event.answer("❌ Ошибка", alert=True)
    
    
    @bot.on(events.CallbackQuery(pattern=b"sysinfo_dashboard"))
    async def sysinfo_to_dashboard(event):
        """Переключает на дашборд."""
        try:
            from utils.dashboard import format_dashboard
            
            dashboard_text = format_dashboard()
            
            buttons = [
                [
                    Button.inline("🔄 Обновить", b"dashboard_refresh"),
                    Button.inline("📊 Сеть", b"dashboard_network")
                ],
                [
                    Button.inline("📈 Компактно", b"dashboard_compact"),
                    Button.inline("❌ Закрыть", b"dashboard_close")
                ]
            ]
            
            await event.edit(dashboard_text, buttons=buttons)
            
        except Exception as e:
            logger.error(f"Error switching to dashboard: {e}")
            await event.answer("❌ Ошибка", alert=True)
    
    
    # === SHUTDOWN/RESTART CONFIRMATION ===
    
    @bot.on(events.CallbackQuery(pattern=b"confirm_shutdown"))
    async def confirm_shutdown(event):
        """Подтверждает выключение ПК."""
        try:
            from core.winapi import shutdown_pc
            import asyncio
            
            await event.edit("⚠️ **Выключение ПК через 3 секунды...**")
            await asyncio.sleep(3)
            await asyncio.to_thread(shutdown_pc)
            
        except Exception as e:
            logger.error(f"Error shutting down: {e}")
            await event.answer("❌ Ошибка", alert=True)
    
    
    @bot.on(events.CallbackQuery(pattern=b"confirm_restart"))
    async def confirm_restart(event):
        """Подтверждает перезагрузку ПК."""
        try:
            from core.winapi import restart_pc
            import asyncio
            
            await event.edit("🔄 **Перезагрузка через 3 секунды...**")
            await asyncio.sleep(3)
            await asyncio.to_thread(restart_pc)
            
        except Exception as e:
            logger.error(f"Error restarting: {e}")
            await event.answer("❌ Ошибка", alert=True)
    
    
    @bot.on(events.CallbackQuery(pattern=b"cancel_action"))
    async def cancel_action(event):
        """Отменяет действие."""
        await event.edit("❌ **Действие отменено**")
        await event.answer("Отменено", alert=False)
    
    
    logger.info("System callback handlers registered")
