"""
Обработчики команд для управления умными уведомлениями (триггерами)
"""

from telethon import events, Button
from core.decorators import with_verify
from utils.triggers import (
    TRIGGERS,
    get_trigger_status,
    set_trigger_enabled,
    save_triggers_config
)
import logging

logger = logging.getLogger(__name__)


# Описания триггеров на русском
TRIGGER_NAMES = {
    'high_cpu': '🔥 Высокий CPU (>90% дольше 5 мин)',
    'high_temp': '🌡️ Высокая температура (>85°C)',
    'low_disk': '💾 Мало места на диске (<10%)',
    'usb_connected': '🔌 USB устройство подключено',
    'usb_disconnected': '🔌 USB устройство отключено',
    'ip_changed': '🌐 Смена IP адреса',
    'login_detected': '🚪 Вход в систему',
    'battery_low': '🔋 Низкий заряд батареи (<20%)',
}


def register_triggers(bot):
    """Регистрирует обработчики команд для управления триггерами."""
    
    @bot.on(events.NewMessage(pattern=r'^/triggers$'))
    @with_verify("Triggers Settings", dangerous=False)
    async def show_triggers(event):
        """Показывает настройки триггеров."""
        status = get_trigger_status()
        
        message = "🔔 **УМНЫЕ УВЕДОМЛЕНИЯ**\n\n"
        message += "Автоматические алерты о важных событиях:\n\n"
        
        # Группируем по категориям
        system_triggers = ['high_cpu', 'high_temp', 'low_disk']
        hardware_triggers = ['usb_connected', 'usb_disconnected', 'battery_low']
        network_triggers = ['ip_changed']
        security_triggers = ['login_detected']
        
        def format_triggers(triggers_list, category_name):
            text = f"**{category_name}:**\n"
            for trigger in triggers_list:
                if trigger in TRIGGERS:
                    enabled = status.get(trigger, False)
                    icon = "✅" if enabled else "❌"
                    name = TRIGGER_NAMES.get(trigger, trigger)
                    text += f"{icon} {name}\n"
            return text + "\n"
        
        message += format_triggers(system_triggers, "⚙️ Система")
        message += format_triggers(hardware_triggers, "🔌 Оборудование")
        message += format_triggers(network_triggers, "🌐 Сеть")
        message += format_triggers(security_triggers, "🔒 Безопасность")
        
        # Создаём кнопки
        buttons = [
            [Button.inline("⚙️ Настроить", b"triggers_settings")],
            [Button.inline("✅ Включить все", b"triggers_enable_all")],
            [Button.inline("❌ Выключить все", b"triggers_disable_all")],
            [Button.inline("📊 Статистика", b"triggers_stats")]
        ]
        
        await event.reply(message, buttons=buttons)
    
    
    @bot.on(events.CallbackQuery(pattern=b"triggers_settings"))
    async def triggers_settings(event):
        """Показывает меню настроек триггеров."""
        message = "⚙️ **НАСТРОЙКА ТРИГГЕРОВ**\n\nВыберите триггер для настройки:\n"
        
        # Создаём кнопки для каждого триггера
        buttons = []
        
        for trigger_name, trigger_obj in TRIGGERS.items():
            label = TRIGGER_NAMES.get(trigger_name, trigger_name)
            icon = "✅" if trigger_obj.enabled else "❌"
            buttons.append([
                Button.inline(f"{icon} {label}", f"trigger_toggle_{trigger_name}".encode())
            ])
        
        buttons.append([Button.inline("⬅️ Назад", b"triggers_back")])
        
        await event.edit(message, buttons=buttons)
    
    
    @bot.on(events.CallbackQuery(pattern=rb"trigger_toggle_(.+)"))
    async def toggle_trigger(event):
        """Переключает состояние триггера."""
        trigger_name = event.pattern_match.group(1).decode()
        
        if trigger_name in TRIGGERS:
            # Переключаем состояние
            current_state = TRIGGERS[trigger_name].enabled
            set_trigger_enabled(trigger_name, not current_state)
            
            new_state = "включен" if not current_state else "выключен"
            trigger_label = TRIGGER_NAMES.get(trigger_name, trigger_name)
            
            await event.answer(f"{trigger_label} {new_state}", alert=False)
            
            # Обновляем меню
            await triggers_settings(event)
        else:
            await event.answer("❌ Триггер не найден", alert=True)
    
    
    @bot.on(events.CallbackQuery(pattern=b"triggers_enable_all"))
    async def enable_all_triggers(event):
        """Включает все триггеры."""
        for trigger_name in TRIGGERS.keys():
            set_trigger_enabled(trigger_name, True)
        
        await event.answer("✅ Все триггеры включены", alert=False)
        
        # Обновляем меню
        await show_triggers_callback(event)
    
    
    @bot.on(events.CallbackQuery(pattern=b"triggers_disable_all"))
    async def disable_all_triggers(event):
        """Выключает все триггеры."""
        for trigger_name in TRIGGERS.keys():
            set_trigger_enabled(trigger_name, False)
        
        await event.answer("❌ Все триггеры выключены", alert=False)
        
        # Обновляем меню
        await show_triggers_callback(event)
    
    
    @bot.on(events.CallbackQuery(pattern=b"triggers_stats"))
    async def triggers_statistics(event):
        """Показывает статистику срабатываний триггеров."""
        message = "📊 **СТАТИСТИКА ТРИГГЕРОВ**\n\n"
        
        any_triggered = False
        for trigger_name, trigger_obj in TRIGGERS.items():
            if trigger_obj.last_triggered:
                label = TRIGGER_NAMES.get(trigger_name, trigger_name)
                time_str = trigger_obj.last_triggered.strftime('%H:%M:%S %d.%m.%Y')
                message += f"**{label}**\n"
                message += f"└ Последнее: {time_str}\n\n"
                any_triggered = True
        
        if not any_triggered:
            message += "Триггеры ещё не срабатывали.\n"
        
        buttons = [[Button.inline("⬅️ Назад", b"triggers_back")]]
        
        await event.edit(message, buttons=buttons)
    
    
    @bot.on(events.CallbackQuery(pattern=b"triggers_back"))
    async def triggers_back(event):
        """Возврат к главному меню триггеров."""
        await show_triggers_callback(event)
    
    
    async def show_triggers_callback(event):
        """Callback версия show_triggers для обновления меню."""
        status = get_trigger_status()
        
        message = "🔔 **УМНЫЕ УВЕДОМЛЕНИЯ**\n\n"
        message += "Автоматические алерты о важных событиях:\n\n"
        
        system_triggers = ['high_cpu', 'high_temp', 'low_disk']
        hardware_triggers = ['usb_connected', 'usb_disconnected', 'battery_low']
        network_triggers = ['ip_changed']
        security_triggers = ['login_detected']
        
        def format_triggers(triggers_list, category_name):
            text = f"**{category_name}:**\n"
            for trigger in triggers_list:
                if trigger in TRIGGERS:
                    enabled = status.get(trigger, False)
                    icon = "✅" if enabled else "❌"
                    name = TRIGGER_NAMES.get(trigger, trigger)
                    text += f"{icon} {name}\n"
            return text + "\n"
        
        message += format_triggers(system_triggers, "⚙️ Система")
        message += format_triggers(hardware_triggers, "🔌 Оборудование")
        message += format_triggers(network_triggers, "🌐 Сеть")
        message += format_triggers(security_triggers, "🔒 Безопасность")
        
        buttons = [
            [Button.inline("⚙️ Настроить", b"triggers_settings")],
            [Button.inline("✅ Включить все", b"triggers_enable_all")],
            [Button.inline("❌ Выключить все", b"triggers_disable_all")],
            [Button.inline("📊 Статистика", b"triggers_stats")]
        ]
        
        await event.edit(message, buttons=buttons)
    
    
    @bot.on(events.NewMessage(pattern=r'^/triggers (on|off) (.+)'))
    @with_verify("Toggle Trigger", dangerous=False)
    async def toggle_trigger_cmd(event):
        """Быстрое включение/выключение триггера через команду."""
        action = event.pattern_match.group(1)
        trigger_name = event.pattern_match.group(2)
        
        if trigger_name not in TRIGGERS:
            available = ", ".join(TRIGGERS.keys())
            return await event.reply(
                f"❌ Триггер '{trigger_name}' не найден.\n\n"
                f"Доступные триггеры:\n{available}\n\n"
                f"Используйте: `/triggers on {list(TRIGGERS.keys())[0]}`"
            )
        
        enabled = (action == 'on')
        set_trigger_enabled(trigger_name, enabled)
        
        label = TRIGGER_NAMES.get(trigger_name, trigger_name)
        state = "включен" if enabled else "выключен"
        
        await event.reply(f"✅ {label} {state}")
    
    
    logger.info("Triggers handlers registered")
