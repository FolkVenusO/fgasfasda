"""
Обработчики команд для системного дашборда
"""

from telethon import events, Button
from core.decorators import with_verify
from utils.dashboard import (
    format_dashboard,
    format_dashboard_compact,
    set_bot_start_time,
    get_network_speed_async
)
import asyncio
import logging

logger = logging.getLogger(__name__)

# Словарь для хранения сообщений дашборда (для авто-обновления)
_dashboard_messages = {}


def register_dashboard(bot):
    """Регистрирует обработчики команд дашборда."""
    
    # Устанавливаем время запуска бота
    set_bot_start_time()
    
    @bot.on(events.NewMessage(pattern=r'^/dashboard$'))
    @with_verify("Dashboard", dangerous=False)
    async def show_dashboard(event):
        """Показывает полный системный дашборд."""
        user_id = event.sender_id
        
        # Формируем дашборд
        dashboard_text = format_dashboard()
        
        # Создаём inline кнопки
        buttons = [
            [
                Button.inline("🔄 Обновить", b"dashboard_refresh"),
                Button.inline("📊 Сеть", b"dashboard_network")
            ],
            [
                Button.inline("📈 Компактно", b"dashboard_compact"),
                Button.inline("❌ Закрыть", b"dashboard_close")
            ]
        ]
        
        # Отправляем сообщение
        msg = await event.reply(dashboard_text, buttons=buttons)
        
        # Сохраняем ID сообщения для обновления
        _dashboard_messages[user_id] = msg.id
    
    
    @bot.on(events.NewMessage(pattern=r'^/dash$'))
    @with_verify("Dashboard Compact", dangerous=False)
    async def show_dashboard_compact(event):
        """Показывает компактную версию дашборда."""
        compact = format_dashboard_compact()
        
        buttons = [
            [Button.inline("📊 Полный", b"dashboard_full")],
            [Button.inline("🔄 Обновить", b"dashboard_refresh_compact")]
        ]
        
        await event.reply(compact, buttons=buttons)
    
    
    @bot.on(events.CallbackQuery(pattern=b"dashboard_refresh"))
    async def refresh_dashboard(event):
        """Обновляет дашборд при нажатии кнопки."""
        try:
            # Формируем обновлённый дашборд
            dashboard_text = format_dashboard()
            
            # Кнопки остаются те же
            buttons = [
                [
                    Button.inline("🔄 Обновить", b"dashboard_refresh"),
                    Button.inline("📊 Сеть", b"dashboard_network")
                ],
                [
                    Button.inline("📈 Компактно", b"dashboard_compact"),
                    Button.inline("❌ Закрыть", b"dashboard_close")
                ]
            ]
            
            # Редактируем сообщение
            await event.edit(dashboard_text, buttons=buttons)
            
            # Уведомляем пользователя
            await event.answer("✅ Дашборд обновлён!", alert=False)
            
        except Exception as e:
            logger.error(f"Error refreshing dashboard: {e}")
            await event.answer("❌ Ошибка обновления", alert=True)
    
    
    @bot.on(events.CallbackQuery(pattern=b"dashboard_network"))
    async def show_network_info(event):
        """Показывает информацию о сети."""
        try:
            await event.answer("⏳ Измеряю скорость...", alert=False)
            
            # Получаем скорость сети (занимает ~1 сек)
            net_speed = await get_network_speed_async()
            
            download_str = f"{net_speed['download_mbps']:.2f} MB/s"
            upload_str = f"{net_speed['upload_mbps']:.2f} MB/s"
            
            network_text = f"""🌐 **СЕТЕВАЯ АКТИВНОСТЬ:**

⬇️ **Download:** {download_str}
⬆️ **Upload:** {upload_str}

_Измерение за последнюю секунду_"""
            
            buttons = [
                [Button.inline("🔄 Обновить", b"dashboard_network")],
                [Button.inline("⬅️ Назад", b"dashboard_refresh")]
            ]
            
            await event.edit(network_text, buttons=buttons)
            
        except Exception as e:
            logger.error(f"Error getting network info: {e}")
            await event.answer("❌ Ошибка получения данных", alert=True)
    
    
    @bot.on(events.CallbackQuery(pattern=b"dashboard_compact"))
    async def switch_to_compact(event):
        """Переключает на компактный вид."""
        try:
            compact = format_dashboard_compact()
            
            buttons = [
                [Button.inline("📊 Полный", b"dashboard_full")],
                [Button.inline("🔄 Обновить", b"dashboard_refresh_compact")]
            ]
            
            await event.edit(compact, buttons=buttons)
            await event.answer("Компактный режим", alert=False)
            
        except Exception as e:
            logger.error(f"Error switching to compact: {e}")
            await event.answer("❌ Ошибка", alert=True)
    
    
    @bot.on(events.CallbackQuery(pattern=b"dashboard_full"))
    async def switch_to_full(event):
        """Переключает на полный вид."""
        try:
            dashboard_text = format_dashboard()
            
            buttons = [
                [
                    Button.inline("🔄 Обновить", b"dashboard_refresh"),
                    Button.inline("📊 Сеть", b"dashboard_network")
                ],
                [
                    Button.inline("📈 Компактно", b"dashboard_compact"),
                    Button.inline("❌ Закрыть", b"dashboard_close")
                ]
            ]
            
            await event.edit(dashboard_text, buttons=buttons)
            await event.answer("Полный режим", alert=False)
            
        except Exception as e:
            logger.error(f"Error switching to full: {e}")
            await event.answer("❌ Ошибка", alert=True)
    
    
    @bot.on(events.CallbackQuery(pattern=b"dashboard_refresh_compact"))
    async def refresh_compact(event):
        """Обновляет компактный дашборд."""
        try:
            compact = format_dashboard_compact()
            
            buttons = [
                [Button.inline("📊 Полный", b"dashboard_full")],
                [Button.inline("🔄 Обновить", b"dashboard_refresh_compact")]
            ]
            
            await event.edit(compact, buttons=buttons)
            await event.answer("✅ Обновлено!", alert=False)
            
        except Exception as e:
            logger.error(f"Error refreshing compact: {e}")
            await event.answer("❌ Ошибка", alert=True)
    
    
    @bot.on(events.CallbackQuery(pattern=b"dashboard_close"))
    async def close_dashboard(event):
        """Закрывает дашборд."""
        try:
            user_id = event.sender_id
            
            # Удаляем сообщение из словаря
            if user_id in _dashboard_messages:
                del _dashboard_messages[user_id]
            
            # Удаляем сообщение
            await event.delete()
            
        except Exception as e:
            logger.error(f"Error closing dashboard: {e}")
            await event.answer("❌ Ошибка удаления", alert=True)
    
    
    @bot.on(events.NewMessage(pattern=r'^/dashboard auto$'))
    @with_verify("Dashboard Auto-Refresh", dangerous=False)
    async def dashboard_auto_refresh(event):
        """Запускает авто-обновляющийся дашборд (каждые 5 сек)."""
        user_id = event.sender_id
        
        # Формируем дашборд
        dashboard_text = format_dashboard()
        
        buttons = [
            [Button.inline("⏸️ Остановить", b"dashboard_stop_auto")],
            [Button.inline("❌ Закрыть", b"dashboard_close")]
        ]
        
        msg = await event.reply(
            f"{dashboard_text}\n\n🔄 **Авто-обновление:** Каждые 5 секунд",
            buttons=buttons
        )
        
        # Запускаем цикл обновления
        asyncio.create_task(_auto_refresh_loop(bot, user_id, msg.id))
    
    
    async def _auto_refresh_loop(bot, user_id: int, message_id: int):
        """Цикл авто-обновления дашборда."""
        try:
            # Максимум 60 обновлений (5 минут)
            for _ in range(60):
                await asyncio.sleep(5)
                
                # Проверяем что сообщение ещё активно
                if user_id not in _dashboard_messages or _dashboard_messages[user_id] != message_id:
                    break
                
                # Формируем новый дашборд
                dashboard_text = format_dashboard()
                
                buttons = [
                    [Button.inline("⏸️ Остановить", b"dashboard_stop_auto")],
                    [Button.inline("❌ Закрыть", b"dashboard_close")]
                ]
                
                try:
                    # Обновляем сообщение
                    await bot.edit_message(
                        user_id,
                        message_id,
                        f"{dashboard_text}\n\n🔄 **Авто-обновление:** Каждые 5 секунд",
                        buttons=buttons
                    )
                except Exception as e:
                    logger.debug(f"Auto-refresh stopped: {e}")
                    break
                    
        except Exception as e:
            logger.error(f"Error in auto-refresh loop: {e}")
    
    
    @bot.on(events.CallbackQuery(pattern=b"dashboard_stop_auto"))
    async def stop_auto_refresh(event):
        """Останавливает авто-обновление."""
        try:
            user_id = event.sender_id
            
            # Удаляем из словаря (это остановит цикл)
            if user_id in _dashboard_messages:
                del _dashboard_messages[user_id]
            
            # Переключаем на обычный дашборд
            dashboard_text = format_dashboard()
            
            buttons = [
                [
                    Button.inline("🔄 Обновить", b"dashboard_refresh"),
                    Button.inline("📊 Сеть", b"dashboard_network")
                ],
                [
                    Button.inline("📈 Компактно", b"dashboard_compact"),
                    Button.inline("❌ Закрыть", b"dashboard_close")
                ]
            ]
            
            await event.edit(dashboard_text, buttons=buttons)
            await event.answer("⏸️ Авто-обновление остановлено", alert=False)
            
        except Exception as e:
            logger.error(f"Error stopping auto-refresh: {e}")
            await event.answer("❌ Ошибка", alert=True)
    
    
    logger.info("Dashboard handlers registered")
