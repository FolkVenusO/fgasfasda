import os
import uuid
from telethon import events, Button
from core.decorators import with_verify
from config import MAIN_ADMINS

# Кэш путей (чтобы обходить лимит Телеграма на размер данных в кнопках)
fm_cache = {}

def register_files(bot):
    @bot.on(events.NewMessage(func=lambda e: e.text == '📂 Файлы (Диск C)'))
    @with_verify("Open Root FM", dangerous=True)
    async def start_ls(event): 
        await send_fm_menu(event, "C:\\")

    @bot.on(events.NewMessage(pattern=r'^/ls(?: (.*))?'))
    @with_verify("Browse Files", dangerous=True)
    async def ls_dir(event):
        p = event.pattern_match.group(1)
        await send_fm_menu(event, p.strip() if p else "C:\\")

    async def send_fm_menu(event, path):
        from utils.security_validators import validate_file_path
        
        # ✅ БЕЗОПАСНОСТЬ: Проверка пути на path traversal
        is_safe, reason = validate_file_path(path)
        if not is_safe:
            import logging
            logging.getLogger(__name__).warning(
                f"Blocked file access: path={path}, reason={reason}, user={event.sender_id}"
            )
            return await event.reply(
                f"🚫 **Доступ запрещён**\\n\\n"
                f"**Причина:** {reason}\\n\\n"
                f"⚠️ Системные директории защищены от просмотра"
            )
        
        # Чистим кэш если вырос больше 500 записей
        if len(fm_cache) > 500:
            fm_cache.clear()
        if not os.path.exists(path):
            return await event.reply(f"❌ Путь не найден: {path}")
        try:
            items = os.listdir(path)
            # Ограничение на 10 элементов, чтобы не упасть по лимитам кнопок
            folders = sorted([i for i in items if os.path.isdir(os.path.join(path, i))])[:10]
            files = sorted([i for i in items if os.path.isfile(os.path.join(path, i))])[:10]
            
            kb = []
            parent = os.path.dirname(path)
            if parent and parent != path:
                pid = str(uuid.uuid4())[:8]; fm_cache[pid] = parent
                kb.append([Button.inline("⬅️ Назад", b"fm_" + pid.encode())])
            
            for f in folders:
                pid = str(uuid.uuid4())[:8]; fm_cache[pid] = os.path.join(path, f)
                kb.append([Button.inline(f"📁 {f}", b"fm_" + pid.encode())])
                
            for f in files:
                pid = str(uuid.uuid4())[:8]; fm_cache[pid] = os.path.join(path, f)
                kb.append([Button.inline(f"📄 {f}", b"fmdl_" + pid.encode())])
            
            text = f"📂 **Путь:** `{path}`\n*(Показаны первые 10 элементов)*"
            if hasattr(event, 'data'): await event.edit(text, buttons=kb)
            else: await event.reply(text, buttons=kb)
        except Exception as e:
            msg = f"❌ Ошибка доступа: {e}"
            if hasattr(event, 'data'): await event.edit(msg)
            else: await event.reply(msg)

    @bot.on(events.CallbackQuery(pattern=b'^fm_(.*)'))
    async def fm_nav(event):
        if str(event.sender_id) not in MAIN_ADMINS: 
            return await event.answer("⛔️ Отказано.", alert=True)
        pid = event.pattern_match.group(1).decode()
        if pid in fm_cache: await send_fm_menu(event, fm_cache[pid])
        else: await event.answer("Кэш устарел. Отправьте /ls заново.", alert=True)

    @bot.on(events.CallbackQuery(pattern=b'^fmdl_(.*)'))
    async def fm_dl(event):
        if str(event.sender_id) not in MAIN_ADMINS: 
            return await event.answer("⛔️ Отказано.", alert=True)
        pid = event.pattern_match.group(1).decode()
        path = fm_cache.get(pid)
        if not path or not os.path.exists(path):
            return await event.answer("Файл не найден.", alert=True)
        
        # Проверка размера файла (лимит Telegram Bot API: 50 МБ)
        try:
            file_size = os.path.getsize(path)
            max_size = 50 * 1024 * 1024  # 50 МБ в байтах
            
            if file_size > max_size:
                size_mb = file_size / (1024 * 1024)
                return await event.answer(
                    f"❌ Файл слишком большой: {size_mb:.1f} МБ\n"
                    f"Telegram Bot API лимит: 50 МБ",
                    alert=True
                )
            
            await event.answer("Загружаю файл...", alert=False)
            await event.respond(f"📁 Отправляю `{os.path.basename(path)}` ({file_size / 1024:.1f} КБ):", file=path)
        except Exception as e:
            await event.answer(f"❌ Ошибка: {e}", alert=True)