import asyncio
import os
import subprocess
import webbrowser
import pyttsx3
import pythoncom
import pygame
from telethon import events
from core.decorators import with_verify
from core.audio_com import get_volume_interface, set_max_volume_and_get_current
from config import ASSETS_DIR, FFMPEG_EXE

def get_media_duration(filepath: str) -> float:
    """Получает длительность медиафайла в секундах через ffprobe."""
    try:
        ffprobe = FFMPEG_EXE.replace('ffmpeg.exe', 'ffprobe.exe')
        if not os.path.exists(ffprobe):
            ffprobe = 'ffprobe'
        result = subprocess.run(
            [ffprobe, '-v', 'error', '-show_entries', 'format=duration',
             '-of', 'default=noprint_wrappers=1:nokey=1', filepath],
            capture_output=True, text=True, timeout=10
        )
        return float(result.stdout.strip())
    except Exception:
        return 0.0

def kill_video_players():
    """Завершает все известные видеоплееры напрямую через WinAPI."""
    from core.winapi import media_controller
    # Используем прямое управление через WinAPI вместо taskkill
    killed = media_controller.stop_all_known_players()
    return killed

def register_cyber(bot):
    @bot.on(events.NewMessage(pattern=r'^/vol(?: (\d+))?$'))
    @with_verify("Set Volume", dangerous=False)
    async def set_vol(event):
        val_str = event.pattern_match.group(1)
        if not val_str:
            return await event.reply(
                "🔊 **Команда /vol** — установить громкость\n\n"
                "**Использование:**\n"
                "`/vol <0-100>`\n\n"
                "**Примеры:**\n"
                "`/vol 50` — установить громкость на 50%\n"
                "`/vol 0` — выключить звук\n"
                "`/vol 100` — максимальная громкость\n\n"
                "💡 Или используй `/mute` для быстрого выключения звука"
            )
        val = int(val_str)
        val = max(0, min(100, val))
        vi = get_volume_interface()
        if vi:
            vi.SetMasterVolumeLevelScalar(val/100.0, None)
            vi.SetMute(0, None)
            await event.reply(f"🎚 Громкость ПК установлена на: **{val}%**")
        else:
            await event.reply("❌ Ошибка управления звуком.")

    @bot.on(events.NewMessage(func=lambda e: e.text in ['/mute', '/unmute']))
    @with_verify("Toggle Mute", dangerous=False)
    async def toggle_mute(event):
        is_mute = 1 if event.text == '/mute' else 0
        vi = get_volume_interface()
        if vi:
            vi.SetMute(is_mute, None)
            await event.reply("🔇 Звук выключен" if is_mute else "🔊 Звук включен")

    @bot.on(events.NewMessage(pattern=r'^/say(?: (.+))?$'))
    @with_verify("TTS Speak", dangerous=False)
    async def tts_say(event):
        txt = event.pattern_match.group(1)
        if not txt:
            return await event.reply(
                "🔊 **Команда /say** — озвучить текст на ПК\n\n"
                "**Использование:**\n"
                "`/say <текст>`\n\n"
                "**Примеры:**\n"
                "`/say Привет мир` — озвучит голосом Windows\n"
                "`/say Hello world` — работает и на английском"
            )
        txt = txt.strip()
        def _do():
            pythoncom.CoInitialize()
            try:
                eng = pyttsx3.init()
                eng.say(txt)
                eng.runAndWait()
            finally: 
                pythoncom.CoUninitialize()
        await asyncio.to_thread(_do)
        await event.reply(f"🗣 ПК произнес: `{txt}`")

    @bot.on(events.NewMessage(pattern=r'^/open(?: (.+))?$'))
    @with_verify("Open Browser URL", dangerous=False)
    async def open_url(event):
        url = event.pattern_match.group(1)
        if not url:
            return await event.reply(
                "🌐 **Команда /open** — открыть ссылку в браузере\n\n"
                "**Использование:**\n"
                "`/open <URL>`\n\n"
                "**Примеры:**\n"
                "`/open https://google.com`\n"
                "`/open youtube.com`"
            )
        url = url.strip()
        if not url.startswith('http'):
            url = 'https://' + url
        webbrowser.open(url)
        await event.reply(f"🌐 Ссылка открыта в браузере: {url}")

    @bot.on(events.NewMessage(pattern=r'^/stop$'))
    @with_verify("Stop All Media", dangerous=False)
    async def stop_all_media(event):
        """Останавливает всё аудио и видео."""
        # Останавливаем pygame музыку
        if pygame.mixer.music.get_busy():
            pygame.mixer.music.stop()
        
        # Закрываем видеоплееры
        kill_video_players()
        
        await event.reply("⏹ Всё аудио и видео остановлено!")
    
    @bot.on(events.NewMessage(func=lambda e: e.text == '🔊 Сирена'))
    @with_verify("Play Siren", dangerous=False)
    async def play_siren(event):
        siren_path = os.path.join(ASSETS_DIR, "siren.mp3")
        if not os.path.exists(siren_path): 
            return await event.reply("❌ Нет звука сирены.")

        duration = get_media_duration(siren_path)
        await event.reply(f"🔊 Врубаю сирену на максимум... ({duration:.1f} сек)")
        vol_interface, old_volume = set_max_volume_and_get_current()
        try:
            pygame.mixer.music.load(siren_path)
            pygame.mixer.music.play()
            # Ждём ровно столько, сколько длится трек
            if duration > 0:
                await asyncio.sleep(duration)
                pygame.mixer.music.stop()
            else:
                while pygame.mixer.music.get_busy():
                    await asyncio.sleep(0.5)
        finally:
            if vol_interface and old_volume is not None: 
                vol_interface.SetMasterVolumeLevelScalar(old_volume, None)
        await event.reply("✅ Сирена отработала.")

    @bot.on(events.NewMessage(func=lambda e: e.text == '👻 Скример'))
    @with_verify("Play Screamer", dangerous=False)
    async def play_screamer(event):
        from core.winapi import send_keypress, VK_F11, media_controller
        import psutil
        
        scr_path = os.path.join(ASSETS_DIR, "screamer.mp4")
        if not os.path.exists(scr_path): 
            return await event.reply("❌ Нет видео скримера.")

        duration = get_media_duration(scr_path)
        await event.reply(f"👻 Скример запущен! ({duration:.1f} сек)")
        vol_interface, old_volume = set_max_volume_and_get_current()
        
        player_pid = None
        try:
            # Запускаем плеер и получаем его PID
            os.startfile(scr_path)
            await asyncio.sleep(2)  # Ждём запуска плеера
            
            # Находим PID запущенного плеера
            for proc in psutil.process_iter(['pid', 'name', 'create_time']):
                try:
                    if proc.info['name'].lower() in ['wmplayer.exe', 'movies.ui.exe', 'vlc.exe']:
                        # Берём самый новый процесс (только что запущенный)
                        player_pid = proc.info['pid']
                        media_controller.track_player(player_pid, proc.info['name'])
                        break
                except:
                    pass
            
            # Полноэкранный режим через WinAPI (не pyautogui!)
            send_keypress(VK_F11)
            
            # Ждём минимум 12 секунд
            wait = max(12.0, duration - 2.0) if duration > 0 else 12.0
            await asyncio.sleep(wait)
        finally:
            if vol_interface and old_volume is not None: 
                vol_interface.SetMasterVolumeLevelScalar(old_volume, None)
            # Останавливаем только наш плеер (не все!)
            if media_controller.active_players:
                media_controller.stop_all_tracked()
            else:
                kill_video_players()
        await event.reply("👻 Скример отработал.")