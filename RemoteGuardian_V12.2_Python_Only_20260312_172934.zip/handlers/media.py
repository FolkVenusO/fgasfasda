import os
import asyncio
import subprocess
import yt_dlp
import pygame
import pyautogui  # Добавлено для управления системными клавишами
from telethon import events, Button
from core.decorators import with_verify
from core.state import state
from config import ASSETS_DIR, FFMPEG_EXE
from handlers.cyber import get_media_duration, kill_video_players

def register_media(bot):
    # --- ТВОИ СУЩЕСТВУЮЩИЕ ФУНКЦИИ ---

    @bot.on(events.NewMessage(func=lambda e: e.text in ['🔽 Загрузить медиа']))
    @with_verify("Download Media Prompt", dangerous=False)
    async def download_media_prompt(event):
        await event.reply(
            "📥 **Загрузка медиа с YouTube**\n\n"
            "Отправь команду:\n"
            "`/getmedia <ссылка>`\n\n"
            "**Примеры:**\n"
            "`/getmedia https://youtube.com/watch?v=...`\n"
            "`/getmedia https://youtu.be/...`\n\n"
            "После отправки выбери формат: MP3 или MP4"
        )

    @bot.on(events.NewMessage(func=lambda e: e.text in ['/media', '🎬 Медиатека']))
    @with_verify("List Media", dangerous=False)
    async def list_media(event):
        state.media_cache.clear()
        audios, videos = [], []
        
        for f in os.listdir(ASSETS_DIR):
            ext = f.lower().split('.')[-1]
            if ext in ['mp3', 'wav', 'ogg']: 
                audios.append(os.path.join(ASSETS_DIR, f))
            elif ext in ['mp4', 'avi', 'mov', 'webm']: 
                videos.append(os.path.join(ASSETS_DIR, f))
                
        text = "🎬 **Медиатека:**\n\n🎵 **Музыка:**\n"
        idx = 1
        for a in audios:
            state.media_cache[str(idx)] = a
            text += f"👉 `/play {idx}` — {os.path.basename(a)}\n"
            idx += 1
            
        text += "\n🎞 **Видео:**\n"
        for v in videos:
            state.media_cache[str(idx)] = v
            text += f"👉 `/play {idx}` — {os.path.basename(v)}\n"
            idx += 1
            
        await event.reply(text if idx > 1 else "📭 В папке assets пока ничего нет.")

    @bot.on(events.NewMessage(pattern=r'^/play (\d+)'))
    @with_verify("Play Media", dangerous=False)
    async def play_media(event):
        idx = event.pattern_match.group(1)
        if idx not in state.media_cache: 
            return await event.reply("❌ Неверный ID. Нажмите «Медиатека» для обновления.")
        
        filepath = state.media_cache[idx]
        ext = filepath.lower().split('.')[-1]
        
        if ext in ['mp3', 'wav', 'ogg']:
            duration = get_media_duration(filepath)
            pygame.mixer.music.load(filepath)
            pygame.mixer.music.play()
            await event.reply(f"🔊 Играю аудио: {os.path.basename(filepath)} ({duration:.1f} сек)")
            # Останавливаем ровно по длительности трека
            if duration > 0:
                await asyncio.sleep(duration)
                pygame.mixer.music.stop()
            else:
                while pygame.mixer.music.get_busy():
                    await asyncio.sleep(0.5)
        else:
            duration = get_media_duration(filepath)
            os.startfile(filepath)
            await event.reply(f"🎬 Запускаю видео: {os.path.basename(filepath)} ({duration:.1f} сек)")
            # Ждём длительность видео, затем закрываем плеер
            wait = max(1.0, duration) if duration > 0 else 10.0
            await asyncio.sleep(wait)
            kill_video_players()

    @bot.on(events.NewMessage(pattern=r'^/getmedia(?: (.+))?$'))
    @with_verify("Get Media URL", dangerous=False)
    async def dl_media(event):
        url = event.pattern_match.group(1)
        if not url:
            return await event.reply(
                "📥 **Команда /getmedia** — скачать видео/аудио\n\n"
                "**Использование:**\n"
                "`/getmedia <URL>`\n\n"
                "**Примеры:**\n"
                "`/getmedia https://youtube.com/watch?v=...`\n"
                "`/getmedia https://youtu.be/...`\n\n"
                "После отправки команды выбери формат: MP3 или MP4"
            )
        # Чистим старые записи, если словарь разросся больше 50
        if len(state.pending_downloads) > 50:
            state.pending_downloads.clear()
        state.pending_downloads[event.sender_id] = url.strip()
        kb = [
            [Button.inline("🎵 Скачать MP3", b"dl_mp3")], 
            [Button.inline("🎬 Скачать MP4", b"dl_mp4")]
        ]
        await event.reply("Выберите формат для загрузки:", buttons=kb)

    # Вспомогательная функция для загрузки (run_dl остается без изменений)
    async def run_dl(url, fmt):
        loop = asyncio.get_running_loop()
        opts = {
            'outtmpl': os.path.join(ASSETS_DIR, '%(title)s.%(ext)s'), 
            'ffmpeg_location': FFMPEG_EXE, 
            'quiet': True, 
            'noplaylist': True
        }
        if fmt == 'mp3':
            opts.update({'format': 'bestaudio', 'postprocessors': [{'key': 'FFmpegExtractAudio', 'preferredcodec': 'mp3'}]})
        else:
            opts.update({'format': 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best'})
        
        def _do():
            with yt_dlp.YoutubeDL(opts) as ydl:
                info = ydl.extract_info(url, download=True)
                ext = 'mp3' if fmt == 'mp3' else info.get('ext', 'mp4')
                return f"{info.get('title')}.{ext}"
        return await loop.run_in_executor(None, _do)

    @bot.on(events.CallbackQuery(pattern=b'^dl_(mp3|mp4)$'))
    async def dl_cb(event):
        fmt = event.pattern_match.group(1).decode()
        url = state.pending_downloads.get(event.sender_id)
        if not url: return await event.answer("Ссылка устарела.", alert=True)
        await event.delete()
        msg = await event.respond(f"⏳ Начинаю загрузку {fmt.upper()}...")
        try:
            filename = await run_dl(url, fmt)
            await msg.edit(f"✅ Файл успешно скачан:\n`{filename}`")
        except Exception as e:
            await msg.edit(f"❌ Ошибка загрузки: {e}")

    # --- НОВАЯ ФУНКЦИЯ: УПРАВЛЕНИЕ КЛАВИШАМИ ПЛЕЕРА ---

    @bot.on(events.NewMessage(func=lambda e: e.text in ['/playpause', '/next', '/prev']))
    @with_verify("Media Control Keys", dangerous=False)
    async def media_keys(event):
        cmd = event.text
        if cmd == '/playpause': 
            pyautogui.press('playpause')
            await event.reply("⏯ Пауза / Воспроизведение")
        elif cmd == '/next': 
            pyautogui.press('nexttrack')
            await event.reply("⏭ Следующий трек")
        elif cmd == '/prev': 
            pyautogui.press('prevtrack')
            await event.reply("⏮ Предыдущий трек")