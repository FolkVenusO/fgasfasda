"""
Модуль для прямого взаимодействия с Windows API
Убирает костыли и работает напрямую с системой
"""

import ctypes
import logging
from ctypes import wintypes

logger = logging.getLogger(__name__)

# === КОНСТАНТЫ WinAPI ===
WM_CLOSE = 0x0010
PROCESS_TERMINATE = 0x0001
PROCESS_QUERY_INFORMATION = 0x0400

# === Загрузка DLL ===
user32 = ctypes.windll.user32
kernel32 = ctypes.windll.kernel32


# === УПРАВЛЕНИЕ ПРОЦЕССАМИ ===

def get_process_by_name(process_name: str) -> list:
    """Получить все PID процессов по имени (без taskkill!)"""
    import psutil
    pids = []
    for proc in psutil.process_iter(['pid', 'name']):
        try:
            if proc.info['name'].lower() == process_name.lower():
                pids.append(proc.info['pid'])
        except:
            pass
    return pids


def kill_process_by_pid(pid: int) -> bool:
    """Убить процесс напрямую через WinAPI (не через taskkill)"""
    try:
        # Открываем процесс с правами на завершение
        handle = kernel32.OpenProcess(PROCESS_TERMINATE, False, pid)
        if not handle:
            return False
        
        # Завершаем процесс
        result = kernel32.TerminateProcess(handle, 0)
        kernel32.CloseHandle(handle)
        return bool(result)
    except Exception as e:
        logger.error(f"Ошибка убийства процесса {pid}: {e}")
        return False


def kill_all_processes(process_name: str) -> int:
    """Убить все процессы с указанным именем (прямой WinAPI)"""
    pids = get_process_by_name(process_name)
    killed = 0
    for pid in pids:
        if kill_process_by_pid(pid):
            killed += 1
    return killed


# === УПРАВЛЕНИЕ ОКНАМИ ===

def find_window_by_title(title: str) -> int:
    """Найти HWND окна по заголовку (частичное совпадение)"""
    import win32gui
    
    def callback(hwnd, results):
        if win32gui.IsWindowVisible(hwnd):
            window_title = win32gui.GetWindowText(hwnd)
            if title.lower() in window_title.lower():
                results.append(hwnd)
        return True
    
    results = []
    win32gui.EnumWindows(callback, results)
    return results[0] if results else None


def close_window(hwnd: int) -> bool:
    """Закрыть окно напрямую через WinAPI (не через taskkill)"""
    try:
        import win32gui
        import win32con
        # Отправляем WM_CLOSE (корректное закрытие)
        win32gui.PostMessage(hwnd, win32con.WM_CLOSE, 0, 0)
        return True
    except Exception as e:
        logger.error(f"Ошибка закрытия окна {hwnd}: {e}")
        return False


def get_window_process_id(hwnd: int) -> int:
    """Получить PID процесса по HWND окна"""
    import win32process
    _, pid = win32process.GetWindowThreadProcessId(hwnd)
    return pid


# === УПРАВЛЕНИЕ МЕДИАПЛЕЕРАМИ (БЕЗ КОСТЫЛЕЙ) ===

class MediaPlayerController:
    """Контроллер для управления медиаплеерами напрямую"""
    
    KNOWN_PLAYERS = {
        'wmplayer.exe': 'Windows Media Player',
        'Movies.UI.exe': 'Movies & TV',
        'vlc.exe': 'VLC Media Player',
        'mpc-hc64.exe': 'MPC-HC',
        'mpc-hc.exe': 'MPC-HC'
    }
    
    def __init__(self):
        self.active_players = []  # Список (PID, имя) запущенных нами плееров
    
    def track_player(self, pid: int, name: str):
        """Запомнить PID плеера который мы запустили"""
        self.active_players.append((pid, name))
        logger.info(f"Отслеживаем плеер {name} (PID: {pid})")
    
    def stop_all_tracked(self) -> int:
        """Остановить только те плееры, которые мы запустили"""
        stopped = 0
        for pid, name in self.active_players:
            if kill_process_by_pid(pid):
                logger.info(f"Остановлен {name} (PID: {pid})")
                stopped += 1
        self.active_players.clear()
        return stopped
    
    def stop_all_known_players(self) -> int:
        """Остановить все известные плееры (аварийная мера)"""
        total = 0
        for exe_name in self.KNOWN_PLAYERS.keys():
            killed = kill_all_processes(exe_name)
            if killed > 0:
                logger.info(f"Остановлено {killed} экземпляров {exe_name}")
                total += killed
        return total
    
    def get_active_players(self) -> list:
        """Получить список активных плееров"""
        active = []
        for pid, name in self.active_players:
            import psutil
            try:
                if psutil.pid_exists(pid):
                    active.append((pid, name))
            except:
                pass
        self.active_players = active
        return active


# === УПРАВЛЕНИЕ КЛАВИАТУРОЙ (БЕЗ PYAUTOGUI) ===

def send_keypress(virtual_key_code: int):
    """Отправить нажатие клавиши напрямую через SendInput"""
    # Структура INPUT для SendInput
    PUL = ctypes.POINTER(ctypes.c_ulong)
    
    class KeyBdInput(ctypes.Structure):
        _fields_ = [("wVk", ctypes.c_ushort),
                    ("wScan", ctypes.c_ushort),
                    ("dwFlags", ctypes.c_ulong),
                    ("time", ctypes.c_ulong),
                    ("dwExtraInfo", PUL)]
    
    class HardwareInput(ctypes.Structure):
        _fields_ = [("uMsg", ctypes.c_ulong),
                    ("wParamL", ctypes.c_short),
                    ("wParamH", ctypes.c_ushort)]
    
    class MouseInput(ctypes.Structure):
        _fields_ = [("dx", ctypes.c_long),
                    ("dy", ctypes.c_long),
                    ("mouseData", ctypes.c_ulong),
                    ("dwFlags", ctypes.c_ulong),
                    ("time", ctypes.c_ulong),
                    ("dwExtraInfo", PUL)]
    
    class Input_I(ctypes.Union):
        _fields_ = [("ki", KeyBdInput),
                    ("mi", MouseInput),
                    ("hi", HardwareInput)]
    
    class Input(ctypes.Structure):
        _fields_ = [("type", ctypes.c_ulong),
                    ("ii", Input_I)]
    
    # Нажатие
    extra = ctypes.c_ulong(0)
    ii_ = Input_I()
    ii_.ki = KeyBdInput(virtual_key_code, 0, 0, 0, ctypes.pointer(extra))
    x = Input(ctypes.c_ulong(1), ii_)
    user32.SendInput(1, ctypes.pointer(x), ctypes.sizeof(x))
    
    # Отпускание
    ii_.ki = KeyBdInput(virtual_key_code, 0, 2, 0, ctypes.pointer(extra))
    x = Input(ctypes.c_ulong(1), ii_)
    user32.SendInput(1, ctypes.pointer(x), ctypes.sizeof(x))


# Виртуальные коды клавиш
VK_F11 = 0x7A  # Полноэкранный режим в большинстве плееров
VK_ESCAPE = 0x1B
VK_RETURN = 0x0D
VK_CONTROL = 0x11
VK_V = 0x56

# === УПРАВЛЕНИЕ ПИТАНИЕМ (БЕЗ OS.SYSTEM) ===

def shutdown_pc(force: bool = True):
    """Выключение ПК через WinAPI (не через shutdown.exe)"""
    SE_SHUTDOWN_NAME = "SeShutdownPrivilege"
    
    # Получаем привилегии
    import win32security
    import win32api
    import win32con
    
    try:
        # Получаем токен процесса
        hToken = win32security.OpenProcessToken(
            win32api.GetCurrentProcess(),
            win32con.TOKEN_ADJUST_PRIVILEGES | win32con.TOKEN_QUERY
        )
        
        # Включаем привилегию на выключение
        privilege_id = win32security.LookupPrivilegeValue(None, SE_SHUTDOWN_NAME)
        win32security.AdjustTokenPrivileges(
            hToken, 0,
            [(privilege_id, win32con.SE_PRIVILEGE_ENABLED)]
        )
        
        # Выключаем систему
        win32api.InitiateSystemShutdown(
            None,  # Локальная машина
            "Выключение через Remote Guardian",
            0,  # Немедленно
            force,  # Принудительно закрыть приложения
            False  # Выключение (не перезагрузка)
        )
        return True
    except Exception as e:
        logger.error(f"Ошибка выключения через WinAPI: {e}")
        # Fallback на старый метод
        import os
        os.system("shutdown /s /t 0")
        return False


def restart_pc(force: bool = True):
    """Перезагрузка ПК через WinAPI"""
    import win32security
    import win32api
    import win32con
    
    try:
        hToken = win32security.OpenProcessToken(
            win32api.GetCurrentProcess(),
            win32con.TOKEN_ADJUST_PRIVILEGES | win32con.TOKEN_QUERY
        )
        
        privilege_id = win32security.LookupPrivilegeValue(None, "SeShutdownPrivilege")
        win32security.AdjustTokenPrivileges(
            hToken, 0,
            [(privilege_id, win32con.SE_PRIVILEGE_ENABLED)]
        )
        
        # Перезагрузка
        win32api.InitiateSystemShutdown(
            None,
            "Перезагрузка через Remote Guardian",
            0,
            force,
            True  # Reboot = True
        )
        return True
    except Exception as e:
        logger.error(f"Ошибка перезагрузки через WinAPI: {e}")
        import os
        os.system("shutdown /r /t 0")
        return False


def lock_workstation():
    """Блокировка рабочей станции через WinAPI"""
    return bool(user32.LockWorkStation())


# === БЛОКИРОВКА МЫШИ (БЕЗ PYAUTOGUI) ===

def block_mouse_input(block: bool = True):
    """Блокировка мыши через WinAPI"""
    return bool(user32.BlockInput(block))


# === ПЕЧАТЬ ТЕКСТА (БЕЗ PYPERCLIP + CTRL+V) ===

def type_unicode_text(text: str):
    """Печать Unicode текста напрямую через SendInput (поддержка русского!)"""
    import time
    
    for char in text:
        # Для Unicode используем KEYEVENTF_UNICODE
        event = ctypes.c_uint(1)  # INPUT_KEYBOARD
        
        # Нажатие
        user32.keybd_event(0, ord(char), 4, 0)  # KEYEVENTF_UNICODE = 4
        time.sleep(0.01)  # Небольшая задержка для надёжности


# === ГЛОБАЛЬНЫЙ КОНТРОЛЛЕР ===
media_controller = MediaPlayerController()
