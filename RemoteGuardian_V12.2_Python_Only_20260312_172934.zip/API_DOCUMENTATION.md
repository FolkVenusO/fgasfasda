# 📚 API документация Remote Guardian V12

## 🎯 Архитектура

```
Remote Guardian V12
├── main.py                 # Точка входа
├── config.py              # Конфигурация
├── database.py            # База данных пользователей
├── core/                  # Ядро системы
│   ├── audio_com.py      # Управление звуком
│   ├── decorators.py     # Декораторы безопасности
│   ├── security.py       # Сенсоры безопасности
│   ├── state.py          # Глобальное состояние
│   └── winapi.py         # WinAPI интеграция
├── handlers/              # Обработчики команд
│   ├── system.py         # Системные команды
│   ├── surveillance.py   # Мониторинг
│   ├── cyber.py          # Кибер функции
│   ├── files.py          # Файловый менеджер
│   ├── media.py          # Медиа функции
│   ├── network.py        # Сетевые функции
│   ├── advanced.py       # Продвинутые функции
│   └── menus.py          # Меню и навигация
└── utils/                 # Утилиты
    ├── cache.py          # Кеширование
    ├── helpers.py        # Вспомогательные функции
    ├── thread_pool.py    # Пул потоков
    ├── optimizations.py  # Оптимизации
    ├── rate_limiter.py   # Rate limiting
    ├── security_validators.py  # Валидаторы
    ├── screenshot.py     # Оптимизированные скриншоты
    ├── performance_monitor.py  # Мониторинг производительности
    └── ai_enhancements.py      # AI улучшения
```

---

## 🔧 Core Modules

### `core/decorators.py`

#### `@with_verify(action_name, dangerous=False)`

Декоратор для проверки прав и лимитов.

**Параметры:**
- `action_name: str` - Имя действия для логирования
- `dangerous: bool` - Если True, доступно только владельцам

**Пример:**
```python
@bot.on(events.NewMessage(pattern=r'^/shutdown$'))
@with_verify("Shutdown PC", dangerous=True)
async def shutdown(event):
    # Код выключения
    pass
```

**Что проверяет:**
1. ✅ Есть ли пользователь в базе
2. ✅ Не исчерпан ли дневной лимит
3. ✅ Имеет ли права на опасные команды
4. ✅ Логирование всех действий

---

### `core/state.py`

#### `BotState` класс

Глобальное хранилище состояния системы.

**Атрибуты:**
```python
state.security_mode: bool           # Режим охраны
state.keylog_active: bool          # Статус кейлоггера
state.keylog_buffer: deque         # Буфер кейлоггера (10000 символов)
state.keylog_lock: threading.Lock  # Блокировка для потокобезопасности
state.bot_client: TelegramClient   # Клиент Telegram
state.bot_loop: asyncio.EventLoop  # Event loop
state.media_cache: dict            # Кеш медиа файлов
state.pending_downloads: dict      # Очередь загрузок
```

**Пример:**
```python
from core.state import state

# Включить режим охраны
state.security_mode = True

# Получить буфер кейлоггера потокобезопасно
with state.keylog_lock:
    text = ''.join(state.keylog_buffer)
```

---

### `core/winapi.py`

#### Управление процессами

**`get_process_by_name(name: str) -> list[int]`**

Получить PID всех процессов по имени.

```python
from core.winapi import get_process_by_name

pids = get_process_by_name("chrome.exe")
# [1234, 5678, 9012]
```

**`terminate_process(pid: int) -> bool`**

Завершить процесс по PID через WinAPI.

```python
from core.winapi import terminate_process

success = terminate_process(1234)
```

#### Управление питанием

**`shutdown_pc(force: bool = True) -> bool`**

Выключение ПК через WinAPI.

**`restart_pc(force: bool = True) -> bool`**

Перезагрузка ПК через WinAPI.

**`lock_workstation() -> bool`**

Блокировка рабочей станции.

#### Управление вводом

**`block_mouse_input(block: bool = True) -> bool`**

Блокировка мыши и клавиатуры.

**`type_unicode_text(text: str)`**

Печать Unicode текста напрямую через SendInput.

**`send_keypress(vk_code: int)`**

Отправка виртуального нажатия клавиши.

---

## 🛠️ Utils Modules

### `utils/rate_limiter.py`

#### `RateLimiter` класс

**Инициализация:**
```python
from utils.rate_limiter import RateLimiter

limiter = RateLimiter(max_calls=10, window=60)
# 10 вызовов в минуту
```

**Методы:**
```python
# Async проверка
allowed, wait_time = await limiter.check_rate_limit_async(user_id)

# Sync проверка
allowed, wait_time = limiter.check_rate_limit(user_id)

# Сброс лимита
limiter.reset(user_id)
```

#### Декоратор `@with_rate_limit`

```python
from utils.rate_limiter import with_rate_limit, dangerous_limiter

@with_rate_limit(dangerous_limiter)
@with_verify("Dangerous Action", dangerous=True)
async def dangerous_command(event):
    pass
```

---

### `utils/security_validators.py`

#### Валидация команд

**`validate_cmd_command(cmd: str) -> tuple[bool, Optional[str]]`**

Проверяет безопасность CMD команды.

```python
from utils.security_validators import validate_cmd_command

is_safe, reason = validate_cmd_command("dir C:\\")
if not is_safe:
    print(f"Опасная команда: {reason}")
```

**`validate_process_kill(pid: int, name: str) -> tuple[bool, Optional[str]]`**

Проверяет безопасность убийства процесса.

**`validate_file_path(path: str) -> tuple[bool, Optional[str]]`**

Защита от path traversal.

**`validate_ai_prompt(prompt: str) -> tuple[bool, Optional[str]]`**

Защита от prompt injection.

**`sanitize_log_message(msg: str) -> str`**

Скрывает чувствительные данные в логах.

---

### `utils/screenshot.py`

#### Оптимизированные скриншоты

**`take_screenshot_optimized(output_path: str, monitor: int = 0, compress: bool = True) -> bool`**

Делает скриншот используя самый быстрый метод (MSS → PIL → pyautogui).

**Производительность:**
- MSS: ~15-30ms ⚡
- PIL ImageGrab: ~50-80ms
- pyautogui: ~100-200ms

```python
from utils.screenshot import take_screenshot_optimized

success = take_screenshot_optimized("screen.png", compress=True)
# Сжимает PNG, экономит ~40-60% размера
```

**`get_screenshot_as_bytes(compress: bool = True) -> Optional[bytes]`**

Возвращает скриншот как байты без сохранения.

**`get_monitor_info() -> list[dict]`**

Информация о подключённых мониторах.

---

### `utils/cache.py`

#### Simple Cache с TTL

**`@cached(ttl: float = 60.0)` декоратор**

```python
from utils.cache import cached

@cached(ttl=30.0)
async def get_system_info():
    # Результат кешируется на 30 секунд
    return psutil.cpu_percent()
```

**SimpleCache класс:**
```python
from utils.cache import SimpleCache

cache = SimpleCache()

# Async методы
await cache.set_async("key", "value")
value = await cache.get_async("key", ttl=60.0)

# Sync методы
cache.set("key", "value")
value = cache.get("key", ttl=60.0)
```

---

### `utils/ai_enhancements.py`

#### AI Session Management

**`get_or_create_session(user_id: str) -> AISession`**

Получить или создать AI сессию с контекстом.

```python
from utils.ai_enhancements import get_or_create_session

session = get_or_create_session("123456789")
session.add_message("user", "Привет!")
session.add_message("assistant", "Здравствуй!")

context = session.get_context()
# [{'role': 'user', 'content': 'Привет!'}, ...]
```

**`extract_commands_advanced(text: str) -> list[str]`**

Улучшенный парсер команд из AI ответа.

```python
from utils.ai_enhancements import extract_commands_advanced

text = "Делаю скриншот! [COMMAND:/screenshot]"
commands = extract_commands_advanced(text)
# ['/screenshot']
```

**`should_take_screenshot(question: str) -> bool`**

Автоматически определяет нужен ли скриншот.

**`build_system_prompt(language: str = 'ru') -> str`**

Строит системный промпт для Gemini.

---

### `utils/performance_monitor.py`

#### Мониторинг производительности

**`@performance_monitor(name, log_slow_threshold=2.0)` декоратор**

```python
from utils.performance_monitor import performance_monitor

@performance_monitor("Screenshot", log_slow_threshold=1.0)
async def take_screenshot(event):
    # Автоматически логирует если > 1 секунды
    pass
```

**`get_performance_stats() -> dict`**

Получить статистику всех команд.

**`format_performance_report() -> str`**

Форматированный отчёт для отправки пользователю.

---

## 📊 Database API

### `database.py`

#### Async методы (рекомендуется)

**`await add_async(user_id: str, limit: int)`**

Добавить пользователя.

**`await remove_async(user_id: str) -> bool`**

Удалить пользователя.

**`await check_limit_async(user_id: str) -> tuple[bool, int]`**

Проверить лимит пользователя.

**`await save_async()`**

Сохранить базу данных потокобезопасно.

#### Sync методы (deprecated)

```python
# ⚠️ НЕ ИСПОЛЬЗУЙ в async коде!
database.add(user_id, limit)
database.remove(user_id)
database.check_limit(user_id)
database.save()
```

#### Структура БД

```json
{
  "123456789": {
    "role": "owner",
    "limit": 99999,
    "used_today": 0,
    "last_date": "2026-03-12"
  },
  "987654321": {
    "role": "user",
    "limit": 50,
    "used_today": 15,
    "last_date": "2026-03-12"
  }
}
```

---

## 🧪 Testing API

### Тесты безопасности

```bash
python tests/test_security.py
```

### Тесты производительности

```bash
python tests/test_performance.py
```

---

## 🚀 Примеры использования

### Создание новой команды

```python
# handlers/my_module.py

from telethon import events
from core.decorators import with_verify
from utils.rate_limiter import with_rate_limit, command_limiter

def register_my_commands(bot):
    
    @bot.on(events.NewMessage(pattern=r'^/mycommand$'))
    @with_rate_limit(command_limiter)
    @with_verify("My Command", dangerous=False)
    async def my_command(event):
        """
        Описание команды.
        """
        # Твой код здесь
        await event.reply("✅ Команда выполнена!")
```

### Регистрация модуля

```python
# handlers/__init__.py

from .my_module import register_my_commands

def register_all_handlers(bot):
    # ... существующие регистрации
    register_my_commands(bot)
```

---

## 📝 Best Practices

### ✅ DO:

1. **Всегда используй `@with_verify`** для проверки прав
2. **Используй async версии** database функций
3. **Логируй важные действия** через `logger.info()`
4. **Используй валидаторы** из `security_validators.py`
5. **Добавляй docstrings** к новым функциям
6. **Используй type hints** где возможно
7. **Обрабатывай исключения** с конкретными сообщениями

### ❌ DON'T:

1. **Не используй `os.system()`** - используй WinAPI
2. **Не блокируй event loop** - используй `asyncio.to_thread()`
3. **Не храни пароли** в коде
4. **Не игнорируй ошибки** - логируй их
5. **Не дублируй код** - выноси в utils

---

**Версия API:** 12.0  
**Совместимость:** Python 3.10+  
**Платформа:** Windows 10/11
